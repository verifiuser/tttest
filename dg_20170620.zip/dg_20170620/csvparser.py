# -*- coding: utf-8 -*-

import csv
import codecs

__author__ = "Nobuyuki Ejiri (yukidome25@gmail.com)"
__copyright__ = "Copyright 2017, Nobuyuki Ejiri"
__license__ = "MIT"
__version__ = "0.0.1 2017/06/11"


class CsvParser:

    def __init__(self):
        pass

    @staticmethod
    def savedata(rows="", name="", extension="", encode=""):

        mode = 'w'

        def __create(nm, ext, md, enc):
            return codecs.open(nm + ext, md, enc)

        def __save(cf, data):
            writer = csv.writer(cf)
            writer.writerows(data)

        cs = __create(name, extension, mode, encode)

        __save(cs, rows)

        cs.close()
