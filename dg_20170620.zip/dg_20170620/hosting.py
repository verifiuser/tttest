# -*- coding: utf-8 -*-

import random
import daterange
import csvparser
import switch
import underid
import excelwrapper


class Hosting:

    def __init__(self):

        self.hosting_id = ""
        self.lbc_office_id = ""
        self.hosting_gid = ""
        self.hosting_update_at = ""

        self.ew = excelwrapper.ExcelWrapper('landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2007, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mch.ew.header, mch.ew.count_rows):

            mch.lbc_office_id = mch.ew.get_cell_str(row=row, col=0)
            mch.hosting_gid = mch.ew.get_cell_str(row=row, col=2)
            gn_count = mch.ew.get_cell_int(row=(mch.sw.case(mch.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                mch.hosting_id = mch.hosting_gid + mch.udi.calculation(count=i)
                mch.hosting_update_at = random.choice(mch.ud_list)

                mch.rows.append(
                    [
                        mch.hosting_id, mch.lbc_office_id, mch.hosting_gid, mch.hosting_update_at
                    ]
                )
        mch.cs.savedata(rows=mch.rows, name='hosting', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mch = Hosting()
    mch.main()
    del mch
