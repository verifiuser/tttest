# -*- coding: utf-8 -*-

import random
import daterange
import csvparser
import switch
import underid
import excelwrapper


class Act:

    def __init__(self):

        self.act_doc_id = ""
        self.lbc_office_id = ""
        self.act_gid = ""
        self.act_title = ""
        self.act_remarks = ""
        self.act_reg_date = ""
        self.act_div = ""
        self.act_proc_type = ""
        self.act_products = ""
        self.act_member_name = ""
        self.act_must_party = ""
        self.act_party = ""
        self.act_end_date = ""
        self.act_update_at = ""
        self.act_del_flag = 0

        self.ew = excelwrapper.ExcelWrapper('landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.title_list = ["株式会社ランドスケイプ ", "     佐藤様     山本様    ", "   村上農園　http://www.murakamifarm.com/"]
        self.rem_list = ["	【日本HP】11.担当者情報　カラム追加依頼 \
        【日本HP】10.活動履歴情報　結果区分項目追加依頼 \
        【日本HP】9.活動履歴情報　カラム追加依頼 ", "×	         	【理由】	●新規やらない為  \
        ●拠点単位で取引が発生。●立ち上げて5年。●保守は件数は増えても、単価が下がる。保守先に消耗品を販売。純正＋消耗品。●保守先で1割。●既存へのアウェアネスを高める。● ",
                         "https://www.nttcsol.com/topics/pdf/news_20160901.pdf←名前見つけるhttp://nttcsol-saiyo.com \
                         /business/index.html#organization \
                         ←採用ページより「経営企画部は経営戦略、事業計画、人事・人材育成、労務構成、財務、会計、総務、法務、社内システムなどを企画立案します。」 "]
        self.div_list = ['訪問', '来社', '社内打合せ']
        self.proc_list = ['004', '005', '006']
        self.product_list = ['LBC001', 'LBC001/DM001', 'LBC001/US002/DM002']
        self.member_list = ['秋山 友也', '中溝 祥影', '山本 友和']
        self.mparty_list = ['幸田 智', '木坊子 圭介¥t大槻 一樹', '江尻 信之¥t高橋 知浩¥t秋山 友也']
        self.party_list = ['幸田 智', '木坊子 圭介¥t大槻 一樹', '江尻 信之¥t高橋 知浩¥t秋山 友也']
        self.rg_ed_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2005)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2006, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(an.ew.header, an.ew.count_rows):

            an.lbc_office_id = an.ew.get_cell_str(row=row, col=0)
            an.act_gid = an.ew.get_cell_str(row=row, col=2)
            gn_count = an.ew.get_cell_int(row=(an.sw.case(an.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                an.act_doc_id = an.act_gid + an.udi.calculation(count=i)
                an.act_title = random.choice(an.title_list)
                an.act_remarks = random.choice(an.rem_list)
                an.act_div = random.choice(an.div_list)
                an.act_proc_type = random.choice(an.proc_list)
                an.act_products = random.choice(an.product_list)
                an.act_member_name = random.choice(an.member_list)
                an.act_must_party = random.choice(an.mparty_list)
                an.act_party = random.choice(an.party_list)
                an.act_reg_date = random.choice(an.rg_ed_list)
                an.act_end_date = random.choice(an.rg_ed_list)
                an.act_update_at = random.choice(an.ud_list)

                an.rows.append(
                    [
                        an.act_doc_id, an.lbc_office_id, an.act_gid, an.act_title, an.act_remarks, an.act_reg_date,
                        an.act_div, an.act_proc_type, an.act_products, an.act_member_name, an.act_must_party,
                        an.act_party, an.act_end_date, an.act_update_at, an.act_del_flag
                    ]
                )
        an.cs.savedata(rows=an.rows, name='act', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    an = Act()
    an.main()
    del an
