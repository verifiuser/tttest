# -*- coding: utf-8 -*-

import random
import daterange
import csvparser
import switch
import underid
import excelwrapper


class LiveAccess:

    def __init__(self):

        self.live_access_id = ""
        self.lbc_office_id = ""
        self.live_access_gid = ""
        self.live_access_access_date = ""
        self.live_access_referrer = ""
        self.live_access_site_url = ""
        self.live_access_search_word = ""
        self.live_access_live_page_url = ""
        self.live_access_cookie_id = ""
        self.live_access_create_at = ""
        self.live_access_category_id = 0
        self.live_access_hierarchy_path = ""

        self.ew = excelwrapper.ExcelWrapper('landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.referrer_list = ["android-app://com.Slack",
                              "android-app://com.google.android.apps.plus/https/plus.url.google.com/mobileapp",
                              "android-app://com.google.android.gm"]
        self.site_list = ["1",
                          "http://marketing.itmedia.co.jp/",
                          "http://marketing.itmedia.co.jp/mm/articles/0501/11/news094.html"]
        self.search_list = ["052-962-0311",
                            "http://www.landscape.co.jp/",
                            "〒103ｰ8419 東京都中央区日本橋本町2-7-1 NOF日本橋本町ビル5F 地図"]
        self.url_list = ["marketing.itmedia.co.jp",
                         "marketing.itmedia.co.jp/mm/articles/0501/11/news094.html",
                         "marketing.itmedia.co.jp/mm/articles/0501/11/news094_2.html"]
        self.category_list = [16, 15, 7]
        self.hierarchy_list = ["/4/16", "/2/15", "/1/7"]
        self.ac_list = dr.random_date(span_list=(dr.date_span(start_year=2010, end_year=2017)))
        self.cr_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2009)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mla.ew.header, mla.ew.count_rows):

            mla.lbc_office_id = mla.ew.get_cell_str(row=row, col=0)
            mla.live_access_gid = mla.ew.get_cell_str(row=row, col=2)
            gn_count = mla.ew.get_cell_int(row=(mla.sw.case(mla.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                mla.live_access_id = mla.live_access_gid + mla.udi.calculation(count=i)
                mla.live_access_referrer = random.choice(mla.referrer_list)
                mla.live_access_site_url = random.choice(mla.site_list)
                mla.live_access_search_word = random.choice(mla.search_list)
                mla.live_access_live_page_url = random.choice(mla.url_list)
                mla.live_access_category_id = random.choice(mla.category_list)
                mla.live_access_hierarchy_path = random.choice(mla.hierarchy_list)
                mla.live_access_access_date = random.choice(mla.ac_list)
                mla.live_access_create_at = random.choice(mla.cr_list)

                mla.rows.append(
                    [
                        mla.live_access_id, mla.lbc_office_id, mla.live_access_gid, mla.live_access_access_date,
                        mla.live_access_referrer, mla.live_access_site_url, mla.live_access_search_word,
                        mla.live_access_live_page_url, mla.live_access_cookie_id, mla.live_access_create_at,
                        mla.live_access_category_id, mla.live_access_hierarchy_path
                    ]
                )
        mla.cs.savedata(rows=mla.rows, name='liveaccess', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mla = LiveAccess()
    mla.main()
    del mla
