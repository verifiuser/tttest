# -*- coding: utf-8 -*-

import random
import daterange
import csvparser
import switch
import underid
import excelwrapper


class Deal:

    def __init__(self):

        self.deal_status_id = ""
        self.lbc_office_id = ""
        self.deal_flag = 0
        self.deal_gid = ""
        self.deal_update_at = ""
        self.deal_del_flag = 0

        self.ew = excelwrapper.ExcelWrapper('landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.df_list = [1, 2, 3, 4, 5]
        self.dd_list = dr.random_date_time(span_list=(dr.date_span(start_year=2007, end_year=2016)))
        self._id = 0

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(ds.ew.header, ds.ew.count_rows):

            ds.lbc_office_id = ds.ew.get_cell_str(row=row, col=0)
            ds.deal_gid = ds.ew.get_cell_str(row=row, col=2)
            gn_count = ds.ew.get_cell_int(row=(ds.sw.case(ds.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                ds.deal_status_id = ds.deal_gid + ds.udi.calculation(count=i)
                ds.deal_flag = random.choice(ds.df_list)
                ds.deal_update_at = random.choice(ds.dd_list)

                ds.rows.append(
                    [
                        ds.deal_status_id, ds.lbc_office_id, ds.deal_flag, ds.deal_gid, ds.deal_update_at,
                        ds.deal_del_flag
                    ]
                )
        ds.cs.savedata(rows=ds.rows, name='deal', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    ds = Deal()
    ds.main()
    del ds
