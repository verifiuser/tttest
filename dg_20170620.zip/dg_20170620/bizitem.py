# -*- coding: utf-8 -*-

import random
import daterange
import csvparser
import switch
import underid
import excelwrapper


class BizItem:

    def __init__(self):

        self.biz_item_id = ""
        self.lbc_office_id = ""
        self.biz_item_gid = ""
        self.biz_item_status = ""
        self.biz_item_product = ""
        self.biz_item_price = 0
        self.biz_item_probability = 0
        self.biz_item_end_date = ""
        self.biz_item_update_at = ""
        self.biz_item_del_flag = 0

        self.ew = excelwrapper.ExcelWrapper('landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.status_list = ["01", "02", "03", "04", "05", "06", "07"]
        self.product_list = ["DISH001", "DISH002", "DM001"]
        self.price_list = [i for i in xrange(100, 100000)]
        self.pro_list = [0, 10, 20, 40, 50, 80, 90, 100]
        self.ed_list = dr.random_date(span_list=(dr.date_span(start_year=2010, end_year=2017)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2007, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mbi.ew.header, mbi.ew.count_rows):

            mbi.lbc_office_id = mbi.ew.get_cell_str(row=row, col=0)
            mbi.biz_item_gid = mbi.ew.get_cell_str(row=row, col=2)
            gn_count = mbi.ew.get_cell_int(row=(mbi.sw.case(mbi.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                mbi.biz_item_id = mbi.biz_item_gid + mbi.udi.calculation(count=i)
                mbi.biz_item_status = random.choice(mbi.status_list)
                mbi.biz_item_product = random.choice(mbi.product_list)
                mbi.biz_item_price = random.choice(mbi.price_list)
                mbi.biz_item_probability = random.choice(mbi.pro_list)
                mbi.biz_item_end_date = random.choice(mbi.ed_list)
                mbi.biz_item_update_at = random.choice(mbi.ud_list)

                mbi.rows.append(
                    [
                        mbi.biz_item_id, mbi.lbc_office_id, mbi.biz_item_gid, mbi.biz_item_status, mbi.biz_item_product,
                        mbi.biz_item_price, mbi.biz_item_probability, mbi.biz_item_end_date, mbi.biz_item_update_at,
                        mbi.biz_item_del_flag
                    ]
                )
        mbi.cs.savedata(rows=mbi.rows, name='bizitem', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mbi = BizItem()
    mbi.main()
    del mbi
