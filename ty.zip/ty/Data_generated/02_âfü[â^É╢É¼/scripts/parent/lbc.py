# -*- coding: utf-8 -*-

from entity import lbc
import daterange
import csvparser
import excelwrapper
import corputil
import landutil

__version__ = "1.0.0"


class Lbc:

    def __init__(self):

        self.en = lbc.Lbc()
        self.lu = landutil.LandUtil('lbc')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.cu = corputil.CorpUtil()
        self.cs = csvparser.CsvParser()

        self.cd_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2005)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2006, end_year=2010)))
        self.ua_list = dr.random_date_time(span_list=(dr.date_span(start_year=2011, end_year=2017)))
        self.vd_list = dr.random_date(span_list=(dr.date_span(start_year=2003, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(plm.ew.header, plm.ew.count_rows):

            plm.en.gid = plm.ew.get_cell_str(row=row, col=2)
            plm.en.office_id = plm.ew.get_cell_str(row=row, col=0)
            plm.en.c_office_id = plm.en.office_id
            plm.en.c_head_office_id = plm.en.office_id
            plm.en.c_top_head_office_id = plm.en.office_id
            plm.en.c_top_af_office_id1 = plm.en.office_id
            plm.en.c_affiliated_office_id1 = plm.en.office_id
            plm.en.formal_company_name = plm.ew.get_cell_str(row=row, col=1)
            plm.en.company_name = plm.ew.get_cell_str(row=row, col=1)
            plm.en.c_relation_flag1 = plm.lu.get_nr('c_relation_flag1')
            plm.en.company_abbreviated_flag = plm.lu.get_nr('company_abbreviated_flag')
            plm.en.c_listed_code = plm.lu.get_nr('c_listed_code')
            plm.en.c_hyouten = plm.lu.get_nr('c_hyouten')
            plm.en.c_building_name = plm.lu.get_nr('c_building_name')
            plm.en.c_office_count_range = plm.lu.get_nr('c_office_count_range')
            plm.en.c_capital_range = plm.lu.get_nr('c_capital_range')
            plm.en.c_emp_count_range = plm.lu.get_nr('c_emp_count_range')
            plm.en.c_sales_range = plm.lu.get_nr('c_sales_range')
            plm.en.c_profit_range = plm.lu.get_nr('c_profit_range')
            plm.en.c_company_kind = plm.lu.get_nr('c_company_kind')
            plm.en.c_has_url = plm.lu.get_nr('c_has_url')
            plm.en.c_has_foreign_flag = plm.lu.get_nr('c_has_foreign_flag')
            plm.en.c_is_head_office = plm.lu.get_nr('c_is_head_office')
            plm.en.c_stat_ng = plm.lu.get_nr('c_stat_ng')
            plm.en.c_is_ccng = plm.lu.get_nr('c_is_ccng')
            plm.en.c_is_mujin_office = plm.lu.get_nr('c_is_mujin_office')
            plm.en.c_office_class = plm.lu.get_nr('c_office_class')
            plm.en.c_grade = plm.lu.get_nr('c_grade')
            plm.en.c_is_faxdm = plm.lu.get_nr('c_is_faxdm')
            plm.en.create_date = plm.lu.get_cal(plm.cd_list)
            plm.en.update_date = plm.lu.get_cal(plm.ud_list)
            plm.en.update_at = plm.lu.get_cal(plm.ua_list)
            plm.en.c_inv_date = plm.lu.get_cal(plm.vd_list)
            plm.en.company_abbreviated_name = plm.cu.check_corporation(plm.en.company_name)
            plm.en.company_before_after = plm.cu.check_corporation_number(plm.en.company_name)
            plm.en.company_before_after_name = plm.cu.check_corporation_name(plm.en.company_name, plm.en.company_before_after)

            plm.rows.append(
                [
                    plm.en.gid, plm.en.office_id, plm.en.company_abbreviated_flag, plm.en.company_abbreviated_name,
                    plm.en.company_before_after, plm.en.company_before_after_name, plm.en.company_name,
                    plm.en.formal_company_name, plm.en.office_name, plm.en.industry_code1_large,
                    plm.en.industry_code1_medium, plm.en.industry_code1_small, plm.en.industry_code1_tiny,
                    plm.en.industry_code2_large, plm.en.industry_code2_medium, plm.en.industry_code2_small,
                    plm.en.industry_code2_tiny, plm.en.industry_code3_large, plm.en.industry_code3_medium,
                    plm.en.industry_code3_small, plm.en.industry_code3_tiny, plm.en.create_date, plm.en.update_date,
                    plm.en.update_at, plm.en.c_office_id, plm.en.c_head_office_id, plm.en.c_top_head_office_id,
                    plm.en.c_top_af_office_id1, plm.en.c_affiliated_office_id1, plm.en.c_relation_flag1,
                    plm.en.c_listed_code, plm.en.c_sec_code, plm.en.c_yuho_number, plm.en.c_hyouten,
                    plm.en.c_company_name, plm.en.c_company_name_kana, plm.en.c_office_name, plm.en.c_building_name,
                    plm.en.c_company_pref_id, plm.en.c_company_city_id, plm.en.c_company_zip, plm.en.c_tel,
                    plm.en.c_fax, plm.en.c_office_count, plm.en.c_office_count_range, plm.en.c_setup_date,
                    plm.en.c_capital, plm.en.c_capital_range, plm.en.c_emp_count, plm.en.c_emp_count_range,
                    plm.en.c_sales, plm.en.c_sales_range, plm.en.c_settlement_month, plm.en.c_profit,
                    plm.en.c_profit_range, plm.en.c_license, plm.en.c_organizations, plm.en.c_inv_date,
                    plm.en.c_company_kind, plm.en.c_has_url, plm.en.c_has_foreign_flag, plm.en.c_is_head_office,
                    plm.en.c_stat_ng, plm.en.c_is_ccng, plm.en.c_is_mujin_office, plm.en.c_office_class,
                    plm.en.c_corporate_number, plm.en.c_grade, plm.en.del_flag, plm.en.c_is_faxdm
                ]
            )
        plm.cs.savedata(rows=plm.rows, name='lbc', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    plm = Lbc()
    plm.main()
    del plm
