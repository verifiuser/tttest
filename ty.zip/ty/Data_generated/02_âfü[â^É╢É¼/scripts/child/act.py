# -*- coding: utf-8 -*-

from entity import act
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil

__version__ = "1.0.0"


class Act:

    def __init__(self):

        self.en = act.Act()
        self.lu = landutil.LandUtil('act')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.rg_list = dr.random_date_time_no_format(span_list=(dr.date_span(start_year=2001, end_year=2005)))
        self.ed_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2005)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2006, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(an.ew.header, an.ew.count_rows):

            an.en.office_id = an.ew.get_cell_str(row=row, col=0)
            an.en.gid = an.ew.get_cell_str(row=row, col=2)
            gn_count = an.ew.get_cell_int(row=(an.sw.case(an.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                an.en.doc_id = an.en.gid + "-" + an.lu.get_union(an.en.office_id + an.udi.calculation(count=i))
                an.en.title = an.lu.get_nr('title')
                an.en.remarks = an.lu.get_nr('remarks')
                an.en.div = an.lu.get_nr('div')
                an.en.proc_type = an.lu.get_nr('proc_type')
                an.en.products = an.lu.get_nr('products')
                an.en.member_name = an.lu.get_nr('member_name')
                an.en.must_party = an.lu.get_nr('must_party')
                an.en.party = an.lu.get_nr('party')
                an.en.reg_date = an.lu.get_cal(an.rg_list)
                an.en.end_date = an.lu.get_cal(an.ed_list)
                an.en.update_at = an.lu.get_cal(an.ud_list)

                an.rows.append(
                    [
                        an.en.doc_id, an.en.office_id, an.en.gid, an.en.title, an.en.remarks, an.en.reg_date, an.en.div,
                        an.en.proc_type, an.en.products, an.en.member_name, an.en.must_party, an.en.party,
                        an.en.end_date, an.en.update_at, an.en.del_flag
                    ]
                )
        an.cs.savedata(rows=an.rows, name='act', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    an = Act()
    an.main()
    del an
