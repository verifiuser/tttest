# -*- coding: utf-8 -*-

__version__ = "1.0.0"


class Hosting:

    def __init__(self):

        self._id = None
        self._office_id = None
        self._gid = None
        self._update_at = None

    @property
    def id(self):
        pass

    @property
    def office_id(self):
        pass

    @property
    def gid(self):
        pass

    @property
    def update_at(self):
        pass

    @id.getter
    def id(self):
        return self._id

    @office_id.getter
    def office_id(self):
        return self._office_id

    @gid.getter
    def gid(self):
        return self._gid

    @update_at.getter
    def update_at(self):
        return self._update_at

    @id.setter
    def id(self, value):
        self._id = value

    @office_id.setter
    def office_id(self, value):
        self._office_id = value

    @gid.setter
    def gid(self, value):
        self._gid = value

    @update_at.setter
    def update_at(self, value):
        self._update_at = value

    @id.deleter
    def id(self):
        del self._id

    @office_id.deleter
    def office_id(self):
        del self._office_id

    @gid.deleter
    def gid(self):
        del self._gid

    @update_at.deleter
    def update_at(self):
        del self._update_at
