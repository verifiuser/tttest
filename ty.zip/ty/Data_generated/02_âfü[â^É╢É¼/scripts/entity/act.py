# -*- coding: utf-8 -*-

__version__ = "1.0.0"


class Act:

    def __init__(self):

        self._doc_id = None
        self._office_id = None
        self._gid = None
        self._title = None
        self._remarks = None
        self._reg_date = None
        self._div = None
        self._proc_type = None
        self._products = None
        self._member_name = None
        self._must_party = None
        self._party = None
        self._end_date = None
        self._update_at = None
        self._del_flag = 0

    @property
    def doc_id(self):
        pass

    @property
    def office_id(self):
        pass

    @property
    def gid(self):
        pass

    @property
    def title(self):
        pass

    @property
    def remarks(self):
        pass

    @property
    def reg_date(self):
        pass

    @property
    def div(self):
        pass

    @property
    def proc_type(self):
        pass

    @property
    def products(self):
        pass

    @property
    def member_name(self):
        pass

    @property
    def must_party(self):
        pass

    @property
    def party(self):
        pass

    @property
    def end_date(self):
        pass

    @property
    def update_at(self):
        pass

    @property
    def del_flag(self):
        pass

    @doc_id.getter
    def doc_id(self):
        return self._doc_id

    @office_id.getter
    def office_id(self):
        return self._office_id

    @gid.getter
    def gid(self):
        return self._gid

    @title.getter
    def title(self):
        return self._title

    @remarks.getter
    def remarks(self):
        return self._remarks

    @reg_date.getter
    def reg_date(self):
        return self._reg_date

    @div.getter
    def div(self):
        return self._div

    @proc_type.getter
    def proc_type(self):
        return self._proc_type

    @products.getter
    def products(self):
        return self._products

    @member_name.getter
    def member_name(self):
        return self._member_name

    @must_party.getter
    def must_party(self):
        return self._must_party

    @party.getter
    def party(self):
        return self._party

    @end_date.getter
    def end_date(self):
        return self._end_date

    @update_at.getter
    def update_at(self):
        return self._update_at

    @del_flag.getter
    def del_flag(self):
        return self._del_flag

    @doc_id.setter
    def doc_id(self, value):
        self._doc_id = value

    @office_id.setter
    def office_id(self, value):
        self._office_id = value

    @gid.setter
    def gid(self, value):
        self._gid = value

    @title.setter
    def title(self, value):
        self._title = value

    @remarks.setter
    def remarks(self, value):
        self._remarks = value

    @reg_date.setter
    def reg_date(self, value):
        self._reg_date = value

    @div.setter
    def div(self, value):
        self._div = value

    @proc_type.setter
    def proc_type(self, value):
        self._proc_type = value

    @products.setter
    def products(self, value):
        self._products = value

    @member_name.setter
    def member_name(self, value):
        self._member_name = value

    @must_party.setter
    def must_party(self, value):
        self._must_party = value

    @party.setter
    def party(self, value):
        self._party = value

    @end_date.setter
    def end_date(self, value):
        self._end_date = value

    @update_at.setter
    def update_at(self, value):
        self._update_at = value

    @del_flag.setter
    def del_flag(self, value):
        self._del_flag = value

    @doc_id.deleter
    def doc_id(self):
        del self._doc_id

    @office_id.deleter
    def office_id(self):
        del self._office_id

    @gid.deleter
    def gid(self):
        del self._gid

    @title.deleter
    def title(self):
        del self._title

    @remarks.deleter
    def remarks(self):
        del self._remarks

    @reg_date.deleter
    def reg_date(self):
        del self._reg_date

    @div.deleter
    def div(self):
        del self._div

    @proc_type.deleter
    def proc_type(self):
        del self._proc_type

    @products.deleter
    def products(self):
        del self._products

    @member_name.deleter
    def member_name(self):
        del self._member_name

    @must_party.deleter
    def must_party(self):
        del self._must_party

    @party.deleter
    def party(self):
        del self._party

    @end_date.deleter
    def end_date(self):
        del self._end_date

    @update_at.deleter
    def update_at(self):
        del self._update_at

    @del_flag.deleter
    def del_flag(self):
        del self._del_flag
