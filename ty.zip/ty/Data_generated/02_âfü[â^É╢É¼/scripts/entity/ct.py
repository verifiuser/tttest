# -*- coding: utf-8 -*-

__version__ = "1.0.0"


class Ct:

    def __init__(self):

        self._id = None
        self._office_id = None
        self._gid = None
        self._uni_id3 = None
        self._category = 0
        self._target_type = 0
        self._action_id = 0
        self._action_type = 0
        self._product_ids = None
        self._action_date = None
        self._update_at = None
        self._del_flag = 0

    @property
    def id(self):
        pass

    @property
    def office_id(self):
        pass

    @property
    def gid(self):
        pass

    @property
    def uni_id3(self):
        pass

    @property
    def category(self):
        pass

    @property
    def target_type(self):
        pass

    @property
    def action_id(self):
        pass

    @property
    def action_type(self):
        pass

    @property
    def product_ids(self):
        pass

    @property
    def action_date(self):
        pass

    @property
    def update_at(self):
        pass

    @property
    def del_flag(self):
        pass

    @id.getter
    def id(self):
        return self._id

    @office_id.getter
    def office_id(self):
        return self._office_id

    @gid.getter
    def gid(self):
        return self._gid

    @uni_id3.getter
    def uni_id3(self):
        return self._uni_id3

    @category.getter
    def category(self):
        return self._category

    @target_type.getter
    def target_type(self):
        return self._target_type

    @action_id.getter
    def action_id(self):
        return self._action_id

    @action_type.getter
    def action_type(self):
        return self._action_type

    @product_ids.getter
    def product_ids(self):
        return self._product_ids

    @action_date.getter
    def action_date(self):
        return self._action_date

    @update_at.getter
    def update_at(self):
        return self._update_at

    @del_flag.getter
    def del_flag(self):
        return self._del_flag

    @id.setter
    def id(self, value):
        self._id = value

    @office_id.setter
    def office_id(self, value):
        self._office_id = value

    @gid.setter
    def gid(self, value):
        self._gid = value

    @uni_id3.setter
    def uni_id3(self, value):
        self._uni_id3 = value

    @category.setter
    def category(self, value):
        self._category = value

    @target_type.setter
    def target_type(self, value):
        self._target_type = value

    @action_id.setter
    def action_id(self, value):
        self._action_id = value

    @action_type.setter
    def action_type(self, value):
        self._action_type = value

    @product_ids.setter
    def product_ids(self, value):
        self._product_ids = value

    @action_date.setter
    def action_date(self, value):
        self._action_date = value

    @update_at.setter
    def update_at(self, value):
        self._update_at = value

    @del_flag.setter
    def del_flag(self, value):
        self._del_flag = value

    @id.deleter
    def id(self):
        del self._id

    @office_id.deleter
    def office_id(self):
        del self._office_id

    @gid.deleter
    def gid(self):
        del self._gid

    @uni_id3.deleter
    def uni_id3(self):
        del self._uni_id3

    @category.deleter
    def category(self):
        del self._category

    @target_type.deleter
    def target_type(self):
        del self._target_type

    @action_id.deleter
    def action_id(self):
        del self._action_id

    @action_type.deleter
    def action_type(self):
        del self._action_type

    @product_ids.deleter
    def product_ids(self):
        del self._product_ids

    @action_date.deleter
    def action_date(self):
        del self._action_date

    @update_at.deleter
    def update_at(self):
        del self._update_at

    @del_flag.deleter
    def del_flag(self):
        del self._del_flag
