SELECT
	'lbc' GID
, 	lcm.OFFICE_ID	lbc_office_id
, 	lcm.COMPANY_ABBREVIATED_FLAG	lbc_company_abbreviated_flag
,	CASE
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '00' THEN '法人格なし'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '01' THEN '株式会社'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '02' THEN '有限会社'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '03' THEN '合資会社'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '04' THEN '合名会社'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '05' THEN '協同組合'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '06' THEN '協同組合連合会'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '07' THEN '協業組合'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '08' THEN '企業組合'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '09' THEN '相互会社'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '10' THEN '社団法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '11' THEN '学校法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '12' THEN '財団法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '13' THEN '医療法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '14' THEN '社会福祉法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '15' THEN '宗教法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '17' THEN '農事組合法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '18' THEN '監査法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '19' THEN '特定非営利活動法人（ＮＰＯ法人）'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '20' THEN 'Company'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '21' THEN 'Limited'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '22' THEN 'Corporation'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '23' THEN 'Incorporated'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '24' THEN 'Company Limited'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '25' THEN '独立行政法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '26' THEN '合同会社'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '27' THEN '準学校法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '28' THEN '国立大学法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '29' THEN '公立大学法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '30' THEN '医療法人社団'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '31' THEN '医療法人財団'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '32' THEN '税理士法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '33' THEN '弁護士法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '34' THEN '有限責任中間法人'
	WHEN lcm.COMPANY_ABBREVIATED_FLAG = '35' THEN '無限責任中間法人'
	END lbc_company_abbreviated_name
, 	lcm.COMPANY_BEFORE_AFTER	lbc_company_before_after
,	CASE
		WHEN lcm.COMPANY_BEFORE_AFTER = '1' THEN '前'
		WHEN lcm.COMPANY_BEFORE_AFTER = '2' THEN '後'
		WHEN lcm.COMPANY_BEFORE_AFTER = '3' THEN '中'
		ELSE '不明'
	END lbc_company_before_after_name
, 	lcm.COMPANY_NAME	lbc_company_name
,	LBC.法人格判定(COMPANY_NAME,1)	lbc_formal_company_name
, 	lcm.OFFICE_NAME	lbc_office_name
,	IND1_L.IND_MAJORCODE	lbc_industry_code1_large
,	IND1_M.IND_CODE_MEDIUM	lbc_industry_code1_medium
,	IND1_S.IND_CODE_SMALL	lbc_industry_code1_small
,	lcm.INDUSTRY13_CODE1	lbc_industry_code1_tiny
,	IND2_L.IND_MAJORCODE	lbc_industry_code2_large
,	IND2_M.IND_CODE_MEDIUM	lbc_industry_code2_medium
,	IND2_S.IND_CODE_SMALL	lbc_industry_code2_small
,	lcm.INDUSTRY13_CODE2	lbc_industry_code2_tiny
,	IND3_L.IND_MAJORCODE	lbc_industry_code3_large
,	IND3_M.IND_CODE_MEDIUM	lbc_industry_code3_medium
,	IND3_S.IND_CODE_SMALL	lbc_industry_code3_small
,	lcm.INDUSTRY13_CODE3	lbc_industry_code3_tiny
, 	TO_CHAR(lcm.CREATE_DATE, 'YYYY/MM/DD HH24:MI:SS')	lbc_create_date
, 	TO_CHAR(NVL(lcm.UPDATE_DATE,lcm.CREATE_DATE), 'YYYY/MM/DD HH24:MI:SS')	lbc_update_date
, 	TO_CHAR(NVL(lcm.UPDATE_DATE,lcm.CREATE_DATE), 'YYYY/MM/DD HH24:MI:SS')	lbc_update_at
,	lcm.OFFICE_ID	lbc_c_office_id
,	lcm.HEAD_OFFICE_ID	lbc_c_head_office_id
,	lcm.TOP_HEAD_OFFICE_ID	lbc_c_top_head_office_id
,	lcm.TOP_AFFILIATED_OFFICE_ID1	lbc_c_top_af_office_id1
,	lcm.AFFILIATED_OFFICE_ID1	lbc_c_affiliated_office_id1
,	FELBC_TO_NUMBER(lcm.OFFICE_ID, lcm.RELATION_FLAG1)	lbc_c_relation_flag1
,	lcm.LISTED_FLAG	lbc_c_listed_code
,	lcm.SEC_CODE	lbc_c_sec_code
, 	DECODE(lcm.YUHO_NUMBER, 'E99999', NULL, lcm.YUHO_NUMBER)	lbc_c_yuho_number
, 	FELBC_GET_HYOUTEN(lcm.OFFICE_ID, lcm.HYOUTEN)	lbc_c_hyouten
, 	TO_SINGLE_BYTE(LBC.法人格判定(LBC.FNC_NORMALIZE_LBC_KEY(lcm.COMPANY_NAME), 8)) lbc_c_company_name
,	lcm.COMPANY_NAME_KANA	lbc_c_company_name_kana
, 	LBC.FNC_NORMALIZE_LBC_KEY(lcm.OFFICE_NAME)	lbc_c_office_name
, 	LBC.FNC_NORMALIZE_LBC_KEY(lcm.COMPANY_ADDR6)	lbc_c_building_name
,	lcm.COMPANY_PREF_ID	lbc_c_company_pref_id
,	lcm.COMPANY_CITY_ID	lbc_c_company_city_id
,	lcm.COMPANY_ZIP	lbc_c_company_zip
, 	REPLACE(lcm.COMPANY_TEL, '-')	lbc_c_tel
, 	REPLACE(lcm.COMPANY_FAX, '-')	lbc_c_fax
,	lcm.OFFICE_COUNT	lbc_c_office_count
, 	FELBC_GET_OFFICE_COUNT_RANGE(lcm.OFFICE_ID, lcm.OFFICE_COUNT)	lbc_c_office_count_range
,	case when length(rtrim(lcm.SETUP_DATE)) = 4 then rtrim(lcm.SETUP_DATE) || '00' ELSE rtrim(lcm.SETUP_DATE) END	lbc_c_setup_date
,	lcm.CAPITAL	lbc_c_capital
, 	FELBC_GET_CAPITAL_RANGE(lcm.OFFICE_ID, lcm.CAPITAL)	lbc_c_capital_range
,	lcm.EMPLOYEE_COUNT	lbc_c_emp_count
, 	FELBC_GET_EDIT_0BASE_RANGE(lcm.OFFICE_ID, lcm.EMP_RANGE)	lbc_c_emp_count_range
,	lcm.THISTERM_AMOUNT	lbc_c_sales
, 	FELBC_GET_EDIT_0BASE_RANGE(lcm.OFFICE_ID, lcm.SALES_RANGE)	lbc_c_sales_range
, 	SUBSTR(lcm.THISTERM_SETTLEMENT_DATE, 5, 2)	lbc_c_settlement_month
,	lcm.THISTERM_PROFIT	lbc_c_profit
, 	FELBC_GET_EDIT_0BASE_RANGE(lcm.OFFICE_ID, lcm.INCOME_RANGE)	lbc_c_profit_range
,	lcm.LICENSE	lbc_c_license
,	lcm.PARTY	lbc_c_organizations
,	lcm.INV_DATE	lbc_c_inv_date
,	FUNC_NEW_KIND_CONV(lcm.COMPANY_KIND)	LBC_C_COMPANY_KIND
, 	DECODE(lcm.URL, NULL, '0', '1')	lbc_c_has_url
, 	DECODE(lcm.FOREIGN_FLAG, 1, '1', '0')	lbc_c_has_foreign_flag
, 	DECODE(lcm.OFFICE_ID, lcm.HEAD_OFFICE_ID, '1', '0')	lbc_c_is_head_office
, 	FELBC_GET_COMPANY_STAT_C(lcm.OFFICE_ID, lcm.COMPANY_STAT, lcm.OFFICE_STAT)	lbc_c_stat_ng
, 	FELBC_GET_IS_CCNG(lcm.OFFICE_ID, lcm.COMPANY_TEL, lcm.TEL_CC_FLAG)	lbc_c_is_ccng
, 	TO_CHAR(FELBC_GET_MUJIN_OFFICE_ID(lcm.OFFICE_ID, lcm.HEAD_OFFICE_ID, lcm.COMPANY_NAME, lcm.OFFICE_NAME))	lbc_c_is_mujin_office
, 	FELBC_GET_OFFICE_CLASS_C(lcm.OFFICE_ID, lcm.HEAD_OFFICE_ID, lcm.OFFICE_CLASS)	lbc_c_office_class
, 	mm.CORPORATE_NUMBER	lbc_c_corporate_number
, 	mg.GRADE	lbc_c_grade
,	lcm.DEL_FLAG	lbc_del_flag
,	CASE WHEN lcm.COMPANY_FAX IS NOT NULL AND lcm.COMPANY_FAX NOT LIKE '0120%' AND lcm.COMPANY_FAX NOT LIKE '0_0%' AND lcm.FAX_CC_FLAG IN (0,1) THEN 1 END LBC_C_IS_FAXDM
FROM
	LBC_MST1.M_LBC lcm
, 	M_LBC_MY_NUMBER mm
, 	M_LBC_GRADE mg
, 	LBC_JIS_INDUSTRY13 IND1_L
, 	LBC_JIS_INDUSTRY13 IND1_M
, 	LBC_JIS_INDUSTRY13 IND1_S
, 	LBC_JIS_INDUSTRY13 IND2_L
, 	LBC_JIS_INDUSTRY13 IND2_M
, 	LBC_JIS_INDUSTRY13 IND2_S
, 	LBC_JIS_INDUSTRY13 IND3_L
, 	LBC_JIS_INDUSTRY13 IND3_M
, 	LBC_JIS_INDUSTRY13 IND3_S
WHERE
    lcm.HEAD_OFFICE_ID = mm.HEAD_OFFICE_ID(+)
AND lcm.HEAD_OFFICE_ID = mg.HEAD_OFFICE_ID(+)
AND lcm.INDUSTRY13_CODE1 = IND1_L.IND_CODE(+)
AND SUBSTR(lcm.INDUSTRY13_CODE1,1,2) = IND1_M.IND_CODE_MEDIUM(+)
AND SUBSTR(lcm.INDUSTRY13_CODE1,1,3) = IND1_S.IND_CODE_SMALL(+)
AND lcm.INDUSTRY13_CODE2 = IND2_L.IND_CODE(+)
AND SUBSTR(lcm.INDUSTRY13_CODE2,1,2) = IND2_M.IND_CODE_MEDIUM(+)
AND SUBSTR(lcm.INDUSTRY13_CODE2,1,3) = IND2_S.IND_CODE_SMALL(+)
AND lcm.INDUSTRY13_CODE3 = IND3_L.IND_CODE(+)
AND SUBSTR(lcm.INDUSTRY13_CODE3,1,2) = IND3_M.IND_CODE_MEDIUM(+)
AND SUBSTR(lcm.INDUSTRY13_CODE3,1,3) = IND3_S.IND_CODE_SMALL(+)
--AND TO_CHAR(UPDATE_DATE, 'YYYY/MM/DD HH24:MI:SS') >= TO_CHAR(:sql_last_value, 'YYYY/MM/DD HH24:MI:SS')
--ORDER BY UPDATE_DATE

