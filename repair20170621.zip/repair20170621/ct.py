# -*- coding: utf-8 -*-

import random
import hashlib
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil


class Ct:

    def __init__(self):

        self.ct_id = ""
        self.lbc_office_id = ""
        self.ct_gid = ""
        self.ct_uni_id3 = ""
        self.ct_category = 0
        self.ct_target_type = 0
        self.ct_action_id = 0
        self.ct_action_type = 0
        self.ct_product_ids = ""
        self.ct_action_date = ""
        self.ct_update_at = ""
        self.ct_del_flag = 0

        self.lu = landutil.LandUtil('ct')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ad_list = dr.random_date(span_list=(dr.date_span(start_year=2010, end_year=2017)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2009)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(vct.ew.header, vct.ew.count_rows):

            vct.lbc_office_id = vct.ew.get_cell_str(row=row, col=0)
            vct.ct_gid = vct.ew.get_cell_str(row=row, col=2)
            gn_count = vct.ew.get_cell_int(row=(vct.sw.case(vct.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                vct.ct_id = vct.ct_gid + "-" + vct.udi.calculation(count=i)
                vct.ct_uni_id3 = hashlib.md5(vct.ct_id + vct.lbc_office_id).hexdigest()
                vct.ct_category = vct.lu.get_nr('category')
                vct.ct_target_type = vct.lu.get_nr('target_type')
                vct.ct_action_id = vct.lu.get_nr('action_id')
                vct.ct_action_type = vct.lu.get_nr('action_type')
                vct.ct_product_ids = vct.lu.get_nr('product_ids')
                vct.ct_action_date = random.choice(vct.ad_list)
                vct.ct_update_at = random.choice(vct.ud_list)

                vct.rows.append(
                    [
                        vct.ct_id, vct.lbc_office_id, vct.ct_gid, vct.ct_uni_id3, vct.ct_category, vct.ct_target_type,
                        vct.ct_action_id, vct.ct_action_type, vct.ct_product_ids, vct.ct_action_date, vct.ct_update_at,
                        vct.ct_del_flag
                    ]
                )
        vct.cs.savedata(rows=vct.rows, name='ct', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    vct = Ct()
    vct.main()
    del vct
