# -*- coding: utf-8 -*-
"""
old version : 0.4.5 2017/06/19
old version : 0.4.0 2017/06/19
old version : 0.3.8 2017/06/19
old version : 0.3.6 2017/06/19
old version : 0.3.2 2017/06/19
old version : 0.3.0 2017/06/19
old version : 0.2.8 2017/06/19
old version : 0.2.1 2017/06/19
old version : 0.1.1 2017/06/18
old version : 0.0.1 2017/06/18
"""

__author__ = "Nobuyuki Ejiri (yukidome25@gmail.com)"
__copyright__ = "Copyright 2017, Nobuyuki Ejiri"
__license__ = "MIT"
__version__ = "0.5.0 2017/06/19"


class CorpUtil:

    def __init__(self):

        self._zero = 0
        self._one = 1
        self._two = 2
        self._three = 3
        self._four = 4
        self._five = 5
        self._six = 6
        self._nine = 9

        self._abbreviated = ""
        self._corporation_string = '株'
        self._corp_string = '株式'
        self._corporation_unicode = u'株'
        self._corp_unicode = u'株式'
        self._limited_company_string = '有'
        self._ltd_co_string = '有限'
        self._limited_company_unicode = u'有'
        self._ltd_co_unicode = u'有限'
        self._incorporated_string = '株式会社'
        self._incorporated_unicode = u'株式会社'
        self._no_incorporated_string = '法人格なし'
        self._no_incorporated_unicode = u'法人格なし'

        self._front_back_number = self._zero
        self.csn = ""
        self.cun = u""
        self._half_width_string_corporation_character = "(株)"
        self._half_width_unicode_corporation_character = u"(株)"
        self._full_width_string_corporation_character = "（株）"
        self._full_width_unicode_corporation_character = u"（株）"
        self._half_width_string_limited_company_character = "(有)"
        self._half_width_unicode_limited_company_character = u"(有)"
        self._full_width_string_limited_company_character = "（有）"
        self._full_width_unicode_limited_company_character = u"（有）"

        self._check_name = ""
        self._unknown_string_name = "不明"
        self._unknown_unicode_name = u"不明"
        self._front_string_name = "前"
        self._front_unicode_name = u"前"
        self._back_string_name = "後"
        self._back_unicode_name = u"後"

    def check_corporation(self, company_name):

        self._abbreviated = ""
        if self.__check_type_string(company_name):
            if self.__search_string_corporation_incorporated(company_name):
                self._abbreviated = self._incorporated_string
            else:
                self._abbreviated = self._no_incorporated_string
        elif self.__check_type_unicode(company_name):
            if self.__search_unicode_corporation_incorporated(company_name):
                self._abbreviated = self._incorporated_unicode
            else:
                self._abbreviated = self._no_incorporated_unicode

        return self._abbreviated

    def check_corporation_number(self, company_name):

        self._front_back_number = self._zero
        self._front_back_number = self.__search_frontward(company_name)
        if self._front_back_number is not self._one:
            self._front_back_number = self.__search_backward(company_name)

        return self._front_back_number

    def check_corporation_name(self, company_name, front_back_number):

        self._check_name = ""
        if self.__check_type_string(company_name):
            self._check_name = self.__corporation_string_case().get(front_back_number)
        elif self.__check_type_unicode(company_name):
            self._check_name = self.__corporation_unicode_case().get(front_back_number)

        return self._check_name

    def __corporation_unicode_case(self):

        switch = {
            self._zero: self._unknown_unicode_name,
            self._one: self._front_unicode_name,
            self._two: self._back_unicode_name
        }

        return switch

    def __corporation_string_case(self):

        switch = {
            self._zero: self._unknown_string_name,
            self._one: self._front_string_name,
            self._two: self._back_string_name
        }

        return switch

    def __search_unicode_corporation_incorporated(self, company_name):

        if self._corp_unicode in company_name \
                or self._half_width_unicode_corporation_character in company_name \
                or self._full_width_unicode_corporation_character in company_name:
                return True
        elif self._ltd_co_unicode in company_name \
                or self._half_width_unicode_limited_company_character in company_name \
                or self._full_width_unicode_limited_company_character in company_name:
                return True

        return False

    def __search_string_corporation_incorporated(self, company_name):

        if self._corp_string in company_name \
                or self._half_width_string_corporation_character in company_name \
                or self._full_width_string_corporation_character in company_name:
                return True
        elif self._ltd_co_string in company_name \
                or self._half_width_string_limited_company_character in company_name \
                or self._full_width_string_limited_company_character in company_name:
                return True

        return False

    def __search_backward_unicode_checker(self, check_int, company_name):

        check_half_corp_char = u""
        check_full_corp_char = u""
        check_corp_name = u""
        if check_int is self._zero:
            check_half_corp_char = self._half_width_unicode_corporation_character
            check_full_corp_char = self._full_width_unicode_corporation_character
            check_corp_name = self._corporation_unicode
        elif check_int is self._one:
            check_half_corp_char = self._half_width_unicode_limited_company_character
            check_full_corp_char = self._full_width_unicode_limited_company_character
            check_corp_name = self._limited_company_unicode

        self.cun = u""
        self.cun = company_name.rstrip()
        word_len = len(self.cun)
        if self.cun.endswith(check_half_corp_char, word_len - self._three, word_len):
            _end_uh_position = word_len - self._one
            _start_uh_position = _end_uh_position - self._one
            if self.cun.endswith(check_corp_name, _start_uh_position, _end_uh_position):
                self._front_back_number = self._two
        elif self.cun.endswith(check_full_corp_char, word_len - self._three, word_len):
            _end_uh_position = word_len - self._one
            _start_uh_position = _end_uh_position - self._one
            if self.cun.endswith(check_corp_name, _start_uh_position, _end_uh_position):
                self._front_back_number = self._two

        return self._front_back_number

    def __search_backward_string_checker(self, check_int, company_name):

        check_half_corp_char = ""
        check_full_corp_char = ""
        check_corp_name = ""
        if check_int is self._zero:
            check_half_corp_char = self._half_width_string_corporation_character
            check_full_corp_char = self._full_width_string_corporation_character
            check_corp_name = self._corporation_string
        elif check_int is self._one:
            check_half_corp_char = self._half_width_string_limited_company_character
            check_full_corp_char = self._full_width_string_limited_company_character
            check_corp_name = self._limited_company_string

        self.csn = ""
        self.csn = company_name.rstrip()
        word_len = len(self.csn)
        if self.csn.endswith(check_half_corp_char, word_len - self._five, word_len):
            _end_h_position = word_len - self._one
            _start_h_position = _end_h_position - self._three
            if self.csn.endswith(check_corp_name, _start_h_position, _end_h_position):
                self._front_back_number = self._two
        elif self.csn.endswith(check_full_corp_char, word_len - self._nine, word_len):
            _end_f_position = word_len - self._three
            _start_f_position = _end_f_position - self._three
            if self.csn.endswith(check_corp_name, _start_f_position, _end_f_position):
                self._front_back_number = self._two

        return self._front_back_number

    def __search_backward_unicode_limited_company(self, company_name):

        if self.__search_unicode_corporation_incorporated(company_name):
            self._front_back_number = self.__search_backward_unicode_checker(self._one, company_name)

        return self._front_back_number

    def __search_backward_string_limited_company(self, company_name):

        if self.__search_string_corporation_incorporated(company_name):
            self._front_back_number = self.__search_backward_string_checker(self._one, company_name)

        return self._front_back_number

    def __search_backward_unicode_corporation(self, company_name):

        if self.__search_unicode_corporation_incorporated(company_name):
            self._front_back_number = self.__search_backward_unicode_checker(self._zero, company_name)

        return self._front_back_number

    def __search_backward_string_corporation(self, company_name):

        if self.__search_string_corporation_incorporated(company_name):
            self._front_back_number = self.__search_backward_string_checker(self._zero, company_name)

        return self._front_back_number

    def __search_backward(self, company_name):

        if self.__check_type_string(company_name):

            self._front_back_number = self.__search_backward_string_corporation(company_name)
            self._front_back_number = self.__search_backward_string_limited_company(company_name)

        elif self.__check_type_unicode(company_name):

            self._front_back_number = self.__search_backward_unicode_corporation(company_name)
            self._front_back_number = self.__search_backward_unicode_limited_company(company_name)

        return self._front_back_number

    def __search_frontward_unicode_checker(self, check_int, company_name):

        check_half_corp_char = u""
        check_full_corp_char = u""
        check_corp_name = u""
        if check_int is self._zero:
            check_half_corp_char = self._half_width_unicode_corporation_character
            check_full_corp_char = self._full_width_unicode_corporation_character
            check_corp_name = self._corporation_unicode
        elif check_int is self._one:
            check_half_corp_char = self._half_width_unicode_limited_company_character
            check_full_corp_char = self._full_width_unicode_limited_company_character
            check_corp_name = self._limited_company_unicode

        self.cun = u""
        self.cun = company_name.lstrip()
        if self.cun.startswith(check_half_corp_char, self._zero, self._three):
            if self.cun.startswith(check_corp_name, self._one, self._two):
                self._front_back_number = self._one
        elif self.cun.startswith(check_full_corp_char, self._zero, self._three):
            if self.cun.startswith(check_corp_name, self._one, self._two):
                self._front_back_number = self._one

        return self._front_back_number

    def __search_frontward_string_checker(self, check_int, company_name):

        check_half_corp_char = ""
        check_full_corp_char = ""
        check_corp_name = ""
        if check_int is self._zero:
            check_half_corp_char = self._half_width_string_corporation_character
            check_full_corp_char = self._full_width_string_corporation_character
            check_corp_name = self._corporation_string
        elif check_int is self._one:
            check_half_corp_char = self._half_width_string_limited_company_character
            check_full_corp_char = self._full_width_string_limited_company_character
            check_corp_name = self._limited_company_string

        self.csn = ""
        self.csn = company_name.lstrip()
        if self.csn.startswith(check_half_corp_char, self._zero, self._five):
            if self.csn.startswith(check_corp_name, self._one, self._four):
                self._front_back_number = self._one
        elif self.csn.startswith(check_full_corp_char, self._zero, self._nine):
            if self.csn.startswith(check_corp_name, self._three, self._six):
                self._front_back_number = self._one

        return self._front_back_number

    def __search_frontward_unicode_limited_company(self, company_name):

        if self.__search_unicode_corporation_incorporated(company_name):
            self._front_back_number = self.__search_frontward_unicode_checker(self._one, company_name)

        return self._front_back_number

    def __search_frontward_string_limited_company(self, company_name):

        if self.__search_string_corporation_incorporated(company_name):
            self._front_back_number = self.__search_frontward_string_checker(self._one, company_name)

        return self._front_back_number

    def __search_frontward_unicode_corporation(self, company_name):

        if self.__search_unicode_corporation_incorporated(company_name):
            self._front_back_number = self.__search_frontward_unicode_checker(self._zero, company_name)

        return self._front_back_number

    def __search_frontward_string_corporation(self, company_name):

        if self.__search_string_corporation_incorporated(company_name):
            self._front_back_number = self.__search_frontward_string_checker(self._zero, company_name)

        return self._front_back_number

    def __search_frontward(self, company_name):

        if self.__check_type_string(company_name):

            self._front_back_number = self.__search_frontward_string_corporation(company_name)
            self._front_back_number = self.__search_frontward_string_limited_company(company_name)

        elif self.__check_type_unicode(company_name):

            self._front_back_number = self.__search_frontward_unicode_corporation(company_name)
            self._front_back_number = self.__search_frontward_unicode_limited_company(company_name)

        return self._front_back_number

    @staticmethod
    def __check_type_unicode(company_name):
        return isinstance(company_name, unicode)

    @staticmethod
    def __check_type_string(company_name):
        return isinstance(company_name, str)
