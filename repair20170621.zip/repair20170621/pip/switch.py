# -*- coding: utf-8 -*-
"""
old version : 0.1.0 2017/06/16
old version : 0.0.1 2017/06/11
"""

__author__ = "Nobuyuki Ejiri (yukidome25@gmail.com)"
__copyright__ = "Copyright 2017, Nobuyuki Ejiri"
__license__ = "MIT"
__version__ = "0.1.1 2017/06/19"


class Switch:

    def __init__(self, generator_words):

        self.word_list = generator_words
        self.s = {}
        self.pairs = []
        self.s = dict(self.__generator())

    def get_generator_words(self):

        return self.word_list

    def case(self, char):

        return self.s.get(char)

    def __generator(self):

        for i in xrange(len(self.word_list)):

            a = self.word_list[i]
            b = i + 1
            pair = (a, b)
            self.pairs.append(pair)

        return self.pairs
