# -*- coding: utf-8 -*-

import yaml
# from collections import OrderedDict


class SampleCase:

    def __init__(self, index):
        """
        yaml.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
                             lambda loader, node: OrderedDict(loader.construct_pairs(node)))
        """
        self.yf = open('./data/sample_data.yml').read()
        self.yf = self.yf.decode('utf-8')

        self.yd = yaml.load(self.yf)

        self.index = index

    def get_data(self, word):

        for i in self.yd.get(self.index):
            # in is definitely more pythonic and high speed
            # dict.has_key() removed in Python 3.x. and low speed
            if word in i:
                return i.get(word)

        return False
