# -*- coding: utf-8 -*-
"""
old version : 0.0.1 2017/06/15
"""

__author__ = "Nobuyuki Ejiri (yukidome25@gmail.com)"
__copyright__ = "Copyright 2017, Nobuyuki Ejiri"
__license__ = "MIT"
__version__ = "0.0.2 2017/06/19"


class UnderId:

    def __init__(self):

        self.one = 1
        self._id = 0
        self.sid = 10000000000

    def calculation(self, count=''):

        self._id += (int(count) + self.one) - int(count)
        return str(self.sid + self._id)
