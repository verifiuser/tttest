# -*- coding: utf-8 -*-
"""
old version : 0.0.1 2017/06/11
"""
import datetime
import random

__author__ = "Nobuyuki Ejiri (yukidome25@gmail.com)"
__copyright__ = "Copyright 2017, Nobuyuki Ejiri"
__license__ = "MIT"
__version__ = "0.0.2 2017/06/16"


class DataRange:

    def __init__(self):
        pass

    @staticmethod
    def date_span(start_year="", end_year=""):

        start_date = datetime.date(int(start_year), 1, 1)
        end_date = datetime.date(int(end_year), 1, 1)
        date_span_list = []

        for n in xrange((end_date - start_date).days + 1):

            date_span_list.append(start_date + datetime.timedelta(n))

        return date_span_list

    @staticmethod
    def random_date_time(span_list=""):

        date_list = []

        for date in span_list:

            date_list.append(datetime.datetime(
                int(date.strftime('%Y')),
                int(date.strftime('%m')),
                int(date.strftime('%d')),
                hour=random.randint(0, 23),
                minute=random.randint(0, 59),
                second=random.randint(0, 59)
            ).strftime('%Y/%m/%d %H:%M:%S'))

        return date_list

    @staticmethod
    def random_date(span_list=""):

        date_list = []

        for date in span_list:

            date_list.append(datetime.datetime(
                int(date.strftime('%Y')),
                int(date.strftime('%m')),
                int(date.strftime('%d'))
            ).strftime('%Y%m%d'))

        return date_list

    @staticmethod
    def random_date_ym(span_list=""):

        date_list = []

        for date in span_list:

            date_list.append(datetime.datetime(
                int(date.strftime('%Y')),
                int(date.strftime('%m')),
                int(date.strftime('%d'))
            ).strftime('%Y%m'))

        return date_list
