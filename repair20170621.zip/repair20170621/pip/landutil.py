# -*- coding: utf-8 -*-

import samplecase
import numpy


class LandUtil:

    def __init__(self, index):

        self.index = index
        self.l = []
        self.sc = samplecase.SampleCase(self.index)

    def get_nr(self, word):
        # <type 'numpy.string_'>
        return str(numpy.random.choice(self.sc.get_data(word)))

    def get_calc(self, word):
        # if len(self.l) is 0:
        #    [self.l.append(i) for i in xrange(int(self.sc.get_data(word)[0]), int(self.sc.get_data(word)[1]) + 1)]
        # return numpy.random.choice(self.l)
        # <type 'int'>
        return numpy.random.randint(int(self.sc.get_data(word)[0]), int(self.sc.get_data(word)[1]))
