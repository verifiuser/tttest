# -*- coding: utf-8 -*-
"""
old version : 0.1.0 2017/06/17
old version : 0.0.1 2017/06/17
"""
import xlrd
import sys

__author__ = "Nobuyuki Ejiri (yukidome25@gmail.com)"
__copyright__ = "Copyright 2017, Nobuyuki Ejiri"
__license__ = "MIT"
__version__ = "0.1.5 2017/06/17"

reload(sys)
sys.setdefaultencoding('utf-8')


class ExcelWrapper:

    def __init__(self, target_file, sheet_number):

        self._tf = target_file
        self._sn = sheet_number
        self._l = []
        self._b = self.__open_book()
        self._ss = self.__open_sheets()
        self._s = self.__open_sheet()

        self.header = 1

        self.sheet_name = self.__all_sheet_name()
        self.count_sheets = self.__count_sheet()
        self.count_cols = self.__count_col()
        self.count_rows = self.__count_row()

    def sheet_information(self):

        for i in xrange(self.__count_sheet()):

            si = self._b.sheet_by_index(i)
            self._l.append('{} has {} rows and {} cols'.format(si.name, si.nrows, si.ncols))

        return self._l

    def get_cell_str(self, row='', col=''):

        return self.__type_convert_string(self._s.cell(row, col).value)

    def get_cell_int(self, row='', col=''):

        return self.__type_convert_integer(self._s.cell(row, col).value)

    @staticmethod
    def __type_convert_string(value):

        if isinstance(value, float):

            value = int(value)

        return str(value)

    @staticmethod
    def __type_convert_integer(value):

        return int(value)

    def __count_row(self):

        return self._s.nrows

    def __count_col(self):

        return self._s.ncols

    def __open_sheet(self):

        return self._ss[self._sn]

    def __open_sheets(self):

        return self._b.sheets()

    def __count_sheet(self):

        return self._b.nsheets

    def __all_sheet_name(self):

        return self._b.sheet_names()

    def __open_book(self):

        return xlrd.open_workbook(self._tf)
