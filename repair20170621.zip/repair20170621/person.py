# -*- coding: utf-8 -*-

import random
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil


class Person:

    def __init__(self):

        self.person_id = ""
        self.person_uni_id3 = ""
        self.lbc_office_id = ""
        self.person_gid = ""
        self.person_busho = ""
        self.person_yakushoku = ""
        self.person_keyman_flag = 0
        self.person_eps_flag = 0
        self.person_fps_flag = ""
        self.person_tps_flag = ""
        self.person_mps_flag = ""
        self.person_email = ""
        self.person_member_name = ""
        self.person_tanto_name = ""
        self.person_hiragana_flag = ""
        self.person_katakana_flag = ""
        self.person_update_at = ""
        self.person_del_flag = 0

        self.lu = landutil.LandUtil('person')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2009)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mp.ew.header, mp.ew.count_rows):

            mp.lbc_office_id = mp.ew.get_cell_str(row=row, col=0)
            mp.person_gid = mp.ew.get_cell_str(row=row, col=2)
            gn_count = mp.ew.get_cell_int(row=(mp.sw.case(mp.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                mp.person_uni_id3 = mp.udi.calculation(count=i)
                mp.person_id = mp.person_gid + "-" + mp.person_uni_id3
                mp.person_busho = mp.lu.get_nr('busho')
                mp.person_yakushoku = mp.lu.get_nr('yakushoku')
                mp.person_keyman_flag = mp.lu.get_nr('keyman_flag')
                mp.person_eps_flag = mp.lu.get_nr('eps_flag')
                mp.person_email = mp.lu.get_nr('email')
                mp.person_member_name = mp.lu.get_nr('member_name')
                mp.person_update_at = random.choice(mp.ud_list)

                mp.rows.append(
                    [
                        mp.person_id, mp.person_uni_id3, mp.lbc_office_id, mp.person_gid, mp.person_busho,
                        mp.person_yakushoku, mp.person_keyman_flag, mp.person_eps_flag, mp.person_fps_flag,
                        mp.person_tps_flag, mp.person_mps_flag, mp.person_email, mp.person_member_name,
                        mp.person_tanto_name, mp.person_hiragana_flag, mp.person_katakana_flag, mp.person_update_at,
                        mp.person_del_flag
                    ]
                )
        mp.cs.savedata(rows=mp.rows, name='person', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mp = Person()
    mp.main()
    del mp
