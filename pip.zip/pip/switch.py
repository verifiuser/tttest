# -*- coding: utf-8 -*-

__author__ = "Nobuyuki Ejiri (yukidome25@gmail.com)"
__copyright__ = "Copyright 2017, Nobuyuki Ejiri"
__license__ = "MIT"
__version__ = "0.01"


class Switch:
    def __init__(self):
        pass

    @staticmethod
    def case(char):
        switch = {
            'A': 1,
            'B': 2,
            'C': 3,
            'D': 4
        }
        return switch.get(char)
