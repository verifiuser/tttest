# -*- coding: utf-8 -*-

import datetime
import random

__author__ = "Nobuyuki Ejiri (yukidome25@gmail.com)"
__copyright__ = "Copyright 2017, Nobuyuki Ejiri"
__license__ = "MIT"
__version__ = "0.01"


class DataRange:
    def __init__(self):
        pass

    @staticmethod
    def date_span(yearbefore="", yearafter=""):
        start_date = datetime.date(yearbefore, 1, 1)
        end_date = datetime.date(yearafter, 1, 1)
        date_span_list = []
        for n in xrange((end_date - start_date).days + 1):
            date_span_list.append(start_date + datetime.timedelta(n))
        return date_span_list


class RandomDataTime:
    def __init__(self):
        pass

    @staticmethod
    def date_span(datelist=""):
        date_list = []
        for date in datelist:
            date_list.append(datetime.datetime(
                int(date.strftime('%Y')),
                int(date.strftime('%m')),
                int(date.strftime('%d')),
                hour=random.randint(0, 23),
                minute=random.randint(0, 59),
                second=random.randint(0, 59)
            ).strftime('%Y/%m/%d %H:%M:%S'))
        return date_list


class RandomData:
    def __init__(self):
        pass

    @staticmethod
    def date_span(datelist=""):
        date_list = []
        for date in datelist:
            date_list.append(datetime.datetime(
                int(date.strftime('%Y')),
                int(date.strftime('%m')),
                int(date.strftime('%d'))
            ).strftime('%Y%m%d'))
        return date_list


class RandomDataYM:
    def __init__(self):
        pass

    @staticmethod
    def date_span(datelist=""):
        date_list = []
        for date in datelist:
            date_list.append(datetime.datetime(
                int(date.strftime('%Y')),
                int(date.strftime('%m')),
                int(date.strftime('%d'))
            ).strftime('%Y%m'))
        return date_list
