# -*- coding: utf-8 -*-

__version__ = "1.0.0"


class BizItem:

    def __init__(self):

        self._id = None
        self._office_id = None
        self._gid = None
        self._status = None
        self._product = None
        self._price = 0
        self._probability = 0
        self._end_date = None
        self._update_at = None
        self._del_flag = 0

    @property
    def id(self):
        pass

    @property
    def office_id(self):
        pass

    @property
    def gid(self):
        pass

    @property
    def status(self):
        pass

    @property
    def product(self):
        pass

    @property
    def price(self):
        pass

    @property
    def probability(self):
        pass

    @property
    def end_date(self):
        pass

    @property
    def update_at(self):
        pass

    @property
    def del_flag(self):
        pass

    @id.getter
    def id(self):
        return self._id

    @office_id.getter
    def office_id(self):
        return self._office_id

    @gid.getter
    def gid(self):
        return self._gid

    @status.getter
    def status(self):
        return self._status

    @product.getter
    def product(self):
        return self._product

    @price.getter
    def price(self):
        return self._price

    @probability.getter
    def probability(self):
        return self._probability

    @end_date.getter
    def end_date(self):
        return self._end_date

    @update_at.getter
    def update_at(self):
        return self._update_at

    @del_flag.getter
    def del_flag(self):
        return self._del_flag

    @id.setter
    def id(self, value):
        self._id = value

    @office_id.setter
    def office_id(self, value):
        self._office_id = value

    @gid.setter
    def gid(self, value):
        self._office_id = value

    @status.setter
    def status(self, value):
        self._status = value

    @product.setter
    def product(self, value):
        self._product = value

    @price.setter
    def price(self, value):
        self._price = value

    @probability.setter
    def probability(self, value):
        self._probability = value

    @end_date.setter
    def end_date(self, value):
        self._end_date = value

    @update_at.setter
    def update_at(self, value):
        self._update_at = value

    @del_flag.setter
    def del_flag(self, value):
        self._del_flag = value

    @id.deleter
    def id(self):
        del self._id

    @office_id.deleter
    def office_id(self):
        del self._office_id

    @gid.deleter
    def gid(self):
        del self._gid

    @status.deleter
    def status(self):
        del self._status

    @product.deleter
    def product(self):
        del self._product

    @price.deleter
    def price(self):
        del self._price

    @probability.deleter
    def probability(self):
        del self._probability

    @end_date.deleter
    def end_date(self):
        del self._end_date

    @update_at.deleter
    def update_at(self):
        del self._update_at

    @del_flag.deleter
    def del_flag(self):
        del self._del_flag
