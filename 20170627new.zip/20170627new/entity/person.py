# -*- coding: utf-8 -*-

__version__ = "1.0.0"


class Person:

    def __init__(self):

        self._id = None
        self._uni_id3 = None
        self._office_id = None
        self._gid = None
        self._busho = None
        self._yakushoku = None
        self._keyman_flag = 0
        self._eps_flag = 0
        self._fps_flag = None
        self._tps_flag = None
        self._mps_flag = None
        self._email = None
        self._member_name = None
        self._tanto_name = None
        self._hiragana_flag = None
        self._katakana_flag = None
        self._update_at = None
        self._del_flag = 0

    @property
    def id(self):
        pass

    @property
    def uni_id3(self):
        pass

    @property
    def office_id(self):
        pass

    @property
    def gid(self):
        pass

    @property
    def busho(self):
        pass

    @property
    def yakushoku(self):
        pass

    @property
    def keyman_flag(self):
        pass

    @property
    def eps_flag(self):
        pass

    @property
    def fps_flag(self):
        pass

    @property
    def tps_flag(self):
        pass

    @property
    def mps_flag(self):
        pass

    @property
    def email(self):
        pass

    @property
    def member_name(self):
        pass

    @property
    def tanto_name(self):
        pass

    @property
    def hiragana_flag(self):
        pass

    @property
    def katakana_flag(self):
        pass

    @property
    def update_at(self):
        pass

    @property
    def del_flag(self):
        pass

    @id.getter
    def id(self):
        return self._id

    @uni_id3.getter
    def uni_id3(self):
        return self._uni_id3

    @office_id.getter
    def office_id(self):
        return self._office_id

    @gid.getter
    def gid(self):
        return self._gid

    @busho.getter
    def busho(self):
        return self._busho

    @yakushoku.getter
    def yakushoku(self):
        return self._yakushoku

    @keyman_flag.getter
    def keyman_flag(self):
        return self._keyman_flag

    @eps_flag.getter
    def eps_flag(self):
        return self._eps_flag

    @fps_flag.getter
    def fps_flag(self):
        return self._fps_flag

    @tps_flag.getter
    def tps_flag(self):
        return self._tps_flag

    @mps_flag.getter
    def mps_flag(self):
        return self._mps_flag

    @email.getter
    def email(self):
        return self._email

    @member_name.getter
    def member_name(self):
        return self._member_name

    @tanto_name.getter
    def tanto_name(self):
        return self._tanto_name

    @hiragana_flag.getter
    def hiragana_flag(self):
        return self._hiragana_flag

    @katakana_flag.getter
    def katakana_flag(self):
        return self._katakana_flag

    @update_at.getter
    def update_at(self):
        return self._update_at

    @del_flag.getter
    def del_flag(self):
        return self._del_flag

    @id.setter
    def id(self, value):
        self._id = value

    @uni_id3.setter
    def uni_id3(self, value):
        self._uni_id3 = value

    @office_id.setter
    def office_id(self, value):
        self._office_id = value

    @gid.setter
    def gid(self, value):
        self._gid = value

    @busho.setter
    def busho(self, value):
        self._busho = value

    @yakushoku.setter
    def yakushoku(self, value):
        self._yakushoku = value

    @keyman_flag.setter
    def keyman_flag(self, value):
        self._keyman_flag = value

    @eps_flag.setter
    def eps_flag(self, value):
        self._eps_flag = value

    @fps_flag.setter
    def fps_flag(self, value):
        self._fps_flag = value

    @tps_flag.setter
    def tps_flag(self, value):
        self._tps_flag = value

    @mps_flag.setter
    def mps_flag(self, value):
        self._mps_flag = value

    @email.setter
    def email(self, value):
        self._email = value

    @member_name.setter
    def member_name(self, value):
        self._member_name = value

    @tanto_name.setter
    def tanto_name(self, value):
        self._tanto_name = value

    @hiragana_flag.setter
    def hiragana_flag(self, value):
        self._hiragana_flag = value

    @katakana_flag.setter
    def katakana_flag(self, value):
        self._katakana_flag = value

    @update_at.setter
    def update_at(self, value):
        self._update_at = value

    @del_flag.setter
    def del_flag(self, value):
        self._del_flag = value

    @id.deleter
    def id(self):
        del self._id

    @uni_id3.deleter
    def uni_id3(self):
        del self._uni_id3

    @office_id.deleter
    def office_id(self):
        del self._office_id

    @gid.deleter
    def gid(self):
        del self._gid

    @busho.deleter
    def busho(self):
        del self._busho

    @yakushoku.deleter
    def yakushoku(self):
        del self._yakushoku

    @keyman_flag.deleter
    def keyman_flag(self):
        del self._keyman_flag

    @eps_flag.deleter
    def eps_flag(self):
        del self._eps_flag

    @fps_flag.deleter
    def fps_flag(self):
        del self._fps_flag

    @tps_flag.deleter
    def tps_flag(self):
        del self._tps_flag

    @mps_flag.deleter
    def mps_flag(self):
        del self._mps_flag

    @email.deleter
    def email(self):
        del self._email

    @member_name.deleter
    def member_name(self):
        del self._member_name

    @tanto_name.deleter
    def tanto_name(self):
        del self._tanto_name

    @hiragana_flag.deleter
    def hiragana_flag(self):
        del self._hiragana_flag

    @katakana_flag.deleter
    def katakana_flag(self):
        del self._katakana_flag

    @update_at.deleter
    def update_at(self):
        del self._update_at

    @del_flag.deleter
    def del_flag(self):
        del self._del_flag
