# -*- coding: utf-8 -*-

__version__ = "1.0.0"


class Deal:

    def __init__(self):

        self._status_id = None
        self._office_id = None
        self._deal_flag = 0
        self._gid = None
        self._update_at = None
        self._del_flag = 0

    @property
    def status_id(self):
        pass

    @property
    def office_id(self):
        pass

    @property
    def deal_flag(self):
        pass

    @property
    def gid(self):
        pass

    @property
    def update_at(self):
        pass

    @property
    def del_flag(self):
        pass

    @status_id.getter
    def status_id(self):
        return self._status_id

    @office_id.getter
    def office_id(self):
        return self._office_id

    @deal_flag.getter
    def deal_flag(self):
        return self._deal_flag

    @gid.getter
    def gid(self):
        return self._gid

    @update_at.getter
    def update_at(self):
        return self._update_at

    @del_flag.getter
    def del_flag(self):
        return self._del_flag

    @status_id.setter
    def status_id(self, value):
        self._status_id = value

    @office_id.setter
    def office_id(self, value):
        self._office_id = value

    @deal_flag.setter
    def deal_flag(self, value):
        self._deal_flag = value

    @gid.setter
    def gid(self, value):
        self._gid = value

    @update_at.setter
    def update_at(self, value):
        self._update_at = value

    @del_flag.setter
    def del_flag(self, value):
        self._del_flag = value

    @status_id.deleter
    def status_id(self):
        del self._status_id

    @office_id.deleter
    def office_id(self):
        del self._office_id

    @deal_flag.deleter
    def deal_flag(self):
        del self._deal_flag

    @gid.deleter
    def gid(self):
        del self._gid

    @update_at.deleter
    def update_at(self):
        del self._update_at

    @del_flag.deleter
    def del_flag(self):
        del self._del_flag
