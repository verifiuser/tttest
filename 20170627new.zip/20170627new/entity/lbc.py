# -*- coding: utf-8 -*-

__version__ = "1.0.0"


class Lbc:

    def __init__(self):

        self._gid = None
        self._office_id = None
        self._company_abbreviated_flag = None
        self._company_abbreviated_name = None
        self._company_before_after = 0
        self._company_before_after_name = None
        self._company_name = None
        self._formal_company_name = None
        self._office_name = None
        self._industry_code1_large = None
        self._industry_code1_medium = None
        self._industry_code1_small = None
        self._industry_code1_tiny = None
        self._industry_code2_large = None
        self._industry_code2_medium = None
        self._industry_code2_small = None
        self._industry_code2_tiny = None
        self._industry_code3_large = None
        self._industry_code3_medium = None
        self._industry_code3_small = None
        self._industry_code3_tiny = None
        self._create_date = None
        self._update_date = None
        self._update_at = None
        self._c_office_id = None
        self._c_head_office_id = None
        self._c_top_head_office_id = None
        self._c_top_af_office_id1 = None
        self._c_affiliated_office_id1 = None
        self._c_relation_flag1 = None
        self._c_listed_code = 0
        self._c_sec_code = None
        self._c_yuho_number = None
        self._c_hyouten = 0
        self._c_company_name = None
        self._c_company_name_kana = None
        self._c_office_name = None
        self._c_building_name = None
        self._c_company_pref_id = None
        self._c_company_city_id = None
        self._c_company_zip = None
        self._c_tel = None
        self._c_fax = None
        self._c_office_count = None
        self._c_office_count_range = 0
        self._c_setup_date = None
        self._c_capital = None
        self._c_capital_range = 0
        self._c_emp_count = None
        self._c_emp_count_range = 0
        self._c_sales = None
        self._c_sales_range = 0
        self._c_settlement_month = None
        self._c_profit = None
        self._c_profit_range = 0
        self._c_license = None
        self._c_organizations = None
        self._c_inv_date = None
        self._c_company_kind = 0
        self._c_has_url = 0
        self._c_has_foreign_flag = 0
        self._c_is_head_office = 0
        self._c_stat_ng = 0
        self._c_is_ccng = 0
        self._c_is_mujin_office = 0
        self._c_office_class = 0
        self._c_corporate_number = None
        self._c_grade = None
        self._del_flag = 0
        self._c_is_faxdm = None

    @property
    def gid(self):
        pass

    @property
    def office_id(self):
        pass

    @property
    def company_abbreviated_flag(self):
        pass

    @property
    def company_abbreviated_name(self):
        pass

    @property
    def company_before_after(self):
        pass

    @property
    def company_before_after_name(self):
        pass

    @property
    def company_name(self):
        pass

    @property
    def formal_company_name(self):
        pass

    @property
    def office_name(self):
        pass

    @property
    def industry_code1_large(self):
        pass

    @property
    def industry_code1_medium(self):
        pass

    @property
    def industry_code1_small(self):
        pass

    @property
    def industry_code1_tiny(self):
        pass

    @property
    def industry_code2_large(self):
        pass

    @property
    def industry_code2_medium(self):
        pass

    @property
    def industry_code2_small(self):
        pass

    @property
    def industry_code2_tiny(self):
        pass

    @property
    def industry_code3_large(self):
        pass

    @property
    def industry_code3_medium(self):
        pass

    @property
    def industry_code3_small(self):
        pass

    @property
    def industry_code3_tiny(self):
        pass

    @property
    def create_date(self):
        pass

    @property
    def update_date(self):
        pass

    @property
    def update_at(self):
        pass

    @property
    def c_office_id(self):
        pass

    @property
    def c_head_office_id(self):
        pass

    @property
    def c_top_head_office_id(self):
        pass

    @property
    def c_top_af_office_id1(self):
        pass

    @property
    def c_affiliated_office_id1(self):
        pass

    @property
    def c_relation_flag1(self):
        pass

    @property
    def c_listed_code(self):
        pass

    @property
    def c_sec_code(self):
        pass

    @property
    def c_yuho_number(self):
        pass

    @property
    def c_hyouten(self):
        pass

    @property
    def c_company_name(self):
        pass

    @property
    def c_company_name_kana(self):
        pass

    @property
    def c_office_name(self):
        pass

    @property
    def c_building_name(self):
        pass

    @property
    def c_company_pref_id(self):
        pass

    @property
    def c_company_city_id(self):
        pass

    @property
    def c_company_zip(self):
        pass

    @property
    def c_tel(self):
        pass

    @property
    def c_fax(self):
        pass

    @property
    def c_office_count(self):
        pass

    @property
    def c_office_count_range(self):
        pass

    @property
    def c_setup_date(self):
        pass

    @property
    def c_capital(self):
        pass

    @property
    def c_capital_range(self):
        pass

    @property
    def c_emp_count(self):
        pass

    @property
    def c_emp_count_range(self):
        pass

    @property
    def c_sales(self):
        pass

    @property
    def c_sales_range(self):
        pass

    @property
    def c_settlement_month(self):
        pass

    @property
    def c_profit(self):
        pass

    @property
    def c_profit_range(self):
        pass

    @property
    def c_license(self):
        pass

    @property
    def c_organizations(self):
        pass

    @property
    def c_inv_date(self):
        pass

    @property
    def c_company_kind(self):
        pass

    @property
    def c_has_url(self):
        pass

    @property
    def c_has_foreign_flag(self):
        pass

    @property
    def c_is_head_office(self):
        pass

    @property
    def c_stat_ng(self):
        pass

    @property
    def c_is_ccng(self):
        pass

    @property
    def c_is_mujin_office(self):
        pass

    @property
    def c_office_class(self):
        pass

    @property
    def c_corporate_number(self):
        pass

    @property
    def c_grade(self):
        pass

    @property
    def del_flag(self):
        pass

    @property
    def c_is_faxdm(self):
        pass

    @gid.getter
    def gid(self):
        return self._gid

    @office_id.getter
    def office_id(self):
        return self._office_id

    @company_abbreviated_flag.getter
    def company_abbreviated_flag(self):
        return self._company_abbreviated_flag

    @company_abbreviated_name.getter
    def company_abbreviated_name(self):
        return self._company_abbreviated_name

    @company_before_after.getter
    def company_before_after(self):
        return self._company_before_after

    @company_before_after_name.getter
    def company_before_after_name(self):
        return self._company_before_after_name

    @company_name.getter
    def company_name(self):
        return self._company_name

    @formal_company_name.getter
    def formal_company_name(self):
        return self._formal_company_name

    @office_name.getter
    def office_name(self):
        return self._office_name

    @industry_code1_large.getter
    def industry_code1_large(self):
        return self._industry_code1_large

    @industry_code1_medium.getter
    def industry_code1_medium(self):
        return self._industry_code1_medium

    @industry_code1_small.getter
    def industry_code1_small(self):
        return self._industry_code1_small

    @industry_code1_tiny.getter
    def industry_code1_tiny(self):
        return self._industry_code1_tiny

    @industry_code2_large.getter
    def industry_code2_large(self):
        return self._industry_code2_large

    @industry_code2_medium.getter
    def industry_code2_medium(self):
        return self._industry_code2_medium

    @industry_code2_small.getter
    def industry_code2_small(self):
        return self._industry_code2_small

    @industry_code2_tiny.getter
    def industry_code2_tiny(self):
        return self._industry_code2_tiny

    @industry_code3_large.getter
    def industry_code3_large(self):
        return self._industry_code3_large

    @industry_code3_medium.getter
    def industry_code3_medium(self):
        return self._industry_code3_medium

    @industry_code3_small.getter
    def industry_code3_small(self):
        return self._industry_code3_small

    @industry_code3_tiny.getter
    def industry_code3_tiny(self):
        return self._industry_code3_tiny

    @create_date.getter
    def create_date(self):
        return self._create_date

    @update_date.getter
    def update_date(self):
        return self._update_date

    @update_at.getter
    def update_at(self):
        return self._update_at

    @c_office_id.getter
    def c_office_id(self):
        return self._c_office_id

    @c_head_office_id.getter
    def c_head_office_id(self):
        return self._c_head_office_id

    @c_top_head_office_id.getter
    def c_top_head_office_id(self):
        return self._c_top_head_office_id

    @c_top_af_office_id1.getter
    def c_top_af_office_id1(self):
        return self._c_top_af_office_id1

    @c_affiliated_office_id1.getter
    def c_affiliated_office_id1(self):
        return self._c_affiliated_office_id1

    @c_relation_flag1.getter
    def c_relation_flag1(self):
        return self._c_relation_flag1

    @c_listed_code.getter
    def c_listed_code(self):
        return self._c_listed_code

    @c_sec_code.getter
    def c_sec_code(self):
        return self._c_sec_code

    @c_yuho_number.getter
    def c_yuho_number(self):
        return self._c_yuho_number

    @c_hyouten.getter
    def c_hyouten(self):
        return self._c_hyouten

    @c_company_name.getter
    def c_company_name(self):
        return self._c_company_name

    @c_company_name_kana.getter
    def c_company_name_kana(self):
        return self._c_company_name_kana

    @c_office_name.getter
    def c_office_name(self):
        return self._c_office_name

    @c_building_name.getter
    def c_building_name(self):
        return self._c_building_name

    @c_company_pref_id.getter
    def c_company_pref_id(self):
        return self._c_company_pref_id

    @c_company_city_id.getter
    def c_company_city_id(self):
        return self._c_company_city_id

    @c_company_zip.getter
    def c_company_zip(self):
        return self._c_company_zip

    @c_tel.getter
    def c_tel(self):
        return self._c_tel

    @c_fax.getter
    def c_fax(self):
        return self._c_fax

    @c_office_count.getter
    def c_office_count(self):
        return self._c_office_count

    @c_office_count_range.getter
    def c_office_count_range(self):
        return self._c_office_count_range

    @c_setup_date.getter
    def c_setup_date(self):
        return self._c_setup_date

    @c_capital.getter
    def c_capital(self):
        return self._c_capital

    @c_capital_range.getter
    def c_capital_range(self):
        return self._c_capital_range

    @c_emp_count.getter
    def c_emp_count(self):
        return self._c_emp_count

    @c_emp_count_range.getter
    def c_emp_count_range(self):
        return self._c_emp_count_range

    @c_sales.getter
    def c_sales(self):
        return self._c_sales

    @c_sales_range.getter
    def c_sales_range(self):
        return self._c_sales_range

    @c_settlement_month.getter
    def c_settlement_month(self):
        return self._c_settlement_month

    @c_profit.getter
    def c_profit(self):
        return self._c_profit

    @c_profit_range.getter
    def c_profit_range(self):
        return self._c_profit_range

    @c_license.getter
    def c_license(self):
        return self._c_license

    @c_organizations.getter
    def c_organizations(self):
        return self._c_organizations

    @c_inv_date.getter
    def c_inv_date(self):
        return self._c_inv_date

    @c_company_kind.getter
    def c_company_kind(self):
        return self._c_company_kind

    @c_has_url.getter
    def c_has_url(self):
        return self._c_has_url

    @c_has_foreign_flag.getter
    def c_has_foreign_flag(self):
        return self._c_has_foreign_flag

    @c_is_head_office.getter
    def c_is_head_office(self):
        return self._c_is_head_office

    @c_stat_ng.getter
    def c_stat_ng(self):
        return self._c_stat_ng

    @c_is_ccng.getter
    def c_is_ccng(self):
        return self._c_is_ccng

    @c_is_mujin_office.getter
    def c_is_mujin_office(self):
        return self._c_is_mujin_office

    @c_office_class.getter
    def c_office_class(self):
        return self._c_office_class

    @c_corporate_number.getter
    def c_corporate_number(self):
        return self._c_corporate_number

    @c_grade.getter
    def c_grade(self):
        return self._c_grade

    @del_flag.getter
    def del_flag(self):
        return self._del_flag

    @c_is_faxdm.getter
    def c_is_faxdm(self):
        return self._c_is_faxdm

    @gid.setter
    def gid(self, value):
        self._gid = value

    @office_id.setter
    def office_id(self, value):
        self._office_id = value

    @company_abbreviated_flag.setter
    def company_abbreviated_flag(self, value):
        self._company_abbreviated_flag = value

    @company_abbreviated_name.setter
    def company_abbreviated_name(self, value):
        self._company_abbreviated_name = value

    @company_before_after.setter
    def company_before_after(self, value):
        self._company_before_after = value

    @company_before_after_name.setter
    def company_before_after_name(self, value):
        self._company_before_after_name = value

    @company_name.setter
    def company_name(self, value):
        self._company_name = value

    @formal_company_name.setter
    def formal_company_name(self, value):
        self._formal_company_name = value

    @office_name.setter
    def office_name(self, value):
        self._office_name = value

    @industry_code1_large.setter
    def industry_code1_large(self, value):
        self._industry_code1_large = value

    @industry_code1_medium.setter
    def industry_code1_medium(self, value):
        self._industry_code1_medium = value

    @industry_code1_small.setter
    def industry_code1_small(self, value):
        self._industry_code1_small = value

    @industry_code1_tiny.setter
    def industry_code1_tiny(self, value):
        self._industry_code1_tiny = value

    @industry_code2_large.setter
    def industry_code2_large(self, value):
        self._industry_code2_large = value

    @industry_code2_medium.setter
    def industry_code2_medium(self, value):
        self._industry_code2_medium = value

    @industry_code2_small.setter
    def industry_code2_small(self, value):
        self._industry_code2_small = value

    @industry_code2_tiny.setter
    def industry_code2_tiny(self, value):
        self._industry_code2_tiny = value

    @industry_code3_large.setter
    def industry_code3_large(self, value):
        self._industry_code3_large = value

    @industry_code3_medium.setter
    def industry_code3_medium(self, value):
        self._industry_code3_medium = value

    @industry_code3_small.setter
    def industry_code3_small(self, value):
        self._industry_code3_small = value

    @industry_code3_tiny.setter
    def industry_code3_tiny(self, value):
        self._industry_code3_tiny = value

    @create_date.setter
    def create_date(self, value):
        self._create_date = value

    @update_date.setter
    def update_date(self, value):
        self._update_date = value

    @update_at.setter
    def update_at(self, value):
        self._update_at = value

    @c_office_id.setter
    def c_office_id(self, value):
        self._c_office_id = value

    @c_head_office_id.setter
    def c_head_office_id(self, value):
        self._c_head_office_id = value

    @c_top_head_office_id.setter
    def c_top_head_office_id(self, value):
        self._c_top_head_office_id = value

    @c_top_af_office_id1.setter
    def c_top_af_office_id1(self, value):
        self._c_top_af_office_id1 = value

    @c_affiliated_office_id1.setter
    def c_affiliated_office_id1(self, value):
        self._c_affiliated_office_id1 = value

    @c_relation_flag1.setter
    def c_relation_flag1(self, value):
        self._c_relation_flag1 = value

    @c_listed_code.setter
    def c_listed_code(self, value):
        self._c_listed_code = value

    @c_sec_code.setter
    def c_sec_code(self, value):
        self._c_sec_code = value

    @c_yuho_number.setter
    def c_yuho_number(self, value):
        self._c_yuho_number = value

    @c_hyouten.setter
    def c_hyouten(self, value):
        self._c_hyouten = value

    @c_company_name.setter
    def c_company_name(self, value):
        self._c_company_name = value

    @c_company_name_kana.setter
    def c_company_name_kana(self, value):
        self._c_company_name_kana = value

    @c_office_name.setter
    def c_office_name(self, value):
        self._c_office_name = value

    @c_building_name.setter
    def c_building_name(self, value):
        self._c_building_name = value

    @c_company_pref_id.setter
    def c_company_pref_id(self, value):
        self._c_company_pref_id = value

    @c_company_city_id.setter
    def c_company_city_id(self, value):
        self._c_company_city_id = value

    @c_company_zip.setter
    def c_company_zip(self, value):
        self._c_company_zip = value

    @c_tel.setter
    def c_tel(self, value):
        self._c_tel = value

    @c_fax.setter
    def c_fax(self, value):
        self._c_fax = value

    @c_office_count.setter
    def c_office_count(self, value):
        self._c_office_count = value

    @c_office_count_range.setter
    def c_office_count_range(self, value):
        self._c_office_count_range = value

    @c_setup_date.setter
    def c_setup_date(self, value):
        self._c_setup_date = value

    @c_capital.setter
    def c_capital(self, value):
        self._c_capital = value

    @c_capital_range.setter
    def c_capital_range(self, value):
        self._c_capital_range = value

    @c_emp_count.setter
    def c_emp_count(self, value):
        self._c_emp_count = value

    @c_emp_count_range.setter
    def c_emp_count_range(self, value):
        self._c_emp_count_range = value

    @c_sales.setter
    def c_sales(self, value):
        self._c_sales = value

    @c_sales_range.setter
    def c_sales_range(self, value):
        self._c_sales_range = value

    @c_settlement_month.setter
    def c_settlement_month(self, value):
        self._c_settlement_month = value

    @c_profit.setter
    def c_profit(self, value):
        self._c_profit = value

    @c_profit_range.setter
    def c_profit_range(self, value):
        self._c_profit_range = value

    @c_license.setter
    def c_license(self, value):
        self._c_license = value

    @c_organizations.setter
    def c_organizations(self, value):
        self._c_organizations = value

    @c_inv_date.setter
    def c_inv_date(self, value):
        self._c_inv_date = value

    @c_company_kind.setter
    def c_company_kind(self, value):
        self._c_company_kind = value

    @c_has_url.setter
    def c_has_url(self, value):
        self._c_has_url = value

    @c_has_foreign_flag.setter
    def c_has_foreign_flag(self, value):
        self._c_has_foreign_flag = value

    @c_is_head_office.setter
    def c_is_head_office(self, value):
        self._c_is_head_office = value

    @c_stat_ng.setter
    def c_stat_ng(self, value):
        self._c_stat_ng = value

    @c_is_ccng.setter
    def c_is_ccng(self, value):
        self._c_is_ccng = value

    @c_is_mujin_office.setter
    def c_is_mujin_office(self, value):
        self._c_is_mujin_office = value

    @c_office_class.setter
    def c_office_class(self, value):
        self._c_office_class = value

    @c_corporate_number.setter
    def c_corporate_number(self, value):
        self._c_corporate_number = value

    @c_grade.setter
    def c_grade(self, value):
        self._c_grade = value

    @del_flag.setter
    def del_flag(self, value):
        self._del_flag = value

    @c_is_faxdm.setter
    def c_is_faxdm(self, value):
        self._c_is_faxdm = value

    @gid.deleter
    def gid(self):
        del self._gid

    @office_id.deleter
    def office_id(self):
        del self._office_id

    @company_abbreviated_flag.deleter
    def company_abbreviated_flag(self):
        del self._company_abbreviated_flag

    @company_abbreviated_name.deleter
    def company_abbreviated_name(self):
        del self._company_abbreviated_name

    @company_before_after.deleter
    def company_before_after(self):
        del self._company_before_after

    @company_before_after_name.deleter
    def company_before_after_name(self):
        del self._company_before_after_name

    @company_name.deleter
    def company_name(self):
        del self._company_name

    @formal_company_name.deleter
    def formal_company_name(self):
        del self._formal_company_name

    @office_name.deleter
    def office_name(self):
        del self._office_name

    @industry_code1_large.deleter
    def industry_code1_large(self):
        del self.industry_code1_large

    @industry_code1_medium.deleter
    def industry_code1_medium(self):
        del self._industry_code1_medium

    @industry_code1_small.deleter
    def industry_code1_small(self):
        del self._industry_code1_small

    @industry_code1_tiny.deleter
    def industry_code1_tiny(self):
        del self._industry_code1_tiny

    @industry_code2_large.deleter
    def industry_code2_large(self):
        del self.industry_code2_large

    @industry_code2_medium.deleter
    def industry_code2_medium(self):
        del self._industry_code2_medium

    @industry_code2_small.deleter
    def industry_code2_small(self):
        del self._industry_code2_small

    @industry_code2_tiny.deleter
    def industry_code2_tiny(self):
        del self._industry_code2_tiny

    @industry_code3_large.deleter
    def industry_code3_large(self):
        del self.industry_code3_large

    @industry_code3_medium.deleter
    def industry_code3_medium(self):
        del self._industry_code3_medium

    @industry_code3_small.deleter
    def industry_code3_small(self):
        del self._industry_code3_small

    @industry_code3_tiny.deleter
    def industry_code3_tiny(self):
        del self._industry_code3_tiny

    @create_date.deleter
    def create_date(self):
        del self._create_date

    @update_date.deleter
    def update_date(self):
        del self._update_date

    @update_at.deleter
    def update_at(self):
        del self._update_at

    @c_office_id.deleter
    def c_office_id(self):
        del self._c_office_id

    @c_head_office_id.deleter
    def c_head_office_id(self):
        del self._c_head_office_id

    @c_top_head_office_id.deleter
    def c_top_head_office_id(self):
        del self._c_top_head_office_id

    @c_top_af_office_id1.deleter
    def c_top_af_office_id1(self):
        del self._c_top_af_office_id1

    @c_affiliated_office_id1.deleter
    def c_affiliated_office_id1(self):
        del self._c_affiliated_office_id1

    @c_relation_flag1.deleter
    def c_relation_flag1(self):
        del self._c_relation_flag1

    @c_listed_code.deleter
    def c_listed_code(self):
        del self._c_listed_code

    @c_sec_code.deleter
    def c_sec_code(self):
        del self._c_sec_code

    @c_yuho_number.deleter
    def c_yuho_number(self):
        del self._c_yuho_number

    @c_hyouten.deleter
    def c_hyouten(self):
        del self._c_hyouten

    @c_company_name.deleter
    def c_company_name(self):
        del self._c_company_name

    @c_company_name_kana.deleter
    def c_company_name_kana(self):
        del self._c_company_name_kana

    @c_office_name.deleter
    def c_office_name(self):
        del self._c_office_name

    @c_building_name.deleter
    def c_building_name(self):
        del self._c_building_name

    @c_company_pref_id.deleter
    def c_company_pref_id(self):
        del self._c_company_pref_id

    @c_company_city_id.deleter
    def c_company_city_id(self):
        del self._c_company_city_id

    @c_company_zip.deleter
    def c_company_zip(self):
        del self._c_company_zip

    @c_tel.deleter
    def c_tel(self):
        del self._c_tel

    @c_fax.deleter
    def c_fax(self):
        del self._c_fax

    @c_office_count.deleter
    def c_office_count(self):
        del self._c_office_count

    @c_office_count_range.deleter
    def c_office_count_range(self):
        del self._c_office_count_range

    @c_setup_date.deleter
    def c_setup_date(self):
        del self._c_setup_date

    @c_capital.deleter
    def c_capital(self):
        del self._c_capital

    @c_capital_range.deleter
    def c_capital_range(self):
        del self._c_capital_range

    @c_emp_count.deleter
    def c_emp_count(self):
        del self._c_emp_count

    @c_emp_count_range.deleter
    def c_emp_count_range(self):
        del self._c_emp_count_range

    @c_sales.deleter
    def c_sales(self):
        del self._c_sales

    @c_sales_range.deleter
    def c_sales_range(self):
        del self._c_sales_range

    @c_settlement_month.deleter
    def c_settlement_month(self):
        del self._c_settlement_month

    @c_profit.deleter
    def c_profit(self):
        del self._c_profit

    @c_profit_range.deleter
    def c_profit_range(self):
        del self._c_profit_range

    @c_license.deleter
    def c_license(self):
        del self._c_license

    @c_organizations.deleter
    def c_organizations(self):
        del self._c_organizations

    @c_inv_date.deleter
    def c_inv_date(self):
        del self._c_inv_date

    @c_company_kind.deleter
    def c_company_kind(self):
        del self._c_company_kind

    @c_has_url.deleter
    def c_has_url(self):
        del self._c_has_url

    @c_has_foreign_flag.deleter
    def c_has_foreign_flag(self):
        del self._c_has_foreign_flag

    @c_is_head_office.deleter
    def c_is_head_office(self):
        del self._c_is_head_office

    @c_stat_ng.deleter
    def c_stat_ng(self):
        del self._c_stat_ng

    @c_is_ccng.deleter
    def c_is_ccng(self):
        del self._c_is_ccng

    @c_is_mujin_office.deleter
    def c_is_mujin_office(self):
        del self._c_is_mujin_office

    @c_office_class.deleter
    def c_office_class(self):
        del self._c_office_class

    @c_corporate_number.deleter
    def c_corporate_number(self):
        del self._c_corporate_number

    @c_grade.deleter
    def c_grade(self):
        del self._c_grade

    @del_flag.deleter
    def del_flag(self):
        del self._del_flag

    @c_is_faxdm.deleter
    def c_is_faxdm(self):
        del self._c_is_faxdm
