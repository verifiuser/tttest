# -*- coding: utf-8 -*-

__version__ = "1.0.0"


class Visit:

    def __init__(self):

        self._proc_id = None
        self._office_id = None
        self._gid = None
        self._member_name = None
        self._member_id = None
        self._action_id = None
        self._update_at = None
        self._del_flag = 0

    @property
    def proc_id(self):
        pass

    @property
    def office_id(self):
        pass

    @property
    def gid(self):
        pass

    @property
    def member_name(self):
        pass

    @property
    def member_id(self):
        pass

    @property
    def action_id(self):
        pass

    @property
    def update_at(self):
        pass

    @property
    def del_flag(self):
        pass

    @proc_id.getter
    def proc_id(self):
        return self._proc_id

    @office_id.getter
    def office_id(self):
        return self._office_id

    @gid.getter
    def gid(self):
        return self._gid

    @member_name.getter
    def member_name(self):
        return self._member_name

    @member_id.getter
    def member_id(self):
        return self._member_id

    @action_id.getter
    def action_id(self):
        return self._action_id

    @update_at.getter
    def update_at(self):
        return self._update_at

    @del_flag.getter
    def del_flag(self):
        return self._del_flag

    @proc_id.setter
    def proc_id(self, value):
        self._proc_id = value

    @office_id.setter
    def office_id(self, value):
        self._office_id = value

    @gid.setter
    def gid(self, value):
        self._gid = value

    @member_name.setter
    def member_name(self, value):
        self._member_name = value

    @member_id.setter
    def member_id(self, value):
        self._member_id = value

    @action_id.setter
    def action_id(self, value):
        self._action_id = value

    @update_at.setter
    def update_at(self, value):
        self._update_at = value

    @del_flag.setter
    def del_flag(self, value):
        self._del_flag = value

    @proc_id.deleter
    def proc_id(self):
        del self._proc_id

    @office_id.deleter
    def office_id(self):
        del self._office_id

    @gid.deleter
    def gid(self):
        del self._gid

    @member_name.deleter
    def member_name(self):
        del self._member_name

    @member_id.deleter
    def member_id(self):
        del self._member_id

    @action_id.deleter
    def action_id(self):
        del self._action_id

    @update_at.deleter
    def update_at(self):
        del self._update_at

    @del_flag.deleter
    def del_flag(self):
        del self._del_flag
