# -*- coding: utf-8 -*-

__version__ = "1.0.0"


class LiveAccess:

    def __init__(self):

        self._id = None
        self._office_id = None
        self._gid = None
        self._access_date = None
        self._referrer = None
        self._site_url = None
        self._search_word = None
        self._live_page_url = None
        self._cookie_id = None
        self._create_at = None
        self._category_id = 0
        self._hierarchy_path = None

    @property
    def id(self):
        pass

    @property
    def office_id(self):
        pass

    @property
    def gid(self):
        pass

    @property
    def access_date(self):
        pass

    @property
    def referrer(self):
        pass

    @property
    def site_url(self):
        pass

    @property
    def search_word(self):
        pass

    @property
    def live_page_url(self):
        pass

    @property
    def cookie_id(self):
        pass

    @property
    def create_at(self):
        pass

    @property
    def category_id(self):
        pass

    @property
    def hierarchy_path(self):
        pass

    @id.getter
    def id(self):
        return self._id

    @office_id.getter
    def office_id(self):
        return self._office_id

    @gid.getter
    def gid(self):
        return self._gid

    @access_date.getter
    def access_date(self):
        return self._access_date

    @referrer.getter
    def referrer(self):
        return self._referrer

    @site_url.getter
    def site_url(self):
        return self._site_url

    @search_word.getter
    def search_word(self):
        return self._search_word

    @live_page_url.getter
    def live_page_url(self):
        return self._live_page_url

    @cookie_id.getter
    def cookie_id(self):
        return self._cookie_id

    @create_at.getter
    def create_at(self):
        return self._create_at

    @category_id.getter
    def category_id(self):
        return self._category_id

    @hierarchy_path.getter
    def hierarchy_path(self):
        return self._hierarchy_path

    @id.setter
    def id(self, value):
        self._id = value

    @office_id.setter
    def office_id(self, value):
        self._office_id = value

    @gid.setter
    def gid(self, value):
        self._gid = value

    @access_date.setter
    def access_date(self, value):
        self._access_date = value

    @referrer.setter
    def referrer(self, value):
        self._referrer = value

    @site_url.setter
    def site_url(self, value):
        self._site_url = value

    @search_word.setter
    def search_word(self, value):
        self._search_word = value

    @live_page_url.setter
    def live_page_url(self, value):
        self._live_page_url = value

    @cookie_id.setter
    def cookie_id(self, value):
        self._cookie_id = value

    @create_at.setter
    def create_at(self, value):
        self._create_at = value

    @category_id.setter
    def category_id(self, value):
        self._category_id = value

    @hierarchy_path.setter
    def hierarchy_path(self, value):
        self._hierarchy_path = value

    @id.deleter
    def id(self):
        del self._id

    @office_id.deleter
    def office_id(self):
        del self._office_id

    @gid.deleter
    def gid(self):
        del self._gid

    @access_date.deleter
    def access_date(self):
        del self._access_date

    @referrer.deleter
    def referrer(self):
        del self._referrer

    @site_url.deleter
    def site_url(self):
        del self._site_url

    @search_word.deleter
    def search_word(self):
        del self._search_word

    @live_page_url.deleter
    def live_page_url(self):
        del self._live_page_url

    @cookie_id.deleter
    def cookie_id(self):
        del self._cookie_id

    @create_at.deleter
    def create_at(self):
        del self._create_at

    @category_id.deleter
    def category_id(self):
        del self._category_id

    @hierarchy_path.deleter
    def hierarchy_path(self):
        del self._hierarchy_path
