# -*- coding: utf-8 -*-

__version__ = "1.0.0"


class Sales:

    def __init__(self):

        self._id = None
        self._office_id = None
        self._gid = None
        self._product_id = None
        self._date = None
        self._amount = 0
        self._update_at = None
        self._del_flag = 0

    @property
    def id(self):
        pass

    @property
    def office_id(self):
        pass

    @property
    def gid(self):
        pass

    @property
    def product_id(self):
        pass

    @property
    def date(self):
        pass

    @property
    def amount(self):
        pass

    @property
    def update_at(self):
        pass

    @property
    def del_flag(self):
        pass

    @id.getter
    def id(self):
        return self._id

    @office_id.getter
    def office_id(self):
        return self._office_id

    @gid.getter
    def gid(self):
        return self._gid

    @product_id.getter
    def product_id(self):
        return self._product_id

    @date.getter
    def date(self):
        return self._date

    @amount.getter
    def amount(self):
        return self._amount

    @update_at.getter
    def update_at(self):
        return self._update_at

    @del_flag.getter
    def del_flag(self):
        return self._del_flag

    @id.setter
    def id(self, value):
        self._id = value

    @office_id.setter
    def office_id(self, value):
        self._office_id = value

    @gid.setter
    def gid(self, value):
        self._gid = value

    @product_id.setter
    def product_id(self, value):
        self._product_id = value

    @date.setter
    def date(self, value):
        self._date = value

    @amount.setter
    def amount(self, value):
        self._amount = value

    @update_at.setter
    def update_at(self, value):
        self._update_at = value

    @del_flag.setter
    def del_flag(self, value):
        self._del_flag = value

    @id.deleter
    def id(self):
        del self._id

    @office_id.deleter
    def office_id(self):
        del self._office_id

    @gid.deleter
    def gid(self):
        del self._gid

    @product_id.deleter
    def product_id(self):
        del self._product_id

    @date.deleter
    def date(self):
        del self._date

    @amount.deleter
    def amount(self):
        del self._amount

    @update_at.deleter
    def update_at(self):
        del self._update_at

    @del_flag.deleter
    def del_flag(self):
        del self._del_flag
