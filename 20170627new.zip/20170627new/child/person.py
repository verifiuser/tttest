# -*- coding: utf-8 -*-

from entity import person
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil

__version__ = "1.0.0"


class Person:

    def __init__(self):

        self.en = person.Person()
        self.lu = landutil.LandUtil('person')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2009)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mp.ew.header, mp.ew.count_rows):

            mp.en.office_id = mp.ew.get_cell_str(row=row, col=0)
            mp.en.gid = mp.ew.get_cell_str(row=row, col=2)
            gn_count = mp.ew.get_cell_int(row=(mp.sw.case(mp.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                mp.en.uni_id3 = mp.udi.calculation(count=i)
                mp.en.id = mp.en.gid + "-" + mp.lu.get_union(mp.en.office_id + mp.en.uni_id3)
                mp.en.busho = mp.lu.get_nr('busho')
                mp.en.yakushoku = mp.lu.get_nr('yakushoku')
                mp.en.keyman_flag = mp.lu.get_nr('keyman_flag')
                mp.en.eps_flag = mp.lu.get_nr('eps_flag')
                mp.en.email = mp.lu.get_nr('email')
                mp.en.member_name = mp.lu.get_nr('member_name')
                mp.en.tanto_name = mp.lu.get_nr('tanto_name')
                mp.en.update_at = mp.lu.get_cal(mp.ud_list)

                mp.rows.append(
                    [
                        mp.en.id, mp.en.uni_id3, mp.en.office_id, mp.en.gid, mp.en.busho, mp.en.yakushoku,
                        mp.en.keyman_flag, mp.en.eps_flag, mp.en.fps_flag, mp.en.tps_flag, mp.en.mps_flag, mp.en.email,
                        mp.en.member_name, mp.en.tanto_name, mp.en.hiragana_flag, mp.en.katakana_flag, mp.en.update_at,
                        mp.en.del_flag
                    ]
                )
        mp.cs.savedata(rows=mp.rows, name='person', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mp = Person()
    mp.main()
    del mp
