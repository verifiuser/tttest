# -*- coding: utf-8 -*-

from entity import hosting
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil

__version__ = "1.0.0"


class Hosting:

    def __init__(self):

        self.en = hosting.Hosting()
        self.lu = landutil.LandUtil('hosting')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2007, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mch.ew.header, mch.ew.count_rows):

            mch.en.office_id = mch.ew.get_cell_str(row=row, col=0)
            mch.en.gid = mch.ew.get_cell_str(row=row, col=2)
            gn_count = mch.ew.get_cell_int(row=(mch.sw.case(mch.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                mch.en.id = mch.en.gid + "-" + mch.lu.get_union(mch.en.office_id + mch.udi.calculation(count=i))
                mch.en.update_at = mch.lu.get_cal(mch.ud_list)

                mch.rows.append(
                    [
                        mch.en.id, mch.en.office_id, mch.en.gid, mch.en.update_at
                    ]
                )
        mch.cs.savedata(rows=mch.rows, name='hosting', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mch = Hosting()
    mch.main()
    del mch
