# -*- coding: utf-8 -*-

from entity import bizitem
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil

__version__ = "1.0.0"


class BizItem:

    def __init__(self):

        self.en = bizitem.BizItem()
        self.lu = landutil.LandUtil('bizitem')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ed_list = dr.random_date(span_list=(dr.date_span(start_year=2010, end_year=2017)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2007, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mbi.ew.header, mbi.ew.count_rows):

            mbi.en.office_id = mbi.ew.get_cell_str(row=row, col=0)
            mbi.en.gid = mbi.ew.get_cell_str(row=row, col=2)
            gn_count = mbi.ew.get_cell_int(row=(mbi.sw.case(mbi.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                mbi.en.id = mbi.en.gid + "-" + mbi.lu.get_union(mbi.en.office_id + mbi.udi.calculation(count=i))
                mbi.en.status = mbi.lu.get_nr('status')
                mbi.en.product = mbi.lu.get_nr('product')
                mbi.en.price = mbi.lu.get_calc('price')
                mbi.en.probability = mbi.lu.get_nr('probability')
                mbi.en.end_date = mbi.lu.get_cal(mbi.ed_list)
                mbi.en.update_at = mbi.lu.get_cal(mbi.ud_list)

                mbi.rows.append(
                    [
                        mbi.en.id, mbi.en.office_id, mbi.en.gid, mbi.en.status, mbi.en.product, mbi.en.price,
                        mbi.en.probability, mbi.en.end_date, mbi.en.update_at, mbi.en.del_flag
                    ]
                )
        mbi.cs.savedata(rows=mbi.rows, name='bizitem', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mbi = BizItem()
    mbi.main()
    del mbi
