# -*- coding: utf-8 -*-

from entity import ct
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil

__version__ = "1.0.0"


class Ct:

    def __init__(self):

        self.en = ct.Ct()
        self.lu = landutil.LandUtil('ct')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ad_list = dr.random_date(span_list=(dr.date_span(start_year=2010, end_year=2017)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2009)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(vct.ew.header, vct.ew.count_rows):

            vct.en.office_id = vct.ew.get_cell_str(row=row, col=0)
            vct.en.gid = vct.ew.get_cell_str(row=row, col=2)
            gn_count = vct.ew.get_cell_int(row=(vct.sw.case(vct.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                vct.en.id = vct.en.gid + "-" + vct.udi.calculation(count=i)
                vct.en.uni_id3 = vct.lu.get_union(vct.en.id + vct.en.office_id)
                vct.en.category = vct.lu.get_nr('category')
                vct.en.target_type = vct.lu.get_nr('target_type')
                vct.en.action_id = vct.lu.get_nr('action_id')
                vct.en.action_type = vct.lu.get_nr('action_type')
                vct.en.product_ids = vct.lu.get_nr('product_ids')
                vct.en.action_date = vct.lu.get_cal(vct.ad_list)
                vct.en.update_at = vct.lu.get_cal(vct.ud_list)

                vct.rows.append(
                    [
                        vct.en.id, vct.en.office_id, vct.en.gid, vct.en.uni_id3, vct.en.category, vct.en.target_type,
                        vct.en.action_id, vct.en.action_type, vct.en.product_ids, vct.en.action_date, vct.en.update_at,
                        vct.en.del_flag
                    ]
                )
        vct.cs.savedata(rows=vct.rows, name='ct', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    vct = Ct()
    vct.main()
    del vct
