# -*- coding: utf-8 -*-

from entity import stats
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil

__version__ = "1.0.0"


class Stats:

    def __init__(self):

        self.en = stats.Stats()
        self.lu = landutil.LandUtil('stats')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2010, end_year=2017)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(cms.ew.header, cms.ew.count_rows):

            cms.en.office_id = cms.ew.get_cell_str(row=row, col=0)
            cms.en.gid = cms.ew.get_cell_str(row=row, col=2)
            gn_count = cms.ew.get_cell_int(row=(cms.sw.case(cms.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                cms.en.id = cms.en.gid + "-" + cms.lu.get_union(cms.en.office_id + cms.udi.calculation(count=i))
                cms.en.total_count = cms.lu.get_calc('total_count')
                cms.en.update_at = cms.lu.get_cal(cms.ud_list)

                cms.rows.append(
                    [
                        cms.en.id, cms.en.office_id, cms.en.gid, cms.en.total_count, cms.en.update_at, cms.en.del_flag
                    ]
                )
        cms.cs.savedata(rows=cms.rows, name='stats', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    cms = Stats()
    cms.main()
    del cms
