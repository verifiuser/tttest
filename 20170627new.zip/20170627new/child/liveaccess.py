# -*- coding: utf-8 -*-

from entity import liveaccess
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil

__version__ = "1.0.0"


class LiveAccess:

    def __init__(self):

        self.en = liveaccess.LiveAccess()
        self.lu = landutil.LandUtil('liveaccess')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ac_list = dr.random_date(span_list=(dr.date_span(start_year=2010, end_year=2017)))
        self.cr_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2009)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mla.ew.header, mla.ew.count_rows):

            mla.en.office_id = mla.ew.get_cell_str(row=row, col=0)
            mla.en.gid = mla.ew.get_cell_str(row=row, col=2)
            gn_count = mla.ew.get_cell_int(row=(mla.sw.case(mla.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                mla.en.id = mla.en.gid + "-" + mla.udi.calculation(count=i)
                mla.en.referrer = mla.lu.get_nr('referrer')
                mla.en.site_url = mla.lu.get_nr('site_url')
                mla.en.search_word = mla.lu.get_nr('search_word')
                mla.en.live_page_url = mla.lu.get_nr('live_page_url')
                mla.en.category_id = mla.lu.get_nr('category_id')
                mla.en.hierarchy_path = mla.lu.get_nr('hierarchy_path')
                mla.en.access_date = mla.lu.get_cal(mla.ac_list)
                mla.en.create_at = mla.lu.get_cal(mla.cr_list)

                mla.rows.append(
                    [
                        mla.en.id, mla.en.office_id, mla.en.gid, mla.en.access_date, mla.en.referrer, mla.en.site_url,
                        mla.en.search_word, mla.en.live_page_url, mla.en.cookie_id, mla.en.create_at,
                        mla.en.category_id, mla.en.hierarchy_path
                    ]
                )
        mla.cs.savedata(rows=mla.rows, name='liveaccess', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mla = LiveAccess()
    mla.main()
    del mla
