# -*- coding: utf-8 -*-

from entity import deal
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil

__version__ = "1.0.0"


class Deal:

    def __init__(self):

        self.en = deal.Deal()
        self.lu = landutil.LandUtil('deal')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.dd_list = dr.random_date_time(span_list=(dr.date_span(start_year=2007, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(ds.ew.header, ds.ew.count_rows):

            ds.en.office_id = ds.ew.get_cell_str(row=row, col=0)
            ds.en.gid = ds.ew.get_cell_str(row=row, col=2)
            gn_count = ds.ew.get_cell_int(row=(ds.sw.case(ds.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                ds.en.status_id = ds.en.gid + "-" + ds.lu.get_union(ds.en.office_id + ds.udi.calculation(count=i))
                ds.en.deal_flag = int(ds.lu.get_nr('flag'))
                ds.en.update_at = ds.lu.get_cal(ds.dd_list)

                ds.rows.append(
                    [
                        ds.en.status_id, ds.en.office_id, ds.en.deal_flag, ds.en.gid, ds.en.update_at, ds.en.del_flag
                    ]
                )
        ds.cs.savedata(rows=ds.rows, name='deal', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    ds = Deal()
    ds.main()
    del ds
