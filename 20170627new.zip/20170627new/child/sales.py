# -*- coding: utf-8 -*-

from entity import sales
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil

__version__ = "1.0.0"


class Sales:

    def __init__(self):

        self.en = sales.Sales()
        self.lu = landutil.LandUtil('sales')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.sd_list = dr.random_date_ym(span_list=(dr.date_span(start_year=2001, end_year=2017)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2010, end_year=2017)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(ms.ew.header, ms.ew.count_rows):

            ms.en.office_id = ms.ew.get_cell_str(row=row, col=0)
            ms.en.gid = ms.ew.get_cell_str(row=row, col=2)
            gn_count = ms.ew.get_cell_int(row=(ms.sw.case(ms.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                ms.en.id = ms.en.gid + "-" + ms.lu.get_union(ms.en.office_id + ms.udi.calculation(count=i))
                ms.en.product_id = ms.lu.get_nr('product_id')
                ms.en.amount = ms.lu.get_calc('amount')
                ms.en.date = ms.lu.get_cal(ms.sd_list)
                ms.en.update_at = ms.lu.get_cal(ms.ud_list)

                ms.rows.append(
                    [
                        ms.en.id, ms.en.office_id, ms.en.gid, ms.en.product_id, ms.en.date, ms.en.amount,
                        ms.en.update_at, ms.en.del_flag
                    ]
                )
        ms.cs.savedata(rows=ms.rows, name='sales', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    ms = Sales()
    ms.main()
    del ms
