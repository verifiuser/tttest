# -*- coding: utf-8 -*-

import xlrd
import random
import sys
import daterange
import csvparser
import switch
import underid


reload(sys)
sys.setdefaultencoding('utf-8')


class Hosting:

    def __init__(self):

        self.hosting_id = ""
        self.lbc_office_id = ""
        self.hosting_gid = ""
        self.hosting_update_at = ""

        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
        sheets = book.sheets()
        self.s1 = sheets[0]

        self.header = 1
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2007, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mch.header, mch.s1.nrows):

            mch.lbc_office_id = str(mch.s1.cell(row, 0).value)
            mch.hosting_gid = str(mch.s1.cell(row, 2).value)
            gn_count = int(mch.s1.cell(mch.sw.case(mch.s1.cell(row, 3).value), 5).value)

            for i in xrange(gn_count):

                mch.hosting_id = mch.hosting_gid + mch.udi.calculation(count=i)
                mch.hosting_update_at = random.choice(mch.ud_list)

                mch.rows.append(
                    [
                        mch.hosting_id, mch.lbc_office_id, mch.hosting_gid, mch.hosting_update_at
                    ]
                )
        mch.cs.savedata(rows=mch.rows, name='hosting', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mch = Hosting()
    mch.main()
    del mch
