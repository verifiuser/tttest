# -*- coding: utf-8 -*-

import xlrd
import random
import sys
import daterange
import csvparser
import switch
import underid


reload(sys)
sys.setdefaultencoding('utf-8')


class Stats:

    def __init__(self):

        self.stats_id = ""
        self.lbc_office_id = ""
        self.stats_gid = ""
        self.stats_total_count = 0
        self.stats_update_at = ""
        self.stats_del_flag = 0

        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
        sheets = book.sheets()
        self.s1 = sheets[0]

        self.header = 1
        self.tc_list = [i for i in xrange(100, 199)]
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2010, end_year=2017)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(cms.header, cms.s1.nrows):

            cms.lbc_office_id = str(cms.s1.cell(row, 0).value)
            cms.stats_gid = str(cms.s1.cell(row, 2).value)
            gn_count = int(cms.s1.cell(cms.sw.case(cms.s1.cell(row, 3).value), 5).value)

            for i in xrange(gn_count):

                cms.stats_id = cms.stats_gid + cms.udi.calculation(count=i)
                cms.stats_total_count = random.choice(cms.tc_list)
                cms.stats_update_at = random.choice(cms.ud_list)

                cms.rows.append(
                    [
                        cms.stats_id, cms.lbc_office_id, cms.stats_gid, cms.stats_total_count, cms.stats_update_at,
                        cms.stats_del_flag
                    ]
                )
        cms.cs.savedata(rows=cms.rows, name='stats', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    cms = Stats()
    cms.main()
    del cms
