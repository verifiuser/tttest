# -*- coding: utf-8 -*-

import xlrd
import random
import sys
import daterange
import csvparser
import switch
import underid


reload(sys)
sys.setdefaultencoding('utf-8')


class Person:

    def __init__(self):

        self.person_id = ""
        self.person_uni_id3 = ""
        self.lbc_office_id = ""
        self.person_gid = ""
        self.person_busho = ""
        self.person_yakushoku = ""
        self.person_keyman_flag = 0
        self.person_eps_flag = 0
        self.person_fps_flag = ""
        self.person_tps_flag = ""
        self.person_mps_flag = ""
        self.person_email = ""
        self.person_member_name = ""
        self.person_tanto_name = ""
        self.person_hiragana_flag = ""
        self.person_katakana_flag = ""
        self.person_update_at = ""
        self.person_del_flag = 0

        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
        sheets = book.sheets()
        self.s1 = sheets[0]

        self.header = 1
        self.busho_list = ["(ＩＭ)事業推進グループ　部門統括部",
                           " ＜サンウッド東京茅場町パークフロント＞マンションギャラリー",
                           "＜プレシス市谷台町坂＞棟内販売事務所"]
        self.yakushoku_list = ["(VAR　主任)",
                               " (グローバルピジネス推進担当)",
                               "(物流技術管理士)"]
        self.keyman_list = [11, 114, 118, 158, 181, 71, 80, 81, 85, 90, 95, 96]
        self.eps_list = [0, 1, 2, 3, 4, 7, 9]
        self.email_list = ["hanbai@sankyo-sss.co.jp", "hano@kcc.catv-kobe.co.jp", "horoaki@kawai-juku.ac.jp"]
        self.name_list = ["@@@admin", "APIテストユーザー", "SFDC連携"]
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2009)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mp.header, mp.s1.nrows):

            mp.lbc_office_id = str(mp.s1.cell(row, 0).value)
            mp.person_gid = str(mp.s1.cell(row, 2).value)
            gn_count = int(mp.s1.cell(mp.sw.case(mp.s1.cell(row, 3).value), 5).value)

            for i in xrange(gn_count):

                mp.person_uni_id3 = mp.udi.calculation(count=i)
                mp.person_id = mp.person_gid + mp.person_uni_id3
                mp.person_busho = random.choice(mp.busho_list)
                mp.person_yakushoku = random.choice(mp.yakushoku_list)
                mp.person_keyman_flag = random.choice(mp.keyman_list)
                mp.person_eps_flag = random.choice(mp.eps_list)
                mp.person_email = random.choice(mp.email_list)
                mp.person_member_name = random.choice(mp.name_list)
                mp.person_update_at = random.choice(mp.ud_list)

                mp.rows.append(
                    [
                        mp.person_id, mp.person_uni_id3, mp.lbc_office_id, mp.person_gid, mp.person_busho,
                        mp.person_yakushoku, mp.person_keyman_flag, mp.person_eps_flag, mp.person_fps_flag,
                        mp.person_tps_flag, mp.person_mps_flag, mp.person_email, mp.person_member_name,
                        mp.person_tanto_name, mp.person_hiragana_flag, mp.person_katakana_flag, mp.person_update_at,
                        mp.person_del_flag
                    ]
                )
        mp.cs.savedata(rows=mp.rows, name='person', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mp = Person()
    mp.main()
    del mp
