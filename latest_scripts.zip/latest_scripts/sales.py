# -*- coding: utf-8 -*-

import xlrd
import random
import sys
import daterange
import csvparser
import switch
import underid


reload(sys)
sys.setdefaultencoding('utf-8')


class Sales:

    def __init__(self):

        self.sales_id = ""
        self.lbc_office_id = ""
        self.sales_gid = ""
        self.sales_product_id = ""
        self.sales_date = ""
        self.sales_amount = 0
        self.sales_update_at = ""
        self.sales_del_flag = 0

        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
        sheets = book.sheets()
        self.s1 = sheets[0]

        self.header = 1
        self.product_id_list = ["COST", "DISH001", "DISH002"]
        self.amount_list = [i for i in xrange(1000000, 99999999)]
        self.sd_list = dr.random_date_ym(span_list=(dr.date_span(start_year=2001, end_year=2017)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2010, end_year=2017)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(ms.header, ms.s1.nrows):

            ms.lbc_office_id = str(ms.s1.cell(row, 0).value)
            ms.sales_gid = str(ms.s1.cell(row, 2).value)
            gn_count = int(ms.s1.cell(ms.sw.case(ms.s1.cell(row, 3).value), 5).value)

            for i in xrange(gn_count):

                ms.sales_id = ms.sales_gid + ms.udi.calculation(count=i)
                ms.sales_product_id = random.choice(ms.product_id_list)
                ms.sales_amount = random.choice(ms.amount_list)
                ms.sales_date = random.choice(ms.sd_list)
                ms.sales_update_at = random.choice(ms.ud_list)

                ms.rows.append(
                    [
                        ms.sales_id, ms.lbc_office_id, ms.sales_gid, ms.sales_product_id, ms.sales_date,
                        ms.sales_amount, ms.sales_update_at, ms.sales_del_flag
                    ]
                )
        ms.cs.savedata(rows=ms.rows, name='sales', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    ms = Sales()
    ms.main()
    del ms
