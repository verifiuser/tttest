# -*- coding: utf-8 -*-

import xlrd
import random
import sys
import daterange
import csvparser


reload(sys)
sys.setdefaultencoding('utf-8')


class Lbc:

    def __init__(self):

        self.lbc_gid = ""
        self.lbc_office_id = ""
        self.lbc_company_abbreviated_flag = ""
        self.lbc_company_abbreviated_name = ""
        self.lbc_company_before_after = 0
        self.lbc_company_before_after_name = ""
        self.lbc_company_name = ""
        self.lbc_formal_company_name = ""
        self.lbc_office_name = ""
        self.lbc_industry_code1_large = ""
        self.lbc_industry_code1_medium = ""
        self.lbc_industry_code1_small = ""
        self.lbc_industry_code1_tiny = ""
        self.lbc_industry_code2_large = ""
        self.lbc_industry_code2_medium = ""
        self.lbc_industry_code2_small = ""
        self.lbc_industry_code2_tiny = ""
        self.lbc_industry_code3_large = ""
        self.lbc_industry_code3_medium = ""
        self.lbc_industry_code3_small = ""
        self.lbc_industry_code3_tiny = ""
        self.lbc_create_date = ""
        self.lbc_update_date = ""
        self.lbc_update_at = ""
        self.lbc_c_office_id = ""
        self.lbc_c_head_office_id = ""
        self.lbc_c_top_head_office_id = ""
        self.lbc_c_top_af_office_id1 = ""
        self.lbc_c_affiliated_office_id1 = ""
        self.lbc_c_relation_flag1 = ""
        self.lbc_c_listed_code = 0
        self.lbc_c_sec_code = ""
        self.lbc_c_yuho_number = ""
        self.lbc_c_hyouten = 0
        self.lbc_c_company_name = ""
        self.lbc_c_company_name_kana = ""
        self.lbc_c_office_name = ""
        self.lbc_c_building_name = ""
        self.lbc_c_company_pref_id = ""
        self.lbc_c_company_city_id = ""
        self.lbc_c_company_zip = ""
        self.lbc_c_tel = ""
        self.lbc_c_fax = ""
        self.lbc_c_office_count = ""
        self.lbc_c_office_count_range = 0
        self.lbc_c_setup_date = ""
        self.lbc_c_capital = ""
        self.lbc_c_capital_range = 0
        self.lbc_c_emp_count = ""
        self.lbc_c_emp_count_range = 0
        self.lbc_c_sales = ""
        self.lbc_c_sales_range = 0
        self.lbc_c_settlement_month = ""
        self.lbc_c_profit = ""
        self.lbc_c_profit_range = 0
        self.lbc_c_license = ""
        self.lbc_c_organizations = ""
        self.lbc_c_inv_date = ""
        self.lbc_c_company_kind = 0
        self.lbc_c_has_url = 0
        self.lbc_c_has_foreign_flag = 0
        self.lbc_c_is_head_office = 0
        self.lbc_c_stat_ng = 0
        self.lbc_c_is_ccng = 0
        self.lbc_c_is_mujin_office = 0
        self.lbc_c_office_class = 0
        self.lbc_c_corporate_number = ""
        self.lbc_c_grade = ""
        self.lbc_del_flag = 0
        self.lbc_c_is_faxdm = ""

        dr = daterange.DataRange()
        self.cs = csvparser.CsvParser()

        book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
        sheets = book.sheets()
        self.s1 = sheets[0]

        self.header = 1
        self.lbc_company_abbreviated_flag = "00"
        self.lbc_c_listed_code = 9
        self.lbc_c_hyouten = 9
        self.lbc_c_office_count_range = 99
        self.lbc_c_capital_range = 99
        self.lbc_c_emp_count_range = 99
        self.lbc_c_sales_range = 99
        self.lbc_c_profit_range = 99
        self.lbc_c_is_ccng = 1
        self.cd_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2005)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2006, end_year=2010)))
        self.ua_list = dr.random_date_time(span_list=(dr.date_span(start_year=2011, end_year=2017)))
        self.vd_list = dr.random_date(span_list=(dr.date_span(start_year=2003, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(plm.header, plm.s1.nrows):

            plm.lbc_gid = str(plm.s1.cell(row, 2).value)
            plm.lbc_office_id = str(plm.s1.cell(row, 0).value)
            plm.lbc_c_office_id = plm.lbc_office_id
            plm.lbc_c_head_office_id = plm.lbc_office_id
            plm.lbc_c_top_head_office_id = plm.lbc_office_id
            plm.lbc_c_top_af_office_id1 = plm.lbc_office_id
            plm.lbc_c_affiliated_office_id1 = plm.lbc_office_id
            plm.lbc_formal_company_name = str(plm.s1.cell(row, 1).value)
            plm.lbc_company_name = str(plm.s1.cell(row, 1).value)
            plm.lbc_create_date = random.choice(plm.cd_list)
            plm.lbc_update_date = random.choice(plm.ud_list)
            plm.lbc_update_at = random.choice(plm.ua_list)
            plm.lbc_c_inv_date = random.choice(plm.vd_list)

            if '株' in plm.lbc_company_name:
                plm.lbc_company_abbreviated_name = "株式会社"
            else:
                plm.lbc_company_abbreviated_name = "法人格なし"

            if plm.lbc_company_name.startswith('株', 1, 4):
                plm.lbc_company_before_after = 1
            elif plm.lbc_company_name.endswith('株', 1, 4):
                plm.lbc_company_before_after = 2
            else:
                plm.lbc_company_before_after = 0

            if plm.lbc_company_before_after == 1:
                plm.lbc_company_before_after_name = "前"
            elif plm.lbc_company_before_after == 2:
                plm.lbc_company_before_after_name = "後"
            else:
                plm.lbc_company_before_after_name = "不明"

            plm.rows.append(
                [
                    plm.lbc_gid, plm.lbc_office_id, plm.lbc_company_abbreviated_flag, plm.lbc_company_abbreviated_name,
                    plm.lbc_company_before_after, plm.lbc_company_before_after_name, plm.lbc_company_name,
                    plm.lbc_formal_company_name, plm.lbc_office_name, plm.lbc_industry_code1_large,
                    plm.lbc_industry_code1_medium, plm.lbc_industry_code1_small, plm.lbc_industry_code1_tiny,
                    plm.lbc_industry_code2_large, plm.lbc_industry_code2_medium, plm.lbc_industry_code2_small,
                    plm.lbc_industry_code2_tiny, plm.lbc_industry_code3_large, plm.lbc_industry_code3_medium,
                    plm.lbc_industry_code3_small, plm.lbc_industry_code3_tiny, plm.lbc_create_date, plm.lbc_update_date,
                    plm.lbc_update_at, plm.lbc_c_office_id, plm.lbc_c_head_office_id, plm.lbc_c_top_head_office_id,
                    plm.lbc_c_top_af_office_id1, plm.lbc_c_affiliated_office_id1, plm.lbc_c_relation_flag1,
                    plm.lbc_c_listed_code, plm.lbc_c_sec_code, plm.lbc_c_yuho_number, plm.lbc_c_hyouten,
                    plm.lbc_c_company_name, plm.lbc_c_company_name_kana, plm.lbc_c_office_name, plm.lbc_c_building_name,
                    plm.lbc_c_company_pref_id, plm.lbc_c_company_city_id, plm.lbc_c_company_zip, plm.lbc_c_tel,
                    plm.lbc_c_fax, plm.lbc_c_office_count, plm.lbc_c_office_count_range, plm.lbc_c_setup_date,
                    plm.lbc_c_capital, plm.lbc_c_capital_range, plm.lbc_c_emp_count, plm.lbc_c_emp_count_range,
                    plm.lbc_c_sales, plm.lbc_c_sales_range, plm.lbc_c_settlement_month, plm.lbc_c_profit,
                    plm.lbc_c_profit_range, plm.lbc_c_license, plm.lbc_c_organizations, plm.lbc_c_inv_date,
                    plm.lbc_c_company_kind, plm.lbc_c_has_url, plm.lbc_c_has_foreign_flag, plm.lbc_c_is_head_office,
                    plm.lbc_c_stat_ng, plm.lbc_c_is_ccng, plm.lbc_c_is_mujin_office, plm.lbc_c_office_class,
                    plm.lbc_c_corporate_number, plm.lbc_c_grade, plm.lbc_del_flag, plm.lbc_c_is_faxdm
                ]
            )
        plm.cs.savedata(rows=plm.rows, name='lbc', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    plm = Lbc()
    plm.main()
    del plm
