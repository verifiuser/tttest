# -*- coding: utf-8 -*-

__author__ = "Nobuyuki Ejiri (yukidome25@gmail.com)"
__copyright__ = "Copyright 2017, Nobuyuki Ejiri"
__license__ = "MIT"
__version__ = "0.01 2017/06/15"


class UnderId:

    def __init__(self):
        self.one = 1
        self._id = 0
        self.sid = 10000000000

    def calculation(self, count=''):

        self._id += (int(count) + self.one) - int(count)
        return str(self.sid + self._id)
