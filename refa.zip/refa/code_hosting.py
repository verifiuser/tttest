# -*- coding: utf-8 -*-

import xlrd
import random
import sys
import daterange
import csvparser
import switch


reload(sys)
sys.setdefaultencoding('utf-8')


class CodeHosting:

    def __init__(self):

        self.hosting_id = ""
        self.lbc_office_id = ""
        self.hosting_gid = ""
        self.hosting_update_at = ""

        dr = daterange.DataRange()
        rdt = daterange.RandomDataTime()
        self.sw = switch.Switch()
        self.cs = csvparser.CsvParser()

        book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
        sheets = book.sheets()
        self.s1 = sheets[0]

        self.header = 1
        self.sid = 10000000000
        date_list = dr.date_span(yearbefore=2007, yearafter=2016)
        self.ud_list = rdt.date_span(datelist=date_list)

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mch.header, mch.s1.nrows):

            mch.lbc_office_id = str(mch.s1.cell(row, 0).value)
            mch.hosting_gid = str(mch.s1.cell(row, 2).value)
            gn_count = int(mch.s1.cell(mch.sw.case(mch.s1.cell(row, 3).value), 5).value)

            for i in xrange(gn_count):

                mch.hosting_id = mch.hosting_gid + str(mch.sid + i)
                mch.hosting_update_at = random.choice(mch.ud_list)

                mch.rows.append(
                    [
                        mch.hosting_id, mch.lbc_office_id, mch.hosting_gid, mch.hosting_update_at
                    ]
                )
        mch.cs.savedata(rows=mch.rows, name='child_m_code_hosting', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mch = CodeHosting()
    mch.main()
    del mch
