# -*- coding: utf-8 -*-

import xlrd
import random
import sys
import daterange
import csvparser
import switch


reload(sys)
sys.setdefaultencoding('utf-8')


class VisitCard:

    def __init__(self):

        self.visit_proc_id = ""
        self.lbc_office_id = ""
        self.visit_gid = ""
        self.visit_member_name = ""
        self.visit_member_id = ""
        self.visit_action_id = ""
        self.visit_update_at = ""
        self.visit_del_flag = 0

        dr = daterange.DataRange()
        rdt = daterange.RandomDataTime()
        self.sw = switch.Switch()
        self.cs = csvparser.CsvParser()

        book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
        sheets = book.sheets()
        self.s1 = sheets[0]

        self.header = 1
        self.sid = 10000000000
        date_list = dr.date_span(yearbefore=2010, yearafter=2017)
        self.ud_list = rdt.date_span(datelist=date_list)

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(vct.header, vct.s1.nrows):

            vct.lbc_office_id = str(vct.s1.cell(row, 0).value)
            vct.visit_gid = str(vct.s1.cell(row, 2).value)
            gn_count = int(vct.s1.cell(vct.sw.case(vct.s1.cell(row, 3).value), 5).value)

            for i in xrange(gn_count):

                vct.visit_proc_id = vct.visit_gid + str(vct.sid + i)
                vct.visit_update_at = random.choice(vct.ud_list)

                vct.rows.append(
                    [
                        vct.visit_proc_id, vct.lbc_office_id, vct.visit_gid, vct.visit_member_name, vct.visit_member_id,
                        vct.visit_action_id, vct.visit_update_at, vct.visit_del_flag
                    ]
                )
        vct.cs.savedata(rows=vct.rows, name='child_visit_card_tbl', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    vct = VisitCard()
    vct.main()
    del vct
