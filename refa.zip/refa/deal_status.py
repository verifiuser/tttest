# -*- coding: utf-8 -*-

import xlrd
import random
import sys
import daterange
import csvparser
import switch


reload(sys)
sys.setdefaultencoding('utf-8')


class DealStatus:

    def __init__(self):

        self.deal_status_id = ""
        self.lbc_office_id = ""
        self.deal_deal_flag = 0
        self.deal_gid = ""
        self.deal_update_at = ""
        self.deal_del_flag = 0

        dr = daterange.DataRange()
        rdt = daterange.RandomDataTime()
        self.sw = switch.Switch()
        self.cs = csvparser.CsvParser()

        book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
        sheets = book.sheets()
        self.s1 = sheets[0]

        self.header = 1
        self.sid = 10000000000
        self.df_list = [1, 2, 3, 4, 5]
        date_list = dr.date_span(yearbefore=2007, yearafter=2016)
        self.dd_list = rdt.date_span(datelist=date_list)

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(ds.header, ds.s1.nrows):

            ds.lbc_office_id = str(ds.s1.cell(row, 0).value)
            ds.deal_gid = str(ds.s1.cell(row, 2).value)
            gn_count = int(ds.s1.cell(ds.sw.case(ds.s1.cell(row, 3).value), 5).value)

            for i in xrange(gn_count):

                ds.deal_status_id = ds.deal_gid + str(ds.sid + i)
                ds.deal_deal_flag = random.choice(ds.df_list)
                ds.deal_update_at = random.choice(ds.dd_list)

                ds.rows.append(
                    [
                        ds.deal_status_id, ds.lbc_office_id, ds.deal_deal_flag, ds.deal_gid, ds.deal_update_at,
                        ds.deal_del_flag
                    ]
                )
        ds.cs.savedata(rows=ds.rows, name='child_client_deal_status', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    ds = DealStatus()
    ds.main()
    del ds
