# -*- coding: utf-8 -*-

import xlrd
import random
import sys
import daterange
import csvparser
import switch


reload(sys)
sys.setdefaultencoding('utf-8')


class LiveAccess:

    def __init__(self):

        self.live_access_id = ""
        self.lbc_office_id = ""
        self.live_access_gid = ""
        self.live_access_access_date = ""
        self.live_access_referrer = ""
        self.live_access_site_url = ""
        self.live_access_search_word = ""
        self.live_access_live_page_url = ""
        self.live_access_cookie_id = ""
        self.live_access_create_at = ""
        self.live_access_category_id = 0
        self.live_access_hierarchy_path = ""

        dr = daterange.DataRange()
        rdt = daterange.RandomDataTime()
        rd = daterange.RandomData()
        self.sw = switch.Switch()
        self.cs = csvparser.CsvParser()

        book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
        sheets = book.sheets()
        self.s1 = sheets[0]

        self.header = 1
        self.sid = 10000000000
        self.referrer_list = ["android-app://com.Slack",
                              "android-app://com.google.android.apps.plus/https/plus.url.google.com/mobileapp",
                              "android-app://com.google.android.gm"]
        self.site_list = ["1",
                          "http://marketing.itmedia.co.jp/",
                          "http://marketing.itmedia.co.jp/mm/articles/0501/11/news094.html"]
        self.search_list = ["052-962-0311",
                            "http://www.landscape.co.jp/",
                            "〒103ｰ8419 東京都中央区日本橋本町2-7-1 NOF日本橋本町ビル5F 地図"]
        self.url_list = ["marketing.itmedia.co.jp",
                         "marketing.itmedia.co.jp/mm/articles/0501/11/news094.html",
                         "marketing.itmedia.co.jp/mm/articles/0501/11/news094_2.html"]
        self.category_list = [16, 15, 7]
        self.hierarchy_list = ["/4/16", "/2/15", "/1/7"]
        date_list = dr.date_span(yearbefore=2010, yearafter=2017)
        self.ac_list = rd.date_span(datelist=date_list)
        date_list = dr.date_span(yearbefore=2001, yearafter=2009)
        self.cr_list = rdt.date_span(datelist=date_list)

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mla.header, mla.s1.nrows):

            mla.lbc_office_id = str(mla.s1.cell(row, 0).value)
            mla.live_access_gid = str(mla.s1.cell(row, 2).value)
            gn_count = int(mla.s1.cell(mla.sw.case(mla.s1.cell(row, 3).value), 5).value)

            for i in xrange(gn_count):

                mla.live_access_id = mla.live_access_gid + str(mla.sid + i)
                mla.live_access_referrer = random.choice(mla.referrer_list)
                mla.live_access_site_url = random.choice(mla.site_list)
                mla.live_access_search_word = random.choice(mla.search_list)
                mla.live_access_live_page_url = random.choice(mla.url_list)
                mla.live_access_category_id = random.choice(mla.category_list)
                mla.live_access_hierarchy_path = random.choice(mla.hierarchy_list)
                mla.live_access_access_date = random.choice(mla.ac_list)
                mla.live_access_create_at = random.choice(mla.cr_list)

                mla.rows.append(
                    [
                        mla.live_access_id, mla.lbc_office_id, mla.live_access_gid, mla.live_access_access_date,
                        mla.live_access_referrer, mla.live_access_site_url, mla.live_access_search_word,
                        mla.live_access_live_page_url, mla.live_access_cookie_id, mla.live_access_create_at,
                        mla.live_access_category_id, mla.live_access_hierarchy_path
                    ]
                )
        mla.cs.savedata(rows=mla.rows, name='child_client_mst_liveaccess', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mla = LiveAccess()
    mla.main()
    del mla
