#!/bin/sh

# サービスを停止
sudo service target-search-api stop

# デプロイ済みのターゲット検索APIを削除
sudo rm /opt/es_api/TargetSearchWeb.jar

# デプロイ対象のjarファイルをコピー
sudo cp /home/ec2-user/TargetSearchWeb-1.0.jar /opt/es_api/TargetSearchWeb.jar

# パーミッション変更
sudo chmod u+x /opt/es_api/TargetSearchWeb.jar

# 所有者変更
sudo chown root.root /opt/es_api/TargetSearchWeb.jar

# サービスを起動
sudo service target-search-api start
