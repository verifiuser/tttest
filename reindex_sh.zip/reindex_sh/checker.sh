#!/bin/sh
#
# checker
# Query速度検証の自動化
#
# 実行例)
# $ sh checker.sh 100 001 &
# or
# $ (time sh checker.sh 1000 001) > time_xxx_001.txt 2>&1 &
#
# 第一引数：繰り返し行う回数を指定
# 第二引数：作成したクエリーJSONの番号を指定
#
# 定数IPは検証を行いたいIPアドレスに変更してください
# 定数INDEXはElasticsearchのindexを指定
# 定数TYPEはElasticsearchのtypeを指定
#
# TYPEを使用しない場合は変数のsearchをコメントアウトし、agg_searchに切り替えてください
#
# sleepで1秒間隔で実行するように設定してますが、待ち時間は好きに変更してください
#
# ディレクトリ構成簡易説明：
# work/
# workディレクトリの名前は好きに変更して頂いて問題ありません
# work配下の構成はそのままで使えるので、測定を行いたいサーバへそのまま置いて実行してください
# work配下ディレクトリ構成を変更する場合は、各定数で指定しているPATHを変更してください
#
# tmp/curl_env.txt
# 測定結果のフォーマットになるので、出力結果を変更したい場合こちらを編集してください
#
# query/
# ここに速度検証で使用したいクエリをJSONにして保存してください
# デフォルトはファイル名query_001.jsonのかたち
# "query_"の部分を変更する場合は定数のNAMEを変更してください
# "001"は第二引数で使用する番号になります、複数クエリがあっても指定したクエリの番号で指定して実行できるようにしてます
# >> 番号でなくてもわかればなんでもいいかと
#
# result/query/
# ここに検索を行ったクエリの結果が出力
# result/speed/
# ここに測定した結果が出力
#

if [ "$1" -eq "" ]; then
	echo "please specify loop count."
	exit 1;
elif [ "$2" -eq "" ]; then
	echo "please specify target query_number."
	exit 1;
fi

COUNT=$1
NUM=$2

URI=http://
IP=localhost
PORT=9200

HOST=`echo ${URI}${IP}:${PORT}/`

INDEX="test_index"
TYPE="test"

API="_search"
FORMAT="pretty"

TMP_PATH="../tmp/"
QUERY="../query/"
OUTPUT="../result/"
R_1="query/"
R_2="speed/"

NAME="query_"
CONFIG="curl_env.txt"

query=`echo ${OUTPUT}${R_1}`
speed=`echo ${OUTPUT}${R_2}`
search=`echo ${HOST}${INDEX}/${TYPE}/${API}?${FORMAT}`
#agg_search=`echo ${HOST}${INDEX}/${API}?${FORMAT}`
rconf=`echo ${TMP_PATH}${CONFIG}`

for i in `seq ${COUNT}`
do
    echo `date "+%Y%m%d %H:%M:%S"` >> ${speed}result_${i}.txt
    curl -o ${query}result_${NAME}${NUM}_${i}.txt -XGET ${search} -d @${QUERY}${NAME}${NUM}.json -w @${rconf} -s >> ${speed}result_${NAME}${NUM}_${i}.txt
    #curl -o ${query}result_${NAME}${NUM}_${i}.txt -XGET ${agg_search} -d @${QUERY}${NAME}${NUM}.json -w @${rconf} -s >> ${speed}result_${NAME}${NUM}_${i}.txt
    #echo -n -e "\n"
    sleep 1s
done
