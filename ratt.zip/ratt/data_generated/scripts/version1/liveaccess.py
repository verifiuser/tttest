# -*- coding: utf-8 -*-

import random
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil


class LiveAccess:

    def __init__(self):

        self.live_access_id = ""
        self.lbc_office_id = ""
        self.live_access_gid = ""
        self.live_access_access_date = ""
        self.live_access_referrer = ""
        self.live_access_site_url = ""
        self.live_access_search_word = ""
        self.live_access_live_page_url = ""
        self.live_access_cookie_id = ""
        self.live_access_create_at = ""
        self.live_access_category_id = 0
        self.live_access_hierarchy_path = ""

        self.lu = landutil.LandUtil('liveaccess')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ac_list = dr.random_date(span_list=(dr.date_span(start_year=2010, end_year=2017)))
        self.cr_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2009)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mla.ew.header, mla.ew.count_rows):

            mla.lbc_office_id = mla.ew.get_cell_str(row=row, col=0)
            mla.live_access_gid = mla.ew.get_cell_str(row=row, col=2)
            gn_count = mla.ew.get_cell_int(row=(mla.sw.case(mla.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                mla.live_access_id = mla.live_access_gid + "-" + mla.udi.calculation(count=i)
                mla.live_access_referrer = mla.lu.get_nr('referrer')
                mla.live_access_site_url = mla.lu.get_nr('site_url')
                mla.live_access_search_word = mla.lu.get_nr('search_word')
                mla.live_access_live_page_url = mla.lu.get_nr('live_page_url')
                mla.live_access_category_id = mla.lu.get_nr('category_id')
                mla.live_access_hierarchy_path = mla.lu.get_nr('hierarchy_path')
                mla.live_access_access_date = random.choice(mla.ac_list)
                mla.live_access_create_at = random.choice(mla.cr_list)

                mla.rows.append(
                    [
                        mla.live_access_id, mla.lbc_office_id, mla.live_access_gid, mla.live_access_access_date,
                        mla.live_access_referrer, mla.live_access_site_url, mla.live_access_search_word,
                        mla.live_access_live_page_url, mla.live_access_cookie_id, mla.live_access_create_at,
                        mla.live_access_category_id, mla.live_access_hierarchy_path
                    ]
                )
        mla.cs.savedata(rows=mla.rows, name='liveaccess', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mla = LiveAccess()
    mla.main()
    del mla
