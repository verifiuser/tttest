# -*- coding: utf-8 -*-

import random
import daterange
import csvparser
import switch
import underid
import excelwrapper


class Visit:

    def __init__(self):

        self.visit_proc_id = ""
        self.lbc_office_id = ""
        self.visit_gid = ""
        self.visit_member_name = ""
        self.visit_member_id = ""
        self.visit_action_id = ""
        self.visit_update_at = ""
        self.visit_del_flag = 0

        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2010, end_year=2017)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(vct.ew.header, vct.ew.count_rows):

            vct.lbc_office_id = vct.ew.get_cell_str(row=row, col=0)
            vct.visit_gid = vct.ew.get_cell_str(row=row, col=2)
            gn_count = vct.ew.get_cell_int(row=(vct.sw.case(vct.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                vct.visit_proc_id = vct.visit_gid + "-" + vct.udi.calculation(count=i)
                vct.visit_update_at = random.choice(vct.ud_list)

                vct.rows.append(
                    [
                        vct.visit_proc_id, vct.lbc_office_id, vct.visit_gid, vct.visit_member_name, vct.visit_member_id,
                        vct.visit_action_id, vct.visit_update_at, vct.visit_del_flag
                    ]
                )
        vct.cs.savedata(rows=vct.rows, name='visit', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    vct = Visit()
    vct.main()
    del vct
