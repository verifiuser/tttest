# -*- coding: utf-8 -*-

import random
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil


class Act:

    def __init__(self):

        self.act_doc_id = ""
        self.lbc_office_id = ""
        self.act_gid = ""
        self.act_title = ""
        self.act_remarks = ""
        self.act_reg_date = ""
        self.act_div = ""
        self.act_proc_type = ""
        self.act_products = ""
        self.act_member_name = ""
        self.act_must_party = ""
        self.act_party = ""
        self.act_end_date = ""
        self.act_update_at = ""
        self.act_del_flag = 0

        self.lu = landutil.LandUtil('act')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.rg_ed_list = dr.random_date_time(span_list=(dr.date_span(start_year=2001, end_year=2005)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2006, end_year=2016)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(an.ew.header, an.ew.count_rows):

            an.lbc_office_id = an.ew.get_cell_str(row=row, col=0)
            an.act_gid = an.ew.get_cell_str(row=row, col=2)
            gn_count = an.ew.get_cell_int(row=(an.sw.case(an.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                an.act_doc_id = an.act_gid + "-" + an.udi.calculation(count=i)
                an.act_title = an.lu.get_nr('title')
                an.act_remarks = an.lu.get_nr('remarks')
                an.act_div = an.lu.get_nr('div')
                an.act_proc_type = an.lu.get_nr('proc_type')
                an.act_products = an.lu.get_nr('products')
                an.act_member_name = an.lu.get_nr('member_name')
                an.act_must_party = an.lu.get_nr('must_party')
                an.act_party = an.lu.get_nr('party')
                an.act_reg_date = random.choice(an.rg_ed_list)
                an.act_end_date = random.choice(an.rg_ed_list)
                an.act_update_at = random.choice(an.ud_list)

                an.rows.append(
                    [
                        an.act_doc_id, an.lbc_office_id, an.act_gid, an.act_title, an.act_remarks, an.act_reg_date,
                        an.act_div, an.act_proc_type, an.act_products, an.act_member_name, an.act_must_party,
                        an.act_party, an.act_end_date, an.act_update_at, an.act_del_flag
                    ]
                )
        an.cs.savedata(rows=an.rows, name='act', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    an = Act()
    an.main()
    del an
