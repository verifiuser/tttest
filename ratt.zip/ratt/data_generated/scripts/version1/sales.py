# -*- coding: utf-8 -*-

import random
import daterange
import csvparser
import switch
import underid
import excelwrapper
import landutil


class Sales:

    def __init__(self):

        self.sales_id = ""
        self.lbc_office_id = ""
        self.sales_gid = ""
        self.sales_product_id = ""
        self.sales_date = ""
        self.sales_amount = 0
        self.sales_update_at = ""
        self.sales_del_flag = 0

        self.lu = landutil.LandUtil('sales')
        self.ew = excelwrapper.ExcelWrapper('./data/landscape_dummy_data_definition_file.xls', 0)
        dr = daterange.DataRange()
        self.sw = switch.Switch(["A", "B", "C", "D"])
        self.udi = underid.UnderId()
        self.cs = csvparser.CsvParser()

        self.sd_list = dr.random_date_ym(span_list=(dr.date_span(start_year=2001, end_year=2017)))
        self.ud_list = dr.random_date_time(span_list=(dr.date_span(start_year=2010, end_year=2017)))

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(ms.ew.header, ms.ew.count_rows):

            ms.lbc_office_id = ms.ew.get_cell_str(row=row, col=0)
            ms.sales_gid = ms.ew.get_cell_str(row=row, col=2)
            gn_count = ms.ew.get_cell_int(row=(ms.sw.case(ms.ew.get_cell_str(row=row, col=3))), col=5)

            for i in xrange(gn_count):

                ms.sales_id = ms.sales_gid + "-" + ms.udi.calculation(count=i)
                ms.sales_product_id = ms.lu.get_nr('product_id')
                ms.sales_amount = ms.lu.get_calc('amount')
                ms.sales_date = random.choice(ms.sd_list)
                ms.sales_update_at = random.choice(ms.ud_list)

                ms.rows.append(
                    [
                        ms.sales_id, ms.lbc_office_id, ms.sales_gid, ms.sales_product_id, ms.sales_date,
                        ms.sales_amount, ms.sales_update_at, ms.sales_del_flag
                    ]
                )
        ms.cs.savedata(rows=ms.rows, name='sales', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    ms = Sales()
    ms.main()
    del ms
