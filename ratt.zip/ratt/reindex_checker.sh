#!/bin/sh

#if [ "$1" -eq "" ]; then
#    echo "please specify loop count."
#    exit 1;
#fi

COUNT=$1

URI=http://
IP=10.90.1.90
PORT=9200

HOST=`echo ${URI}${IP}:${PORT}/`

INDEX=test_reindex

REINDEXAPI=_reindex
DOCUMENTAPI=_delete_by_query
FORMAT=pretty

TMP_PATH="../tmp/"
QUERY="../query/"
OUTPUT="../result/"
R_1="query/"
R_2="speed/"

CONFIG="curl_env.txt"

query=`echo ${OUTPUT}${R_1}`
speed=`echo ${OUTPUT}${R_2}`
rconf=`echo ${TMP_PATH}${CONFIG}`

reindex=`echo ${HOST}${REINDEXAPI}?${FORMAT}`

reindex_query=reindex_query.json
delete_query=delete_query.json

target_parent=(lbc)
target_child=(act bizitem ct deal hosting liveaccess person sales stats visit)

for i in `seq ${COUNT}`
do
    echo `date "+%Y%m%d %H:%M:%S"` >> ${speed}result_${i}.txt
    curl -o ${query}result_${i}.txt -XPOST ${reindex} -d @${QUERY}reindex_query.json -w @${rconf} -s >> ${speed}result_reindex_${i}.txt

    sleep 1s

    #for c_type in "${target_child[@]}"
    #do
    #    C_URL=`echo ${HOST}${INDEX}/${c_type}/${DOCUMENTAPI}?${FORMAT}`
    #    curl -o ${query}result_${c_type}_${i}.txt -XPOST ${C_URL} -d @${QUERY}delete_query.json -w @${rconf} -s >> ${speed}delete_result_${c_type}_${i}.txt
    #done
    #for p_type in "${target_parent[@]}"
    #do
    #    P_URL=`echo ${HOST}${INDEX}/${p_type}/${DOCUMENTAPI}?${FORMAT}`
    #    curl -o ${query}result_${p_type}_${i}.txt -XPOST ${P_URL} -d @${QUERY}delete_query.json -w @${rconf} -s >> ${speed}delete_result_${p_type}_${i}.txt
    #done
done
