# -*- coding: utf-8 -*-
import xlrd
import random
import datetime
import codecs
import csv
import sys

reload(sys)
sys.setdefaultencoding('utf-8')

# ヘッダを除く企業情報取得の開始位置
CLUSTER_NAME_START_ROW = 1

# インデックス名の接頭辞
INDEX_NAME_PREFIX = 'dummy_data_create'


# class Dummy_data_create:
# noinspection PyUnboundLocalVariable
class CustomFormat(csv.excel):
    quoting = csv.QUOTE_ALL
    book = xlrd.open_workbook('landscape_dummy_data_definition_file_route.xls')
    sheets = book.sheets()

    # 定義シートを読み込む
    s1 = sheets[0]

    # ファイル名生成準備
    # 日時取得
    date = datetime.datetime.today()
    date_str_raw = str(date).split('.')
    date_str = date_str_raw[0]
    date_str = date_str.replace('-', '')

    # CSVを作成
    csv_file = codecs.open('child' + '_' + 'client_mst_liveaccess' + '.csv', 'w', 'utf-8')
    writer = csv.writer(csv_file)

    for row in range(CLUSTER_NAME_START_ROW, s1.nrows):

        # データ生成数の取得
        CLASS_OF_ENT = s1.cell(row, 3).value

        if CLASS_OF_ENT == u'A':
            CLASS_NUM = s1.cell(1, 5).value
        elif CLASS_OF_ENT == u'B':
            CLASS_NUM = s1.cell(2, 5).value
        elif CLASS_OF_ENT == u'C':
            CLASS_NUM = s1.cell(3, 5).value
        elif CLASS_OF_ENT == u'D':
            CLASS_NUM = s1.cell(4, 5).value

        CLASS_NUM = int(CLASS_NUM)

        # Oracle定義 : OFFICE_ID
        # ES定義 : lbc_office_id
        # 企業コード
        lbc_office_id = s1.cell(row, 0).value
        lbc_office_id = str(lbc_office_id)

        # Oracle定義 : GROUP_ID
        # ES定義 : liveaccess_gid
        # グループID
        liveaccess_gid = s1.cell(row, 2).value

        num = 0
        ct = 0
        liveaccess_access_date = u''
        liveaccess_create_at = u''

        while ct < CLASS_NUM:
            ct = ct + 1
            num = num + 1

            # Oracle定義 : LIVEACCESS_ID（LIVEACCESS_ID + GROUP_ID）
            # ES定義 : liveaccess_id
            # 主キー
            liveaccess_gid_str = str(liveaccess_gid)
            liveaccess_id_num = 10000000000 + num
            liveaccess_id_str = str(liveaccess_id_num)

            liveaccess_id = liveaccess_gid_str + liveaccess_id_str

            # Oracle定義 : ACCESS_DATE
            # ES定義 : liveaccess_access_date
            # アクセス日付        
            # liveaccess_access_dateの「年」生成
            R_YEAR = random.randint(2010, 2017)
            # liveaccess_access_dateの「月」生成
            if R_YEAR == 2017:
                R_MONTH = random.randint(1, 3)
            else:
                R_MONTH = random.randint(1, 12)
            # liveaccess_access_dateの「日」生成
            if R_MONTH == 1:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 2:
                R_DAY = random.randint(1, 28)
            elif R_MONTH == 3:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 4:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 5:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 6:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 7:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 8:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 9:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 10:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 11:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 12:
                R_DAY = random.randint(1, 31)

            R_YEAR_STR = str(R_YEAR)

            R_MONTH_STR = str(R_MONTH)
            if R_MONTH_STR == '1':
                R_MONTH_STR = '01'
            elif R_MONTH_STR == '2':
                R_MONTH_STR = '02'
            elif R_MONTH_STR == '3':
                R_MONTH_STR = '03'
            elif R_MONTH_STR == '4':
                R_MONTH_STR = '04'
            elif R_MONTH_STR == '5':
                R_MONTH_STR = '05'
            elif R_MONTH_STR == '6':
                R_MONTH_STR = '06'
            elif R_MONTH_STR == '7':
                R_MONTH_STR = '07'
            elif R_MONTH_STR == '8':
                R_MONTH_STR = '08'
            elif R_MONTH_STR == '9':
                R_MONTH_STR = '09'

            R_DAY_STR = str(R_DAY)
            if R_DAY_STR == '1':
                R_DAY_STR = '01'
            elif R_DAY_STR == '2':
                R_DAY_STR = '02'
            elif R_DAY_STR == '3':
                R_DAY_STR = '03'
            elif R_DAY_STR == '4':
                R_DAY_STR = '04'
            elif R_DAY_STR == '5':
                R_DAY_STR = '05'
            elif R_DAY_STR == '6':
                R_DAY_STR = '06'
            elif R_DAY_STR == '7':
                R_DAY_STR = '07'
            elif R_DAY_STR == '8':
                R_DAY_STR = '08'
            elif R_DAY_STR == '9':
                R_DAY_STR = '09'

            liveaccess_access_date = R_YEAR_STR + R_MONTH_STR + R_DAY_STR

            # Oracle定義 : REFERRER
            # ES定義 : liveaccess_referrer
            # リファーラー 
            referrer_num = random.randint(1, 3)

            if referrer_num == 1:
                liveaccess_referrer = u"android-app://com.Slack"
            elif referrer_num == 2:
                liveaccess_referrer = u"android-app://com.google.android.apps.plus/https/plus.url.google.com/mobileapp"
            elif referrer_num == 3:
                liveaccess_referrer = u"android-app://com.google.android.gm"

            # Oracle定義 : SEARCH_SITE_URL
            # ES定義 : liveaccess_site_url
            # 検索サイトURL（直前のページが検索サイトの場合）         
            site_num = random.randint(1, 3)

            if site_num == 1:
                liveaccess_site_url = u"1"
            elif site_num == 2:
                liveaccess_site_url = u"http://marketing.itmedia.co.jp/"
            elif site_num == 3:
                liveaccess_site_url = u"http://marketing.itmedia.co.jp/mm/articles/0501/11/news094.html"

            # Oracle定義 : SEARCH_WORD
            # ES定義 : liveaccess_search_word
            # 検索キーワード（直前のページが検索サイトの場合）
            search_num = random.randint(1, 3)

            if search_num == 1:
                liveaccess_search_word = u"052-962-0311"
            elif search_num == 2:
                liveaccess_search_word = u"http://www.landscape.co.jp/"
            elif search_num == 3:
                liveaccess_search_word = u"〒103ｰ8419 東京都中央区日本橋本町2-7-1 NOF日本橋本町ビル5F 地図"

            # Oracle定義 : LIVE_PAGE_URL
            # ES定義 : liveaccess_live_page_url
            # 表示されていページのURL（パラメータ等が取り除かれている）
            url_num = random.randint(1, 3)

            if url_num == 1:
                liveaccess_live_page_url = u"marketing.itmedia.co.jp"
            elif url_num == 2:
                liveaccess_live_page_url = u"marketing.itmedia.co.jp/mm/articles/0501/11/news094.html"
            elif url_num == 3:
                liveaccess_live_page_url = u"marketing.itmedia.co.jp/mm/articles/0501/11/news094_2.html"

            # Oracle定義 : COOKIE_ID
            # ES定義 : liveaccess_cookie_id
            # クッキーID
            liveaccess_cookie_id = u""

            # Oracle定義 : REG_DATE
            # ES定義 : liveaccess_create_at
            # 作成日（更新日の代わり）
            # liveaccess_create_atの「年」生成
            R_YEAR = random.randint(2001, 2009)
            # liveaccess_create_atの「月」生成
            if R_YEAR == 2017:
                R_MONTH = random.randint(1, 3)
            else:
                R_MONTH = random.randint(1, 12)
            # liveaccess_create_atの「日」生成
            if R_MONTH == 1:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 2:
                R_DAY = random.randint(1, 28)
            elif R_MONTH == 3:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 4:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 5:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 6:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 7:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 8:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 9:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 10:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 11:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 12:
                R_DAY = random.randint(1, 31)
            # liveaccess_create_atの「時」生成
            R_HOUR = random.randint(9, 23)
            # liveaccess_create_atの「分」生成
            R_MINUTES = random.randint(0, 59)
            # liveaccess_create_atの「秒」生成
            R_SECONDS = random.randint(0, 59)

            R_YEAR_STR = str(R_YEAR)

            R_MONTH_STR = str(R_MONTH)
            if R_MONTH_STR == '1':
                R_MONTH_STR = '01'
            elif R_MONTH_STR == '2':
                R_MONTH_STR = '02'
            elif R_MONTH_STR == '3':
                R_MONTH_STR = '03'
            elif R_MONTH_STR == '4':
                R_MONTH_STR = '04'
            elif R_MONTH_STR == '5':
                R_MONTH_STR = '05'
            elif R_MONTH_STR == '6':
                R_MONTH_STR = '06'
            elif R_MONTH_STR == '7':
                R_MONTH_STR = '07'
            elif R_MONTH_STR == '8':
                R_MONTH_STR = '08'
            elif R_MONTH_STR == '9':
                R_MONTH_STR = '09'

            R_DAY_STR = str(R_DAY)
            if R_DAY_STR == '1':
                R_DAY_STR = '01'
            elif R_DAY_STR == '2':
                R_DAY_STR = '02'
            elif R_DAY_STR == '3':
                R_DAY_STR = '03'
            elif R_DAY_STR == '4':
                R_DAY_STR = '04'
            elif R_DAY_STR == '5':
                R_DAY_STR = '05'
            elif R_DAY_STR == '6':
                R_DAY_STR = '06'
            elif R_DAY_STR == '7':
                R_DAY_STR = '07'
            elif R_DAY_STR == '8':
                R_DAY_STR = '08'
            elif R_DAY_STR == '9':
                R_DAY_STR = '09'

            R_HOUR_STR = str(R_HOUR)
            if R_HOUR_STR == '1':
                R_HOUR_STR = '01'
            elif R_HOUR_STR == '2':
                R_HOUR_STR = '02'
            elif R_HOUR_STR == '3':
                R_HOUR_STR = '03'
            elif R_HOUR_STR == '4':
                R_HOUR_STR = '04'
            elif R_HOUR_STR == '5':
                R_HOUR_STR = '05'
            elif R_HOUR_STR == '6':
                R_HOUR_STR = '06'
            elif R_HOUR_STR == '7':
                R_HOUR_STR = '07'
            elif R_HOUR_STR == '8':
                R_HOUR_STR = '08'
            elif R_HOUR_STR == '9':
                R_HOUR_STR = '09'

            R_MINUTES_STR = str(R_MINUTES)
            if R_MINUTES_STR == '1':
                R_MINUTES_STR = '01'
            elif R_MINUTES_STR == '2':
                R_MINUTES_STR = '02'
            elif R_MINUTES_STR == '3':
                R_MINUTES_STR = '03'
            elif R_MINUTES_STR == '4':
                R_MINUTES_STR = '04'
            elif R_MINUTES_STR == '5':
                R_MINUTES_STR = '05'
            elif R_MINUTES_STR == '6':
                R_MINUTES_STR = '06'
            elif R_MINUTES_STR == '7':
                R_MINUTES_STR = '07'
            elif R_MINUTES_STR == '8':
                R_MINUTES_STR = '08'
            elif R_MINUTES_STR == '9':
                R_MINUTES_STR = '09'

            R_SECONDS_STR = str(R_SECONDS)
            if R_SECONDS_STR == '1':
                R_SECONDS_STR = '01'
            elif R_SECONDS_STR == '2':
                R_SECONDS_STR = '02'
            elif R_SECONDS_STR == '3':
                R_SECONDS_STR = '03'
            elif R_SECONDS_STR == '4':
                R_SECONDS_STR = '04'
            elif R_SECONDS_STR == '5':
                R_SECONDS_STR = '05'
            elif R_SECONDS_STR == '6':
                R_SECONDS_STR = '06'
            elif R_SECONDS_STR == '7':
                R_SECONDS_STR = '07'
            elif R_SECONDS_STR == '8':
                R_SECONDS_STR = '08'
            elif R_SECONDS_STR == '9':
                R_SECONDS_STR = '09'

            liveaccess_create_at = '{0}/{1}/{2} {3}:{4}:{5}'.format(R_YEAR_STR, R_MONTH_STR, R_DAY_STR, R_HOUR_STR,
                                                                    R_MINUTES_STR, R_SECONDS_STR)

            # Oracle定義 : CATEGORY_ID
            # ES定義 : liveaccess_category_id
            # ページカテゴリID
            # liveaccess_category_id = u""
            category_list = [16, 15, 7]
            liveaccess_category_id = random.choice(category_list)

            # Oracle定義 : HIERARCHY_PATH
            # ES定義 : liveaccess_hierarchy_path
            # 階層パス
            # liveaccess_hierarchy_path = u""
            hierarchy_list = ["/4/16", "/2/15", "/1/7"]
            liveaccess_hierarchy_path = random.choice(hierarchy_list)

            rows = [(liveaccess_id, lbc_office_id, liveaccess_gid, liveaccess_access_date, liveaccess_referrer,
                     liveaccess_site_url, liveaccess_search_word, liveaccess_live_page_url, liveaccess_cookie_id,
                     liveaccess_create_at, liveaccess_category_id, liveaccess_hierarchy_path)]
            writer.writerows(rows)

    csv_file.close()
