# -*- coding: utf-8 -*-
import xlrd
import random
import datetime
import codecs
import csv
import sys

reload(sys)
sys.setdefaultencoding('utf-8')

# ヘッダを除く企業情報取得の開始位置
CLUSTER_NAME_START_ROW = 1

# インデックス名の接頭辞
INDEX_NAME_PREFIX = 'dummy_data_create'


# class Dummy_data_create:
# noinspection PyUnboundLocalVariable
class CustomFormat(csv.excel):
    quoting = csv.QUOTE_ALL
    book = xlrd.open_workbook('landscape_dummy_data_definition_file_route.xls')
    sheets = book.sheets()

    # 定義シートを読み込む
    s1 = sheets[0]

    # ファイル名生成準備
    # 日時取得
    date = datetime.datetime.today()
    date_str_raw = str(date).split('.')
    date_str = date_str_raw[0]
    date_str = date_str.replace('-', '')

    # CSVを作成
    csv_file = codecs.open('child' + '_' + 'visit_card_tbl' + '.csv', 'w', 'utf-8')
    writer = csv.writer(csv_file)

    for row in range(CLUSTER_NAME_START_ROW, s1.nrows):

        # データ生成数の取得
        CLASS_OF_ENT = s1.cell(row, 3).value

        if CLASS_OF_ENT == u'A':
            CLASS_NUM = s1.cell(1, 5).value
        elif CLASS_OF_ENT == u'B':
            CLASS_NUM = s1.cell(2, 5).value
        elif CLASS_OF_ENT == u'C':
            CLASS_NUM = s1.cell(3, 5).value
        elif CLASS_OF_ENT == u'D':
            CLASS_NUM = s1.cell(4, 5).value

        # Oracle定義 : OFFICE_ID
        # ES定義 : lbc_office_id
        # 企業コード
        lbc_office_id = s1.cell(row, 0).value
        lbc_office_id = str(lbc_office_id)

        # Oracle定義 : GROUP_ID
        # ES定義 : visit_gid
        # グループID
        visit_gid = s1.cell(row, 2).value
        
        # Oracle定義 : DELETE_FLAG
        # ES定義 : visit_del_flag
        # 論理削除フラグ
        visit_del_flag = 0 
        
        num = 0
        ct = 0
        bizitem_update_at = u''
        while ct < CLASS_NUM:
            ct = ct + 1
            num = num + 1
            
            # Oracle定義 : PROC_NO（GROUP_ID + PROC_NO + PROC_REC_NO）
            # ES定義 : visit_proc_id
            # 主キー
            visit_gid_str = str(visit_gid)
            visit_proc_id_num = 10000000000 + num
            visit_proc_id_str = str(visit_proc_id_num)

            visit_proc_id = visit_gid_str + visit_proc_id_str

            # Oracle定義 : MEMBER_NAME
            # ES定義 : visit_member_name
            # 名刺受領者
            visit_member_name = u""

            # Oracle定義 : MEMBER_ID
            # ES定義 : visit_member_id
            # 名刺受領者ID
            visit_member_id = ""

            # Oracle定義 : ACTION_ID
            # ES定義 : visit_action_id
            # 案件フェーズ
            visit_action_id = u""

            # Oracle定義 : UPD_DATE
            # ES定義 : visit_update_at
            # 更新日
            # visit_update_atの「年」生成
            R_YEAR = random.randint(2010, 2017)
            # visit_update_atの「月」生成
            if R_YEAR == 2017:
                R_MONTH = random.randint(1, 3)
            else:
                R_MONTH = random.randint(1, 12)
            # visit_update_atの「日」生成
            if R_MONTH == 1:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 2:
                R_DAY = random.randint(1, 28)
            elif R_MONTH == 3:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 4:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 5:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 6:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 7:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 8:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 9:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 10:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 11:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 12:
                R_DAY = random.randint(1, 31)
            # visit_update_atの「時」生成
            R_HOUR = random.randint(9, 23)
            # visit_update_atの「分」生成
            R_MINUTES = random.randint(0, 59)
            # visit_update_atの「秒」生成
            R_SECONDS = random.randint(0, 59)

            R_YEAR_STR = str(R_YEAR)

            R_MONTH_STR = str(R_MONTH)
            if R_MONTH_STR == '1':
                R_MONTH_STR = '01'
            elif R_MONTH_STR == '2':
                R_MONTH_STR = '02'
            elif R_MONTH_STR == '3':
                R_MONTH_STR = '03'
            elif R_MONTH_STR == '4':
                R_MONTH_STR = '04'
            elif R_MONTH_STR == '5':
                R_MONTH_STR = '05'
            elif R_MONTH_STR == '6':
                R_MONTH_STR = '06'
            elif R_MONTH_STR == '7':
                R_MONTH_STR = '07'
            elif R_MONTH_STR == '8':
                R_MONTH_STR = '08'
            elif R_MONTH_STR == '9':
                R_MONTH_STR = '09'

            R_DAY_STR = str(R_DAY)
            if R_DAY_STR == '1':
                R_DAY_STR = '01'
            elif R_DAY_STR == '2':
                R_DAY_STR = '02'
            elif R_DAY_STR == '3':
                R_DAY_STR = '03'
            elif R_DAY_STR == '4':
                R_DAY_STR = '04'
            elif R_DAY_STR == '5':
                R_DAY_STR = '05'
            elif R_DAY_STR == '6':
                R_DAY_STR = '06'
            elif R_DAY_STR == '7':
                R_DAY_STR = '07'
            elif R_DAY_STR == '8':
                R_DAY_STR = '08'
            elif R_DAY_STR == '9':
                R_DAY_STR = '09'

            R_HOUR_STR = str(R_HOUR)
            if R_HOUR_STR == '1':
                R_HOUR_STR = '01'
            elif R_HOUR_STR == '2':
                R_HOUR_STR = '02'
            elif R_HOUR_STR == '3':
                R_HOUR_STR = '03'
            elif R_HOUR_STR == '4':
                R_HOUR_STR = '04'
            elif R_HOUR_STR == '5':
                R_HOUR_STR = '05'
            elif R_HOUR_STR == '6':
                R_HOUR_STR = '06'
            elif R_HOUR_STR == '7':
                R_HOUR_STR = '07'
            elif R_HOUR_STR == '8':
                R_HOUR_STR = '08'
            elif R_HOUR_STR == '9':
                R_HOUR_STR = '09'

            R_MINUTES_STR = str(R_MINUTES)
            if R_MINUTES_STR == '1':
                R_MINUTES_STR = '01'
            elif R_MINUTES_STR == '2':
                R_MINUTES_STR = '02'
            elif R_MINUTES_STR == '3':
                R_MINUTES_STR = '03'
            elif R_MINUTES_STR == '4':
                R_MINUTES_STR = '04'
            elif R_MINUTES_STR == '5':
                R_MINUTES_STR = '05'
            elif R_MINUTES_STR == '6':
                R_MINUTES_STR = '06'
            elif R_MINUTES_STR == '7':
                R_MINUTES_STR = '07'
            elif R_MINUTES_STR == '8':
                R_MINUTES_STR = '08'
            elif R_MINUTES_STR == '9':
                R_MINUTES_STR = '09'

            R_SECONDS_STR = str(R_SECONDS)
            if R_SECONDS_STR == '1':
                R_SECONDS_STR = '01'
            elif R_SECONDS_STR == '2':
                R_SECONDS_STR = '02'
            elif R_SECONDS_STR == '3':
                R_SECONDS_STR = '03'
            elif R_SECONDS_STR == '4':
                R_SECONDS_STR = '04'
            elif R_SECONDS_STR == '5':
                R_SECONDS_STR = '05'
            elif R_SECONDS_STR == '6':
                R_SECONDS_STR = '06'
            elif R_SECONDS_STR == '7':
                R_SECONDS_STR = '07'
            elif R_SECONDS_STR == '8':
                R_SECONDS_STR = '08'
            elif R_SECONDS_STR == '9':
                R_SECONDS_STR = '09'

            visit_update_at = '{0}/{1}/{2} {3}:{4}:{5}'.format(R_YEAR_STR, R_MONTH_STR, R_DAY_STR, R_HOUR_STR,
                                                               R_MINUTES_STR, R_SECONDS_STR)

            rows = [(visit_proc_id, lbc_office_id, visit_gid, visit_member_name, visit_member_id, visit_action_id,
                     visit_update_at, visit_del_flag)]
            writer.writerows(rows)

    csv_file.close()
