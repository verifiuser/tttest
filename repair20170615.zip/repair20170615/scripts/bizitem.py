# -*- coding: utf-8 -*-

import xlrd
import random
import sys
import daterange
import csvparser
import switch


reload(sys)
sys.setdefaultencoding('utf-8')


class BizItem:

    def __init__(self):
        self.biz_item_id = ""
        self.lbc_office_id = ""
        self.biz_item_gid = ""
        self.biz_item_status = ""
        self.biz_item_product = ""
        self.biz_item_price = 0
        self.biz_item_probability = 0
        self.biz_item_end_date = ""
        self.biz_item_update_at = ""
        self.biz_item_del_flag = 0

        dr = daterange.DataRange()
        rd = daterange.RandomData()
        rdt = daterange.RandomDataTime()
        self.sw = switch.Switch()
        self.cs = csvparser.CsvParser()

        book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
        sheets = book.sheets()
        self.s1 = sheets[0]

        self.header = 1
        self.sid = 10000000000
        self.status_list = ["01", "02", "03", "04", "05", "06", "07"]
        self.product_list = ["DISH001", "DISH002", "DM001"]
        self.price_list = [i for i in xrange(100, 100000)]
        self.pro_list = [0, 10, 20, 40, 50, 80, 90, 100]
        date_list = dr.date_span(yearbefore=2010, yearafter=2017)
        self.ed_list = rd.date_span(datelist=date_list)
        date_list = dr.date_span(yearbefore=2007, yearafter=2016)
        self.ud_list = rdt.date_span(datelist=date_list)

        self.rows = []

    @staticmethod
    def main():

        for row in xrange(mbi.header, mbi.s1.nrows):

            mbi.lbc_office_id = str(mbi.s1.cell(row, 0).value)
            mbi.biz_item_gid = str(mbi.s1.cell(row, 2).value)
            gn_count = int(mbi.s1.cell(mbi.sw.case(mbi.s1.cell(row, 3).value), 5).value)

            for i in xrange(gn_count):

                mbi.biz_item_id = mbi.biz_item_gid + str(mbi.sid + i)
                mbi.biz_item_status = random.choice(mbi.status_list)
                mbi.biz_item_product = random.choice(mbi.product_list)
                mbi.biz_item_price = random.choice(mbi.price_list)
                mbi.biz_item_probability = random.choice(mbi.pro_list)
                mbi.biz_item_end_date = random.choice(mbi.ed_list)
                mbi.biz_item_update_at = random.choice(mbi.ud_list)

                mbi.rows.append(
                    [
                        mbi.biz_item_id, mbi.lbc_office_id, mbi.biz_item_gid, mbi.biz_item_status, mbi.biz_item_product,
                        mbi.biz_item_price, mbi.biz_item_probability, mbi.biz_item_end_date, mbi.biz_item_update_at,
                        mbi.biz_item_del_flag
                    ]
                )
        mbi.cs.savedata(rows=mbi.rows, name='child_client_mst_bizitem', extension='.csv', encode='utf-8')

if __name__ == "__main__":

    mbi = BizItem()
    mbi.main()
    del mbi
