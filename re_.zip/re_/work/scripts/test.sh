#!/bin/sh

curl -o result.txt -XPOST 'http://10.90.1.90:9200/_reindex?pretty' -d '{ "source": { "index": "lbc_verification" }, "dest": { "index": "lbc_verification_2" } }' -w @/home/ec2-user/data_generated/work/tmp/curl_env.txt -s >> result_001.txt


#curl -XDELETE 'http://10.90.1.90:9200/lbc_verification_2'

