#/bin/sh

COUNT=$1
NUM=$2

HOST="http://10.90.1.90:9200/"
INDEX="lbc_verification/"
TYPE="lbc/"
OPTION="_search?pretty"

TMP_PATH="../tmp/"
QUERY="../query/"
OUTPUT="../result/"
R_1="query/"
R_2="speed/"

NAME="query_parent_"
#NAME="query_wc_"
#NAME="term_all_"
#NAME="all_"
#NAME="query_visit_"
#NAME="query_person_"
#NAME="query_ct_"
#NAME="query_hosting_"
#NAME="query_stats_"
#NAME="query_sales_"
#NAME="query_liveaccess_"
#NAME="query_bizitem_"
#NAME="query_act_"
#NAME="query_deal_"
#NAME="query_test_"
#NAME="query_all_"
CONFIG="curl_env.txt"


query=`echo ${OUTPUT}${R_1}`
speed=`echo ${OUTPUT}${R_2}`
search=`echo ${HOST}${INDEX}${TYPE}${OPTION}`
rconf=`echo ${TMP_PATH}${CONFIG}`

for i in `seq ${COUNT}`
do
    echo `date "+%Y%m%d %H:%M:%S"` >> ${speed}result_${i}.txt
    curl -o ${query}result_${i}.txt -XGET ${search} -d @${QUERY}${NAME}${NUM}.json -w @${rconf} -s >> ${speed}result_${i}.txt
    #echo -n -e "\n"
    #sleep 2s
    sleep 1s
done

