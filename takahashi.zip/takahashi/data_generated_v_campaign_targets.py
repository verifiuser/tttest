# -*- coding: utf-8 -*-
import xlrd
import random
import codecs
import csv
import sys
import hashlib

reload(sys)
sys.setdefaultencoding('utf-8')


# Class V_Campaign_Targets
# noinspection PyUnboundLocalVariable
class VCampaignTargets(csv.excel):
    # ヘッダを除く企業情報取得の開始位置
    HEADER_START_ROW = 1

    category_list = [1, 2, 3, 4, 5]
    target_list = [0, 1]
    action_list = [3008, 3152]
    product_list = ["US001", "DO002",
                    "DISH001", "DM001", "DM001/DS001", "DM002", "DO001", "ETC", "LBC001", "LBC001/DS001", "LBC001/ETC",
                    "LBC001/TM001", "TM001", "TM001/DM001/DS001", "US002"]
    type_list = [0, 1, 2, 3, 4, 5, 6, 7]

    # Oracle定義 : DEL_FLAG
    # ES定義 : ct_del_flag
    # 論理削除フラグ
    ct_del_flag = 0

    ct_action_date = u''
    ct_update_at = u''

    quoting = csv.QUOTE_ALL
    book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
    sheets = book.sheets()

    # 定義シートを読み込む
    s1 = sheets[0]

    # CSVを作成
    csv_file = codecs.open('child' + '_' + 'v_campaign_targets' + '.csv', 'w', 'utf-8')
    writer = csv.writer(csv_file)

    for row in xrange(HEADER_START_ROW, s1.nrows):

        # データ生成数の取得
        CLASS_OF_ENT = s1.cell(row, 3).value

        if CLASS_OF_ENT == u'A':
            CLASS_NUM = s1.cell(1, 5).value
        elif CLASS_OF_ENT == u'B':
            CLASS_NUM = s1.cell(2, 5).value
        elif CLASS_OF_ENT == u'C':
            CLASS_NUM = s1.cell(3, 5).value
        elif CLASS_OF_ENT == u'D':
            CLASS_NUM = s1.cell(4, 5).value

        CLASS_NUM = int(CLASS_NUM)

        # Oracle定義 : OFFICE_ID
        # ES定義 : lbc_office_id
        # 企業コード
        lbc_office_id = s1.cell(row, 0).value
        lbc_office_id = str(lbc_office_id)

        # Oracle定義 : GROUP_ID
        # ES定義 : ct_gid
        # グループID
        ct_gid = s1.cell(row, 2).value

        for i in xrange(CLASS_NUM):

            # Oracle定義 : TARGET_LIST_ID（GROUP_ID + TARGET_LIST_ID）
            # ES定義 : ct_id
            # 主キー
            ct_gid_str = str(ct_gid)
            ct_id_num = 10000000000 + i
            ct_id_str = str(ct_id_num)

            ct_id = ct_gid_str + ct_id_str

            # Oracle定義 : AITE_TANTO_UNID3
            # ES定義 : ct_unid3
            # 担当者ユニークID
            # ct_unid3 = u""
            ct_unid3 = hashlib.md5(ct_id + lbc_office_id).hexdigest()

            # Oracle定義 : CATEGORY
            # ES定義 : ct_category
            # ターゲットカテゴリ
            # ct_category = u""
            # ct_category = 1
            ct_category = random.choice(category_list)

            # Oracle定義 : TARGET_TYPE
            # ES定義 : ct_target_type
            # ターゲットタイプ
            ct_target_type = random.choice(target_list)

            # Oracle定義 : ACTION_ID
            # ES定義 : ct_action_id
            # キャンペーンID
            # ct_action_id = u""
            ct_action_id = random.choice(action_list)

            # Oracle定義 : ACTION_TYPE
            # ES定義 : ct_action_type
            # キャンペーンタイプID
            # ct_action_type = u""
            # ct_action_type = 1
            ct_action_type = random.choice(type_list)

            # Oracle定義 : PRODUCT_IDS
            # ES定義 : ct_product_ids
            # 商材（複数）ID
            # ct_product_ids = u""
            ct_product_ids = random.choice(product_list)

            # Oracle定義 : ACTION_DATE
            # ES定義 : ct_action_date
            # キャンペーン日付        
            # ct_action_dateの「年」生成
            R_YEAR = random.randint(2010, 2017)
            # ct_action_dateの「月」生成
            if R_YEAR == 2017:
                R_MONTH = random.randint(1, 3)
            else:
                R_MONTH = random.randint(1, 12)
            # ct_action_dateの「日」生成
            if R_MONTH == 1:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 2:
                R_DAY = random.randint(1, 28)
            elif R_MONTH == 3:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 4:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 5:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 6:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 7:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 8:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 9:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 10:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 11:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 12:
                R_DAY = random.randint(1, 31)

            R_YEAR_STR = str(R_YEAR)

            R_MONTH_STR = str(R_MONTH)
            if R_MONTH_STR == '1':
                R_MONTH_STR = '01'
            elif R_MONTH_STR == '2':
                R_MONTH_STR = '02'
            elif R_MONTH_STR == '3':
                R_MONTH_STR = '03'
            elif R_MONTH_STR == '4':
                R_MONTH_STR = '04'
            elif R_MONTH_STR == '5':
                R_MONTH_STR = '05'
            elif R_MONTH_STR == '6':
                R_MONTH_STR = '06'
            elif R_MONTH_STR == '7':
                R_MONTH_STR = '07'
            elif R_MONTH_STR == '8':
                R_MONTH_STR = '08'
            elif R_MONTH_STR == '9':
                R_MONTH_STR = '09'

            R_DAY_STR = str(R_DAY)
            if R_DAY_STR == '1':
                R_DAY_STR = '01'
            elif R_DAY_STR == '2':
                R_DAY_STR = '02'
            elif R_DAY_STR == '3':
                R_DAY_STR = '03'
            elif R_DAY_STR == '4':
                R_DAY_STR = '04'
            elif R_DAY_STR == '5':
                R_DAY_STR = '05'
            elif R_DAY_STR == '6':
                R_DAY_STR = '06'
            elif R_DAY_STR == '7':
                R_DAY_STR = '07'
            elif R_DAY_STR == '8':
                R_DAY_STR = '08'
            elif R_DAY_STR == '9':
                R_DAY_STR = '09'

            ct_action_date = R_YEAR_STR + R_MONTH_STR + R_DAY_STR

            # Oracle定義 : UPD_DATE
            # ES定義 : ct_update_at
            # 更新日付
            # liveaccess_create_atの「年」生成
            R_YEAR = random.randint(2001, 2009)
            # liveaccess_create_atの「月」生成
            if R_YEAR == 2017:
                R_MONTH = random.randint(1, 3)
            else:
                R_MONTH = random.randint(1, 12)
            # liveaccess_create_atの「日」生成
            if R_MONTH == 1:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 2:
                R_DAY = random.randint(1, 28)
            elif R_MONTH == 3:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 4:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 5:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 6:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 7:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 8:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 9:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 10:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 11:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 12:
                R_DAY = random.randint(1, 31)
            # liveaccess_create_atの「時」生成
            R_HOUR = random.randint(9, 23)
            # liveaccess_create_atの「分」生成
            R_MINUTES = random.randint(0, 59)
            # liveaccess_create_atの「秒」生成
            R_SECONDS = random.randint(0, 59)

            R_YEAR_STR = str(R_YEAR)

            R_MONTH_STR = str(R_MONTH)
            if R_MONTH_STR == '1':
                R_MONTH_STR = '01'
            elif R_MONTH_STR == '2':
                R_MONTH_STR = '02'
            elif R_MONTH_STR == '3':
                R_MONTH_STR = '03'
            elif R_MONTH_STR == '4':
                R_MONTH_STR = '04'
            elif R_MONTH_STR == '5':
                R_MONTH_STR = '05'
            elif R_MONTH_STR == '6':
                R_MONTH_STR = '06'
            elif R_MONTH_STR == '7':
                R_MONTH_STR = '07'
            elif R_MONTH_STR == '8':
                R_MONTH_STR = '08'
            elif R_MONTH_STR == '9':
                R_MONTH_STR = '09'

            R_DAY_STR = str(R_DAY)
            if R_DAY_STR == '1':
                R_DAY_STR = '01'
            elif R_DAY_STR == '2':
                R_DAY_STR = '02'
            elif R_DAY_STR == '3':
                R_DAY_STR = '03'
            elif R_DAY_STR == '4':
                R_DAY_STR = '04'
            elif R_DAY_STR == '5':
                R_DAY_STR = '05'
            elif R_DAY_STR == '6':
                R_DAY_STR = '06'
            elif R_DAY_STR == '7':
                R_DAY_STR = '07'
            elif R_DAY_STR == '8':
                R_DAY_STR = '08'
            elif R_DAY_STR == '9':
                R_DAY_STR = '09'

            R_HOUR_STR = str(R_HOUR)
            if R_HOUR_STR == '1':
                R_HOUR_STR = '01'
            elif R_HOUR_STR == '2':
                R_HOUR_STR = '02'
            elif R_HOUR_STR == '3':
                R_HOUR_STR = '03'
            elif R_HOUR_STR == '4':
                R_HOUR_STR = '04'
            elif R_HOUR_STR == '5':
                R_HOUR_STR = '05'
            elif R_HOUR_STR == '6':
                R_HOUR_STR = '06'
            elif R_HOUR_STR == '7':
                R_HOUR_STR = '07'
            elif R_HOUR_STR == '8':
                R_HOUR_STR = '08'
            elif R_HOUR_STR == '9':
                R_HOUR_STR = '09'
            elif R_HOUR_STR == '0':
                R_HOUR_STR = '00'

            R_MINUTES_STR = str(R_MINUTES)
            if R_MINUTES_STR == '1':
                R_MINUTES_STR = '01'
            elif R_MINUTES_STR == '2':
                R_MINUTES_STR = '02'
            elif R_MINUTES_STR == '3':
                R_MINUTES_STR = '03'
            elif R_MINUTES_STR == '4':
                R_MINUTES_STR = '04'
            elif R_MINUTES_STR == '5':
                R_MINUTES_STR = '05'
            elif R_MINUTES_STR == '6':
                R_MINUTES_STR = '06'
            elif R_MINUTES_STR == '7':
                R_MINUTES_STR = '07'
            elif R_MINUTES_STR == '8':
                R_MINUTES_STR = '08'
            elif R_MINUTES_STR == '9':
                R_MINUTES_STR = '09'
            elif R_MINUTES_STR == '0':
                R_MINUTES_STR = '00'

            R_SECONDS_STR = str(R_SECONDS)
            if R_SECONDS_STR == '1':
                R_SECONDS_STR = '01'
            elif R_SECONDS_STR == '2':
                R_SECONDS_STR = '02'
            elif R_SECONDS_STR == '3':
                R_SECONDS_STR = '03'
            elif R_SECONDS_STR == '4':
                R_SECONDS_STR = '04'
            elif R_SECONDS_STR == '5':
                R_SECONDS_STR = '05'
            elif R_SECONDS_STR == '6':
                R_SECONDS_STR = '06'
            elif R_SECONDS_STR == '7':
                R_SECONDS_STR = '07'
            elif R_SECONDS_STR == '8':
                R_SECONDS_STR = '08'
            elif R_SECONDS_STR == '9':
                R_SECONDS_STR = '09'
            elif R_SECONDS_STR == '0':
                R_SECONDS_STR = '00'

            ct_update_at = '{0}/{1}/{2} {3}:{4}:{5}'.format(R_YEAR_STR, R_MONTH_STR, R_DAY_STR, R_HOUR_STR,
                                                            R_MINUTES_STR, R_SECONDS_STR)

            rows = [(ct_id, lbc_office_id, ct_gid, ct_unid3, ct_category, ct_target_type, ct_action_id, ct_action_type,
                     ct_product_ids, ct_action_date, ct_update_at, ct_del_flag)]
            writer.writerows(rows)

    csv_file.close()
