# -*- coding: utf-8 -*-
import xlrd
import random
import codecs
import csv
import sys

reload(sys)
sys.setdefaultencoding('utf-8')


# Class Mst_Activity_New
# noinspection PyUnboundLocalVariable
class MstActivityNew(csv.excel):
    # ヘッダを除く企業情報取得の開始位置
    HEADER_START_ROW = 1

    title_list = ["株式会社ランドスケイプ ", "     佐藤様     山本様    ", "   村上農園　http://www.murakamifarm.com/"]
    rem_list = ["	【日本HP】11.担当者情報　カラム追加依頼 \
               【日本HP】10.活動履歴情報　結果区分項目追加依頼 \
               【日本HP】9.活動履歴情報　カラム追加依頼 ", "×	         	【理由】	●新規やらない為  \
                          ●拠点単位で取引が発生。●立ち上げて5年。●保守は件数は増えても、単価が下がる。保守先に消耗品を販売。純正＋消耗品。●保守先で1割。●既存へのアウェアネスを高める。● ",
                "https://www.nttcsol.com/topics/pdf/news_20160901.pdf←名前見つけるhttp://nttcsol-saiyo.com \
                                          /business/index.html#organization \
                                          ←採用ページより「経営企画部は経営戦略、事業計画、人事・人材育成、労務構成、財務、会計、総務、法務、社内システムなどを企画立案します。」 "]
    div_list = ['訪問', '来社', '社内打合せ']
    proc_list = ['004', '005', '006']
    product_list = ['LBC001', 'LBC001/DM001', 'LBC001/US002/DM002']
    member_list = ['秋山 友也', '中溝 祥影', '山本 友和']
    mparty_list = ['幸田 智', '木坊子 圭介¥t大槻 一樹', '江尻 信之¥t高橋 知浩¥t秋山 友也']
    party_list = ['幸田 智', '木坊子 圭介¥t大槻 一樹', '江尻 信之¥t高橋 知浩¥t秋山 友也']
    act_reg_date = u''
    act_update_at = u''

    # Oracle定義 : DEL_FLAG
    # ES定義 : act_del_flag
    # 論理削除フラグ
    act_del_flag = 0

    quoting = csv.QUOTE_ALL
    book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
    sheets = book.sheets()

    # 定義シートを読み込む
    s1 = sheets[0]

    # CSVを作成
    csv_file = codecs.open('child' + '_' + 'client_mst_activity_new' + '.csv', 'w', 'utf-8')
    writer = csv.writer(csv_file)

    for row in xrange(HEADER_START_ROW, s1.nrows):

        # データ生成数の取得
        CLASS_OF_ENT = s1.cell(row, 3).value

        if CLASS_OF_ENT == u'A':
            CLASS_NUM = s1.cell(1, 5).value
        elif CLASS_OF_ENT == u'B':
            CLASS_NUM = s1.cell(2, 5).value
        elif CLASS_OF_ENT == u'C':
            CLASS_NUM = s1.cell(3, 5).value
        elif CLASS_OF_ENT == u'D':
            CLASS_NUM = s1.cell(4, 5).value

        CLASS_NUM = int(CLASS_NUM)

        # Oracle定義 : OFFICE_ID
        # ES定義 : lbc_office_id
        # 企業コード
        lbc_office_id = s1.cell(row, 0).value
        lbc_office_id = str(lbc_office_id)

        # Oracle定義 : GROUP_ID 
        # ES定義 : act_gid
        # グループID
        act_gid = s1.cell(row, 2).value

        for i in xrange(CLASS_NUM):

            # Oracle定義 : DOC_UNIVERSAL_ID（GROUP_ID + DOC_UNIVERSAL_ID）
            # ES定義 : act_doc_id
            # 主キー
            act_gid_str = str(act_gid)
            act_doc_id_num = 10000000000 + i
            act_doc_id_str = str(act_doc_id_num)

            act_doc_id = act_gid_str + act_doc_id_str

            # Oracle定義 : TITLE
            # ES定義     : act_title
            # タイトル
            act_title = random.choice(title_list)

            # Oracle定義 : REMARKS
            # ES定義     : act_remkars
            # メモ
            act_remkars = random.choice(rem_list)

            # Oracle定義 : REG_DATE
            # ES定義     : act_reg_date
            # 作成日
            # act_reg_dateの「年」生成
            R_YEAR = random.randint(2001, 2005)
            # act_reg_dateの「月」生成
            if R_YEAR == 2017:
                R_MONTH = random.randint(1, 3)
            else:
                R_MONTH = random.randint(1, 12)
            # act_reg_dateの「日」生成
            if R_MONTH == 1:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 2:
                R_DAY = random.randint(1, 28)
            elif R_MONTH == 3:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 4:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 5:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 6:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 7:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 8:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 9:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 10:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 11:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 12:
                R_DAY = random.randint(1, 31)
            # act_reg_dateの「時」生成
            R_HOUR = random.randint(9, 23)
            # act_reg_dateの「分」生成
            R_MINUTES = random.randint(0, 59)
            # act_reg_dateの「秒」生成
            R_SECONDS = random.randint(0, 59)

            R_YEAR_STR = str(R_YEAR)

            R_MONTH_STR = str(R_MONTH)
            if R_MONTH_STR == '1':
                R_MONTH_STR = '01'
            elif R_MONTH_STR == '2':
                R_MONTH_STR = '02'
            elif R_MONTH_STR == '3':
                R_MONTH_STR = '03'
            elif R_MONTH_STR == '4':
                R_MONTH_STR = '04'
            elif R_MONTH_STR == '5':
                R_MONTH_STR = '05'
            elif R_MONTH_STR == '6':
                R_MONTH_STR = '06'
            elif R_MONTH_STR == '7':
                R_MONTH_STR = '07'
            elif R_MONTH_STR == '8':
                R_MONTH_STR = '08'
            elif R_MONTH_STR == '9':
                R_MONTH_STR = '09'

            R_DAY_STR = str(R_DAY)
            if R_DAY_STR == '1':
                R_DAY_STR = '01'
            elif R_DAY_STR == '2':
                R_DAY_STR = '02'
            elif R_DAY_STR == '3':
                R_DAY_STR = '03'
            elif R_DAY_STR == '4':
                R_DAY_STR = '04'
            elif R_DAY_STR == '5':
                R_DAY_STR = '05'
            elif R_DAY_STR == '6':
                R_DAY_STR = '06'
            elif R_DAY_STR == '7':
                R_DAY_STR = '07'
            elif R_DAY_STR == '8':
                R_DAY_STR = '08'
            elif R_DAY_STR == '9':
                R_DAY_STR = '09'

            R_HOUR_STR = str(R_HOUR)
            if R_HOUR_STR == '1':
                R_HOUR_STR = '01'
            elif R_HOUR_STR == '2':
                R_HOUR_STR = '02'
            elif R_HOUR_STR == '3':
                R_HOUR_STR = '03'
            elif R_HOUR_STR == '4':
                R_HOUR_STR = '04'
            elif R_HOUR_STR == '5':
                R_HOUR_STR = '05'
            elif R_HOUR_STR == '6':
                R_HOUR_STR = '06'
            elif R_HOUR_STR == '7':
                R_HOUR_STR = '07'
            elif R_HOUR_STR == '8':
                R_HOUR_STR = '08'
            elif R_HOUR_STR == '9':
                R_HOUR_STR = '09'
            elif R_HOUR_STR == '0':
                R_HOUR_STR = '00'

            R_MINUTES_STR = str(R_MINUTES)
            if R_MINUTES_STR == '1':
                R_MINUTES_STR = '01'
            elif R_MINUTES_STR == '2':
                R_MINUTES_STR = '02'
            elif R_MINUTES_STR == '3':
                R_MINUTES_STR = '03'
            elif R_MINUTES_STR == '4':
                R_MINUTES_STR = '04'
            elif R_MINUTES_STR == '5':
                R_MINUTES_STR = '05'
            elif R_MINUTES_STR == '6':
                R_MINUTES_STR = '06'
            elif R_MINUTES_STR == '7':
                R_MINUTES_STR = '07'
            elif R_MINUTES_STR == '8':
                R_MINUTES_STR = '08'
            elif R_MINUTES_STR == '9':
                R_MINUTES_STR = '09'
            elif R_MINUTES_STR == '0':
                R_MINUTES_STR = '00'

            R_SECONDS_STR = str(R_SECONDS)
            if R_SECONDS_STR == '1':
                R_SECONDS_STR = '01'
            elif R_SECONDS_STR == '2':
                R_SECONDS_STR = '02'
            elif R_SECONDS_STR == '3':
                R_SECONDS_STR = '03'
            elif R_SECONDS_STR == '4':
                R_SECONDS_STR = '04'
            elif R_SECONDS_STR == '5':
                R_SECONDS_STR = '05'
            elif R_SECONDS_STR == '6':
                R_SECONDS_STR = '06'
            elif R_SECONDS_STR == '7':
                R_SECONDS_STR = '07'
            elif R_SECONDS_STR == '8':
                R_SECONDS_STR = '08'
            elif R_SECONDS_STR == '9':
                R_SECONDS_STR = '09'
            elif R_SECONDS_STR == '0':
                R_SECONDS_STR = '00'

            act_reg_date = "{0}{1}{2}{3}{4}{5}".format(R_YEAR_STR, R_MONTH_STR, R_DAY_STR, R_HOUR_STR, R_MINUTES_STR,
                                                       R_SECONDS_STR)

            # Oracle定義 : ACT_DIV
            # ES定義     : act_act_div
            # 活動区分
            act_act_div = random.choice(div_list)

            # Oracle定義 : ACT_PROC_TYPE
            # ES定義     : act_proc_type
            # 活動区分タイプ
            act_proc_type = random.choice(proc_list)

            # Oracle定義 : PRODUCTS
            # ES定義     : act_products
            # 商材
            act_products = random.choice(product_list)

            # Oracle定義 : MEMBER_NAME
            # ES定義     : act_member_name
            # 主担当者
            act_member_name = random.choice(member_list)

            # Oracle定義 : MUST_PARTY
            # ES定義     : act_must_party
            # 必須同席者
            act_must_party = random.choice(mparty_list)

            # Oracle定義 : PARTY
            # ES定義     : act_party
            # 任意同席者
            act_party = random.choice(party_list)

            # Oracle定義 : END_DATE
            # ES定義     : act_end_date
            # 終了日 YYYYMMDD
            E_YEAR = random.randint(2001, 2005)
            # act_reg_dateの「月」生成
            if E_YEAR == 2017:
                E_MONTH = random.randint(1, 3)
            else:
                E_MONTH = random.randint(1, 12)
            # act_reg_dateの「日」生成
            if E_MONTH == 1:
                E_DAY = random.randint(1, 31)
            elif E_MONTH == 2:
                E_DAY = random.randint(1, 28)
            elif E_MONTH == 3:
                E_DAY = random.randint(1, 31)
            elif E_MONTH == 4:
                E_DAY = random.randint(1, 30)
            elif E_MONTH == 5:
                E_DAY = random.randint(1, 31)
            elif E_MONTH == 6:
                E_DAY = random.randint(1, 30)
            elif E_MONTH == 7:
                E_DAY = random.randint(1, 31)
            elif E_MONTH == 8:
                E_DAY = random.randint(1, 31)
            elif E_MONTH == 9:
                E_DAY = random.randint(1, 30)
            elif E_MONTH == 10:
                E_DAY = random.randint(1, 31)
            elif E_MONTH == 11:
                E_DAY = random.randint(1, 30)
            elif E_MONTH == 12:
                E_DAY = random.randint(1, 31)

            E_YEAR_STR = str(E_YEAR)

            E_MONTH_STR = str(E_MONTH)
            if E_MONTH_STR == '1':
                E_MONTH_STR = '01'
            elif E_MONTH_STR == '2':
                E_MONTH_STR = '02'
            elif E_MONTH_STR == '3':
                E_MONTH_STR = '03'
            elif E_MONTH_STR == '4':
                E_MONTH_STR = '04'
            elif E_MONTH_STR == '5':
                E_MONTH_STR = '05'
            elif E_MONTH_STR == '6':
                E_MONTH_STR = '06'
            elif E_MONTH_STR == '7':
                E_MONTH_STR = '07'
            elif E_MONTH_STR == '8':
                E_MONTH_STR = '08'
            elif E_MONTH_STR == '9':
                E_MONTH_STR = '09'

            E_DAY_STR = str(E_DAY)
            if E_DAY_STR == '1':
                E_DAY_STR = '01'
            elif E_DAY_STR == '2':
                E_DAY_STR = '02'
            elif E_DAY_STR == '3':
                E_DAY_STR = '03'
            elif E_DAY_STR == '4':
                E_DAY_STR = '04'
            elif E_DAY_STR == '5':
                E_DAY_STR = '05'
            elif E_DAY_STR == '6':
                E_DAY_STR = '06'
            elif E_DAY_STR == '7':
                E_DAY_STR = '07'
            elif E_DAY_STR == '8':
                E_DAY_STR = '08'
            elif E_DAY_STR == '9':
                E_DAY_STR = '09'

            act_end_date = E_YEAR_STR + E_MONTH_STR + E_DAY_STR

            # Oracle定義 : UPD_DATE
            # ES定義     : act_update_at
            # 更新日
            # act_update_atの「年」生成
            R_YEAR = random.randint(2006, 2016)
            # act_update_atの「月」生成
            if R_YEAR == 2017:
                R_MONTH = random.randint(1, 3)
            else:
                R_MONTH = random.randint(1, 12)
            # act_update_atの「日」生成
            if R_MONTH == 1:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 2:
                R_DAY = random.randint(1, 28)
            elif R_MONTH == 3:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 4:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 5:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 6:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 7:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 8:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 9:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 10:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 11:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 12:
                R_DAY = random.randint(1, 31)
            # act_update_atの「時」生成
            R_HOUR = random.randint(9, 23)
            # act_update_atの「分」生成
            R_MINUTES = random.randint(0, 59)
            # act_update_atの「秒」生成
            R_SECONDS = random.randint(0, 59)

            R_YEAR_STR = str(R_YEAR)

            R_MONTH_STR = str(R_MONTH)
            if R_MONTH_STR == '1':
                R_MONTH_STR = '01'
            elif R_MONTH_STR == '2':
                R_MONTH_STR = '02'
            elif R_MONTH_STR == '3':
                R_MONTH_STR = '03'
            elif R_MONTH_STR == '4':
                R_MONTH_STR = '04'
            elif R_MONTH_STR == '5':
                R_MONTH_STR = '05'
            elif R_MONTH_STR == '6':
                R_MONTH_STR = '06'
            elif R_MONTH_STR == '7':
                R_MONTH_STR = '07'
            elif R_MONTH_STR == '8':
                R_MONTH_STR = '08'
            elif R_MONTH_STR == '9':
                R_MONTH_STR = '09'

            R_DAY_STR = str(R_DAY)
            if R_DAY_STR == '1':
                R_DAY_STR = '01'
            elif R_DAY_STR == '2':
                R_DAY_STR = '02'
            elif R_DAY_STR == '3':
                R_DAY_STR = '03'
            elif R_DAY_STR == '4':
                R_DAY_STR = '04'
            elif R_DAY_STR == '5':
                R_DAY_STR = '05'
            elif R_DAY_STR == '6':
                R_DAY_STR = '06'
            elif R_DAY_STR == '7':
                R_DAY_STR = '07'
            elif R_DAY_STR == '8':
                R_DAY_STR = '08'
            elif R_DAY_STR == '9':
                R_DAY_STR = '09'

            R_HOUR_STR = str(R_HOUR)
            if R_HOUR_STR == '1':
                R_HOUR_STR = '01'
            elif R_HOUR_STR == '2':
                R_HOUR_STR = '02'
            elif R_HOUR_STR == '3':
                R_HOUR_STR = '03'
            elif R_HOUR_STR == '4':
                R_HOUR_STR = '04'
            elif R_HOUR_STR == '5':
                R_HOUR_STR = '05'
            elif R_HOUR_STR == '6':
                R_HOUR_STR = '06'
            elif R_HOUR_STR == '7':
                R_HOUR_STR = '07'
            elif R_HOUR_STR == '8':
                R_HOUR_STR = '08'
            elif R_HOUR_STR == '9':
                R_HOUR_STR = '09'
            elif R_HOUR_STR == '0':
                R_HOUR_STR = '00'

            R_MINUTES_STR = str(R_MINUTES)
            if R_MINUTES_STR == '1':
                R_MINUTES_STR = '01'
            elif R_MINUTES_STR == '2':
                R_MINUTES_STR = '02'
            elif R_MINUTES_STR == '3':
                R_MINUTES_STR = '03'
            elif R_MINUTES_STR == '4':
                R_MINUTES_STR = '04'
            elif R_MINUTES_STR == '5':
                R_MINUTES_STR = '05'
            elif R_MINUTES_STR == '6':
                R_MINUTES_STR = '06'
            elif R_MINUTES_STR == '7':
                R_MINUTES_STR = '07'
            elif R_MINUTES_STR == '8':
                R_MINUTES_STR = '08'
            elif R_MINUTES_STR == '9':
                R_MINUTES_STR = '09'
            elif R_MINUTES_STR == '0':
                R_MINUTES_STR = '00'

            R_SECONDS_STR = str(R_SECONDS)
            if R_SECONDS_STR == '1':
                R_SECONDS_STR = '01'
            elif R_SECONDS_STR == '2':
                R_SECONDS_STR = '02'
            elif R_SECONDS_STR == '3':
                R_SECONDS_STR = '03'
            elif R_SECONDS_STR == '4':
                R_SECONDS_STR = '04'
            elif R_SECONDS_STR == '5':
                R_SECONDS_STR = '05'
            elif R_SECONDS_STR == '6':
                R_SECONDS_STR = '06'
            elif R_SECONDS_STR == '7':
                R_SECONDS_STR = '07'
            elif R_SECONDS_STR == '8':
                R_SECONDS_STR = '08'
            elif R_SECONDS_STR == '9':
                R_SECONDS_STR = '09'
            elif R_SECONDS_STR == '0':
                R_SECONDS_STR = '00'

            act_update_at = '{0}/{1}/{2} {3}:{4}:{5}'.format(R_YEAR_STR, R_MONTH_STR, R_DAY_STR, R_HOUR_STR,
                                                             R_MINUTES_STR, R_SECONDS_STR)

            rows = [
                [act_doc_id, lbc_office_id, act_gid, act_title, act_remkars, act_reg_date, act_act_div, act_proc_type,
                 act_products, act_member_name, act_must_party, act_party, act_end_date, act_update_at, act_del_flag]]
            writer.writerows(rows)

    csv_file.close()

