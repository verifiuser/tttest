# -*- coding: utf-8 -*-
import xlrd
import random
import codecs
import csv
import sys

reload(sys)
sys.setdefaultencoding('utf-8')


# Class Lbc_Mst
# noinspection PyUnboundLocalVariable
class LbcMst(csv.excel):
    # ヘッダを除く企業情報取得の開始位置
    HEADER_START_ROW = 1

    # Oracle View : LBC_COMPANY_ABBREVIATED_FLAG
    # Elasticsearch : lbc_company_abbreviated_flag
    # 数字2文字の00が入る
    lbc_company_abbreviated_flag = u"00"

    # Oracle View : LBC_OFFICE_NAME
    # Elasticsearch : lbc_office_name
    # 基本NULL、店舗がある場合、店舗名が入る
    # lbc_office_name = u"lbc_office_name"
    lbc_office_name = ""

    # 業種
    # Oracle View : LBC_INDUSTRY_CODE1_LARGE
    # Elasticsearch : lbc_industry_code1_large
    # 業種コード[A-Z]：大項目
    lbc_industry_code1_large = ""

    # Oracle View : LBC_INDUSTRY_CODE1_LARGE
    # Elasticsearch : lbc_industry_code1_medium
    # 業種コード：中項目
    lbc_industry_code1_medium = ""

    # Oracle View : LBC_INDUSTRY_CODE1_SMALL
    # Elasticsearch : lbc_industry_code1_small
    # 業種コード：小項目
    lbc_industry_code1_small = ""

    # Oracle View : LBC_INDUSTRY_CODE1_TINY
    # Elasticsearch : lbc_industry_code1_tiny
    # 業種コード：細項目
    lbc_industry_code1_tiny = ""

    # Oracle View : LBC_INDUSTRY_CODE2_LARGE
    # Elasticsearch : lbc_industry_code2_large
    # 業種コード[A-Z]：大項目
    lbc_industry_code2_large = ""

    # Oracle View : LBC_INDUSTRY_CODE2_MEDIUM
    # Elasticsearch : lbc_industry_code2_medium
    # 業種コード：中項目
    lbc_industry_code2_medium = ""

    # Oracle View : LBC_INDUSTRY_CODE2_SMALL
    # Elasticsearch : lbc_industry_code2_small
    # 業種コード：小項目
    lbc_industry_code2_small = ""

    # Oracle View : LBC_INDUSTRY_CODE2_TINY
    # Elasticsearch : lbc_industry_code2_tiny
    # 業種コード：細項目
    lbc_industry_code2_tiny = ""

    # Oracle View : LBC_INDUSTRY_CODE3_LARGE
    # Elasticsearch : lbc_industry_code3_large
    # 業種コード[A-Z]：大項目
    lbc_industry_code3_large = ""

    # Oracle View : LBC_INDUSTRY_CODE3_MEDIUM
    # Elasticsearch : lbc_industry_code3_medium
    # 業種コード：中項目
    lbc_industry_code3_medium = ""

    # Oracle View : LBC_INDUSTRY_CODE3_SMALL
    # Elasticsearch : lbc_industry_code3_small
    # 業種コード：小項目
    lbc_industry_code3_small = ""

    # Oracle View : LBC_INDUSTRY_CODE3_TINY
    # Elasticsearch : lbc_industry_code3_tiny
    # 業種コード：細項目
    lbc_industry_code3_tiny = ""

    # Oracle View : LBC_C_RELATION_FLAG1
    # Elasticsearch : lbc_c_relation_flag1
    # 不明でNULLが入る
    lbc_c_relation_flag1 = ""

    # Oracle View : LBC_C_LISTED_CODE
    # Elasticsearch : lbc_c_listed_code
    # 不明で数字の9だらけ
    lbc_c_listed_code = 9

    # Oracle View : LBC_C_SEC_CODE
    # Elasticsearch : lbc_c_sec_code
    # 不明でNULLが入る
    lbc_c_sec_code = ""

    # Oracle View : LBC_C_YUHO_NUMBER
    # Elasticsearch : lbc_c_yuho_number
    # 不明でNULLが入る
    lbc_c_yuho_number = ""

    # Oracle View : LBC_C_HYOUTEN
    # Elasticsearch : lbc_c_hyouten
    # 不明で数字の9だらけ
    lbc_c_hyouten = 9

    # Oracle View : LBC_C_COMPANY_NAME
    # Elasticsearch : lbc_c_company_name
    # 会社名(濁点無し - 株式会社除いたもの)
    # lbc_c_company_name(濁点なし）
    lbc_c_company_name = u""

    # Oracle View : LBC_C_COMPANY_NAME_KANA
    # Elasticsearch : lbc_c_company_name_kana
    # 会社名(半角カナ - 株式会社除いたもの)
    # lbc_c_company_name_kana（半角カナ）
    lbc_c_company_name_kana = u""

    # Oracle View : LBC_C_OFFICE_NAME
    # Elasticsearch : lbc_c_office_name
    # office_name(濁点無し)、店舗名がある場合、店舗名が入る(ィなど小文字は、イのように大文字になる)
    lbc_c_office_name = u""

    # Oracle View : LBC_C_BUILDING_NAME
    # Elasticsearch : lbc_c_building_name
    # ビル名(濁点無し)、階数のFが小文字のf
    lbc_c_building_name = u""

    # Oracle View : LBC_C_COMPANY_PREF_ID
    # Elasticsearch : lbc_c_company_pref_id
    # 都道府県コード：2文字
    lbc_c_company_pref_id = ""

    # Oracle View : LBC_C_COMPANY_CITY_ID
    # Elasticsearch : lbc_c_company_city_id
    # 市区町村コード：下1桁とった5文字
    lbc_c_company_city_id = ""

    # Oracle View : LBC_C_COMPANY_ZIP
    # Elasticsearch : lbc_c_company_zip
    # 郵便番号(ハイフンなし)
    lbc_c_company_zip = ""

    # Oracle View : LBC_C_TEL
    # Elasticsearch : lbc_c_tel
    # 電話番号(ハイフンなし - 最大13文字)
    lbc_c_tel = ""

    # Oracle View : LBC_C_FAX
    # Elasticsearch : lbc_c_fax
    # FAX番号(ハイフンなし - 最大13文字)
    lbc_c_fax = ""

    # Oracle View : LBC_C_OFFICE_COUNT
    # Elasticsearch : lbc_c_office_count
    # 不明でNULLが入る
    lbc_c_office_count = u""

    # Oracle View : LBC_C_OFFICE_COUNT_RANGE
    # Elasticsearch : lbc_c_office_count_range
    # 不明で99だらけ
    lbc_c_office_count_range = 99

    # Oracle View : LBC_C_SETUP_DATE
    # Elasticsearch : lbc_c_setup_date
    # 不明でNULL
    lbc_c_setup_date = u""

    # Oracle View : LBC_C_CAPITAL
    # Elasticsearch : lbc_c_capital
    # 不明でNULL
    lbc_c_capital = ""

    # Oracle View : LBC_C_CAPITAL_RANGE
    # Elasticsearch : lbc_c_capital_range
    # 不明で99だらけ
    lbc_c_capital_range = 99

    # Oracle View : LBC_C_EMP_COUNT
    # Elasticsearch : lbc_c_emp_count
    # 不明でNULL
    lbc_c_emp_count = ""

    # Oracle View : LBC_C_EMP_COUNT_RANGE
    # Elasticsearch : lbc_c_emp_count_range
    # 不明で99だらけ
    lbc_c_emp_count_range = 99

    # Oracle View : LBC_C_SALES
    # Elasticsearch : lbc_c_sales
    # 不明でNULL
    lbc_c_sales = ""

    # Oracle View : LBC_C_SALES_RANGE
    # Elasticsearch : lbc_c_sales_range
    # 不明で99だらけ
    lbc_c_sales_range = 99

    # Oracle View : LBC_C_SETTLEMENT_MONTH
    # Elasticsearch : lbc_c_settlement_month
    # 不明でNULL
    lbc_c_settlement_month = u""

    # Oracle View : LBC_C_PROFIT
    # Elasticsearch : lbc_c_profit
    # 不明でNULL
    lbc_c_profit = ""

    # Oracle View : LBC_C_PROFIT_RANGE
    # Elasticsearch : lbc_c_profit_range
    # 不明で99だらけ
    lbc_c_profit_range = 99

    # Oracle View : LBC_C_LICENSE
    # Elasticsearch : lbc_c_license
    # 不明でNULL
    lbc_c_license = u""

    # Oracle View : LBC_C_ORGANIZATIONS
    # Elasticsearch : lbc_c_organizations
    # 不明でNULL
    lbc_c_organizations = u""

    # Oracle View : LBC_C_COMPANY_KIND
    # Elasticsearch : lbc_c_company_kind
    # 不明で0が入る
    # lbc_c_company_kind = u""
    lbc_c_company_kind = 0

    # Oracle View : LBC_C_HAS_URL
    # Elasticsearch :lbc_c_has_url
    # 不明で0が入る
    # lbc_c_has_url = u""
    lbc_c_has_url = 0

    # Oracle View : LBC_C_HAS_FOREIGN_FLAG
    # Elasticsearch : lbc_c_has_foreign_flag
    # 不明で0が入る
    # lbc_c_has_foreign_flag = u""
    lbc_c_has_foreign_flag = 0

    # Oracle View : LBC_C_IS_HEAD_OFFICE
    # Elasticsearch : lbc_c_is_head_office
    # 不明で0が入る
    # lbc_c_is_head_office = u""
    lbc_c_is_head_office = 0

    # Oracle View : LBC_C_STAT_NG
    # Elasticsearch : lbc_c_stat_ng
    # 不明で0が入る
    lbc_c_stat_ng = 0

    # Oracle View : LBC_C_IS_CCNG
    # Elasticsearch : lbc_c_is_ccng
    # 不明で1が入る
    # lbc_c_is_ccng = u""
    lbc_c_is_ccng = 1

    # Oracle View : LBC_C_IS_MUJIN_OFFICE
    # Elasticsearch : lbc_c_is_mujin_office
    # 不明で0が入る
    # lbc_c_is_mujin_office = u""
    lbc_c_is_mujin_office = 0

    # Oracle View : LBC_C_OFFICE_CLASS
    # Elasticsearch : lbc_c_office_class
    # 不明で0が入る
    lbc_c_office_class = 0

    # Oracle View : LBC_C_CORPORATE_NUMBER
    # Elasticsearch : lbc_c_corporate_number
    # 不明でNULLが入る
    lbc_c_corporate_number = u""

    # Oracle View : LBC_C_GRADE
    # Elasticsearch : lbc_c_grade
    # 不明でNULLが入る
    lbc_c_grade = ""

    # Oracle View : LBC_DEL_FLAG
    # Elasticsearch : lbc_del_flag
    # 不明で0が入る
    lbc_del_flag = 0

    # Oracle View : LBC_C_IS_FAXDM
    # Elasticsearch : lbc_c_is_faxdm
    # 不明でNULLが入る
    lbc_c_is_faxdm = ""

    quoting = csv.QUOTE_ALL
    book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
    sheets = book.sheets()

    # 定義シートを読み込む
    s1 = sheets[0]

    # CSVを作成
    csv_file = codecs.open('parent' + '_' + 'lbc_mst' + '.csv', 'w', 'utf-8')
    writer = csv.writer(csv_file)

    for row in xrange(HEADER_START_ROW, s1.nrows):
        # Oracle View : GID
        # Elasticsearch : gid
        # グループID
        gid = s1.cell(row, 2).value

        # Oracle View : LBC_OFFICE_ID
        # Elasticsearch : lbc_office_id
        # 主キー
        lbc_office_id = s1.cell(row, 0).value

        # Oracle View : LBC_C_OFFICE_ID
        # Elasticsearch :  lbc_c_office_id
        # = lbc_office_id
        lbc_c_office_id = lbc_office_id

        # Oracle View : LBC_C_HEAD_OFFICE_ID
        # Elasticsearch :  lbc_c_head_office_id
        # = lbc_office_id
        lbc_c_head_office_id = lbc_office_id

        # Oracle View : LBC_C_TOP_HEAD_OFFICE_ID
        # Elasticsearch : lbc_c_top_head_office_id
        # = lbc_office_id
        lbc_c_top_head_office_id = lbc_office_id

        # Oracle View : LBC_C_TOP_AF_OFFICE_ID1
        # Elasticsearch : lbc_c_top_af_office_id1
        # = lbc_office_id
        lbc_c_top_af_office_id1 = lbc_office_id

        # Oracle View : LBC_C_AFFILIATED_OFFICE_ID1
        # Elasticsearch : lbc_c_affiliated_office_id1
        # = lbc_office_id
        lbc_c_affiliated_office_id1 = lbc_office_id

        # Oracle View : LBC_FORMAL_COMPANY_NAME
        # Elasticsearch : lbc_formal_company_name
        # 会社名(正式名称)
        lbc_formal_company_name = s1.cell(row, 1).value

        # Oracle View : LBC_COMPANY_NAME
        # Elasticsearch : lbc_company_name
        # 会社名(略称 - (株)になる略称形式)
        lbc_company_name = s1.cell(row, 1).value

        # Oracle View : LBC_COMPANY_ABBREVIATED_NAME
        # Elasticsearch : lbc_company_abbreviated_name
        # 法人格の有無
        if u'株' in lbc_company_name:
            lbc_company_abbreviated_name = u"株式会社"
        else:
            lbc_company_abbreviated_name = u"法人格なし"

        # Oracle View : LBC_COMPANY_BEFORE_AFTER
        # Elasticsearch : lbc_company_before_after
        # 前株か後株か不明なのかを判定
        if lbc_company_name.startswith('株', 1, 4):
            lbc_company_before_after = 1
        elif lbc_company_name.endswith('株', 1, 4):
            lbc_company_before_after = 2
        else:
            lbc_company_before_after = 0

        # Oracle View : LBC_COMPANY_BEFORE_AFTER_NAME
        # Elasticsearch : lbc_company_before_after_name
        # 文字で前株価後株価不明なのかを判定
        if lbc_company_before_after == 1:
            lbc_company_before_after_name = u"前"
        elif lbc_company_before_after == 2:
            lbc_company_before_after_name = u"後"
        else:
            lbc_company_before_after_name = u"不明"

        # Oracle View : LBC_CREATE_DATE
        # Elasticsearch : lbc_create_date
        # 作成年月日

        # lbc_create_dateの「年」生成
        R_YEAR = random.randint(2001, 2005)
        # lbc_create_dateの「月」生成
        if R_YEAR == 2017:
            R_MONTH = random.randint(1, 3)
        else:
            R_MONTH = random.randint(1, 12)
        # lbc_create_dateの「日」生成
        if R_MONTH == 1:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 2:
            R_DAY = random.randint(1, 28)
        elif R_MONTH == 3:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 4:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 5:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 6:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 7:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 8:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 9:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 10:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 11:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 12:
            R_DAY = random.randint(1, 31)
        # lbc_create_dateの「時」生成
        R_HOUR = random.randint(9, 23)
        # lbc_create_dateの「分」生成
        R_MINUTES = random.randint(0, 59)
        # lbc_create_dateの「秒」生成
        R_SECONDS = random.randint(0, 59)

        R_YEAR_STR = str(R_YEAR)

        R_MONTH_STR = str(R_MONTH)
        if R_MONTH_STR == '1':
            R_MONTH_STR = '01'
        elif R_MONTH_STR == '2':
            R_MONTH_STR = '02'
        elif R_MONTH_STR == '3':
            R_MONTH_STR = '03'
        elif R_MONTH_STR == '4':
            R_MONTH_STR = '04'
        elif R_MONTH_STR == '5':
            R_MONTH_STR = '05'
        elif R_MONTH_STR == '6':
            R_MONTH_STR = '06'
        elif R_MONTH_STR == '7':
            R_MONTH_STR = '07'
        elif R_MONTH_STR == '8':
            R_MONTH_STR = '08'
        elif R_MONTH_STR == '9':
            R_MONTH_STR = '09'

        R_DAY_STR = str(R_DAY)
        if R_DAY_STR == '1':
            R_DAY_STR = '01'
        elif R_DAY_STR == '2':
            R_DAY_STR = '02'
        elif R_DAY_STR == '3':
            R_DAY_STR = '03'
        elif R_DAY_STR == '4':
            R_DAY_STR = '04'
        elif R_DAY_STR == '5':
            R_DAY_STR = '05'
        elif R_DAY_STR == '6':
            R_DAY_STR = '06'
        elif R_DAY_STR == '7':
            R_DAY_STR = '07'
        elif R_DAY_STR == '8':
            R_DAY_STR = '08'
        elif R_DAY_STR == '9':
            R_DAY_STR = '09'

        R_HOUR_STR = str(R_HOUR)
        if R_HOUR_STR == '1':
            R_HOUR_STR = '01'
        elif R_HOUR_STR == '2':
            R_HOUR_STR = '02'
        elif R_HOUR_STR == '3':
            R_HOUR_STR = '03'
        elif R_HOUR_STR == '4':
            R_HOUR_STR = '04'
        elif R_HOUR_STR == '5':
            R_HOUR_STR = '05'
        elif R_HOUR_STR == '6':
            R_HOUR_STR = '06'
        elif R_HOUR_STR == '7':
            R_HOUR_STR = '07'
        elif R_HOUR_STR == '8':
            R_HOUR_STR = '08'
        elif R_HOUR_STR == '9':
            R_HOUR_STR = '09'
        elif R_HOUR_STR == '0':
            R_HOUR_STR = '00'

        R_MINUTES_STR = str(R_MINUTES)
        if R_MINUTES_STR == '1':
            R_MINUTES_STR = '01'
        elif R_MINUTES_STR == '2':
            R_MINUTES_STR = '02'
        elif R_MINUTES_STR == '3':
            R_MINUTES_STR = '03'
        elif R_MINUTES_STR == '4':
            R_MINUTES_STR = '04'
        elif R_MINUTES_STR == '5':
            R_MINUTES_STR = '05'
        elif R_MINUTES_STR == '6':
            R_MINUTES_STR = '06'
        elif R_MINUTES_STR == '7':
            R_MINUTES_STR = '07'
        elif R_MINUTES_STR == '8':
            R_MINUTES_STR = '08'
        elif R_MINUTES_STR == '9':
            R_MINUTES_STR = '09'
        elif R_MINUTES_STR == '0':
            R_MINUTES_STR = '00'

        R_SECONDS_STR = str(R_SECONDS)
        if R_SECONDS_STR == '1':
            R_SECONDS_STR = '01'
        elif R_SECONDS_STR == '2':
            R_SECONDS_STR = '02'
        elif R_SECONDS_STR == '3':
            R_SECONDS_STR = '03'
        elif R_SECONDS_STR == '4':
            R_SECONDS_STR = '04'
        elif R_SECONDS_STR == '5':
            R_SECONDS_STR = '05'
        elif R_SECONDS_STR == '6':
            R_SECONDS_STR = '06'
        elif R_SECONDS_STR == '7':
            R_SECONDS_STR = '07'
        elif R_SECONDS_STR == '8':
            R_SECONDS_STR = '08'
        elif R_SECONDS_STR == '9':
            R_SECONDS_STR = '09'
        elif R_SECONDS_STR == '0':
            R_SECONDS_STR = '00'

        lbc_create_date = '{0}{1}{2} {3}:{4}:{5}'.format(R_YEAR_STR, R_MONTH_STR, R_DAY_STR, R_HOUR_STR, R_MINUTES_STR,
                                                         R_SECONDS_STR)

        # Oracle View : LBC_UPDATE_DATE
        # Elasticsearch : lbc_update_date
        # 更新年月日

        # lbc_update_dateの「年」生成
        R_YEAR = random.randint(2006, 2010)
        # lbc_update_dateの「月」生成
        if R_YEAR == 2017:
            R_MONTH = random.randint(1, 3)
        else:
            R_MONTH = random.randint(1, 12)
        # lbc_update_dateの「日」生成
        if R_MONTH == 1:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 2:
            R_DAY = random.randint(1, 28)
        elif R_MONTH == 3:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 4:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 5:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 6:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 7:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 8:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 9:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 10:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 11:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 12:
            R_DAY = random.randint(1, 31)
        # lbc_update_dateの「時」生成
        R_HOUR = random.randint(9, 23)
        # lbc_update_dateの「分」生成
        R_MINUTES = random.randint(0, 59)
        # lbc_update_dateの「秒」生成
        R_SECONDS = random.randint(0, 59)

        R_YEAR_STR = str(R_YEAR)

        R_MONTH_STR = str(R_MONTH)
        if R_MONTH_STR == '1':
            R_MONTH_STR = '01'
        elif R_MONTH_STR == '2':
            R_MONTH_STR = '02'
        elif R_MONTH_STR == '3':
            R_MONTH_STR = '03'
        elif R_MONTH_STR == '4':
            R_MONTH_STR = '04'
        elif R_MONTH_STR == '5':
            R_MONTH_STR = '05'
        elif R_MONTH_STR == '6':
            R_MONTH_STR = '06'
        elif R_MONTH_STR == '7':
            R_MONTH_STR = '07'
        elif R_MONTH_STR == '8':
            R_MONTH_STR = '08'
        elif R_MONTH_STR == '9':
            R_MONTH_STR = '09'

        R_DAY_STR = str(R_DAY)
        if R_DAY_STR == '1':
            R_DAY_STR = '01'
        elif R_DAY_STR == '2':
            R_DAY_STR = '02'
        elif R_DAY_STR == '3':
            R_DAY_STR = '03'
        elif R_DAY_STR == '4':
            R_DAY_STR = '04'
        elif R_DAY_STR == '5':
            R_DAY_STR = '05'
        elif R_DAY_STR == '6':
            R_DAY_STR = '06'
        elif R_DAY_STR == '7':
            R_DAY_STR = '07'
        elif R_DAY_STR == '8':
            R_DAY_STR = '08'
        elif R_DAY_STR == '9':
            R_DAY_STR = '09'

        R_HOUR_STR = str(R_HOUR)
        if R_HOUR_STR == '1':
            R_HOUR_STR = '01'
        elif R_HOUR_STR == '2':
            R_HOUR_STR = '02'
        elif R_HOUR_STR == '3':
            R_HOUR_STR = '03'
        elif R_HOUR_STR == '4':
            R_HOUR_STR = '04'
        elif R_HOUR_STR == '5':
            R_HOUR_STR = '05'
        elif R_HOUR_STR == '6':
            R_HOUR_STR = '06'
        elif R_HOUR_STR == '7':
            R_HOUR_STR = '07'
        elif R_HOUR_STR == '8':
            R_HOUR_STR = '08'
        elif R_HOUR_STR == '9':
            R_HOUR_STR = '09'
        elif R_HOUR_STR == '0':
            R_HOUR_STR = '00'

        R_MINUTES_STR = str(R_MINUTES)
        if R_MINUTES_STR == '1':
            R_MINUTES_STR = '01'
        elif R_MINUTES_STR == '2':
            R_MINUTES_STR = '02'
        elif R_MINUTES_STR == '3':
            R_MINUTES_STR = '03'
        elif R_MINUTES_STR == '4':
            R_MINUTES_STR = '04'
        elif R_MINUTES_STR == '5':
            R_MINUTES_STR = '05'
        elif R_MINUTES_STR == '6':
            R_MINUTES_STR = '06'
        elif R_MINUTES_STR == '7':
            R_MINUTES_STR = '07'
        elif R_MINUTES_STR == '8':
            R_MINUTES_STR = '08'
        elif R_MINUTES_STR == '9':
            R_MINUTES_STR = '09'
        elif R_MINUTES_STR == '0':
            R_MINUTES_STR = '00'

        R_SECONDS_STR = str(R_SECONDS)
        if R_SECONDS_STR == '1':
            R_SECONDS_STR = '01'
        elif R_SECONDS_STR == '2':
            R_SECONDS_STR = '02'
        elif R_SECONDS_STR == '3':
            R_SECONDS_STR = '03'
        elif R_SECONDS_STR == '4':
            R_SECONDS_STR = '04'
        elif R_SECONDS_STR == '5':
            R_SECONDS_STR = '05'
        elif R_SECONDS_STR == '6':
            R_SECONDS_STR = '06'
        elif R_SECONDS_STR == '7':
            R_SECONDS_STR = '07'
        elif R_SECONDS_STR == '8':
            R_SECONDS_STR = '08'
        elif R_SECONDS_STR == '9':
            R_SECONDS_STR = '09'
        elif R_SECONDS_STR == '0':
            R_SECONDS_STR = '00'

        lbc_update_date = '{0}{1}{2} {3}:{4}:{5}'.format(R_YEAR_STR, R_MONTH_STR, R_DAY_STR, R_HOUR_STR, R_MINUTES_STR,
                                                         R_SECONDS_STR)

        # Oracle View : LBC_UPDATE_DATE
        # Elasticsearch : lbc_update_at
        # 最終更新年月日

        # lbc_update_atの「年」生成
        R_YEAR = random.randint(2011, 2017)
        # lbc_update_atの「月」生成
        if R_YEAR == 2017:
            R_MONTH = random.randint(1, 3)
        else:
            R_MONTH = random.randint(1, 12)
        # lbc_update_atの「日」生成
        if R_MONTH == 1:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 2:
            R_DAY = random.randint(1, 28)
        elif R_MONTH == 3:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 4:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 5:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 6:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 7:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 8:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 9:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 10:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 11:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 12:
            R_DAY = random.randint(1, 31)
        # lbc_update_atの「時」生成
        R_HOUR = random.randint(9, 23)
        # lbc_update_atの「分」生成
        R_MINUTES = random.randint(0, 59)
        # lbc_update_atの「秒」生成
        R_SECONDS = random.randint(0, 59)

        R_YEAR_STR = str(R_YEAR)

        R_MONTH_STR = str(R_MONTH)
        if R_MONTH_STR == '1':
            R_MONTH_STR = '01'
        elif R_MONTH_STR == '2':
            R_MONTH_STR = '02'
        elif R_MONTH_STR == '3':
            R_MONTH_STR = '03'
        elif R_MONTH_STR == '4':
            R_MONTH_STR = '04'
        elif R_MONTH_STR == '5':
            R_MONTH_STR = '05'
        elif R_MONTH_STR == '6':
            R_MONTH_STR = '06'
        elif R_MONTH_STR == '7':
            R_MONTH_STR = '07'
        elif R_MONTH_STR == '8':
            R_MONTH_STR = '08'
        elif R_MONTH_STR == '9':
            R_MONTH_STR = '09'

        R_DAY_STR = str(R_DAY)
        if R_DAY_STR == '1':
            R_DAY_STR = '01'
        elif R_DAY_STR == '2':
            R_DAY_STR = '02'
        elif R_DAY_STR == '3':
            R_DAY_STR = '03'
        elif R_DAY_STR == '4':
            R_DAY_STR = '04'
        elif R_DAY_STR == '5':
            R_DAY_STR = '05'
        elif R_DAY_STR == '6':
            R_DAY_STR = '06'
        elif R_DAY_STR == '7':
            R_DAY_STR = '07'
        elif R_DAY_STR == '8':
            R_DAY_STR = '08'
        elif R_DAY_STR == '9':
            R_DAY_STR = '09'

        R_HOUR_STR = str(R_HOUR)
        if R_HOUR_STR == '1':
            R_HOUR_STR = '01'
        elif R_HOUR_STR == '2':
            R_HOUR_STR = '02'
        elif R_HOUR_STR == '3':
            R_HOUR_STR = '03'
        elif R_HOUR_STR == '4':
            R_HOUR_STR = '04'
        elif R_HOUR_STR == '5':
            R_HOUR_STR = '05'
        elif R_HOUR_STR == '6':
            R_HOUR_STR = '06'
        elif R_HOUR_STR == '7':
            R_HOUR_STR = '07'
        elif R_HOUR_STR == '8':
            R_HOUR_STR = '08'
        elif R_HOUR_STR == '9':
            R_HOUR_STR = '09'
        elif R_HOUR_STR == '0':
            R_HOUR_STR = '00'

        R_MINUTES_STR = str(R_MINUTES)
        if R_MINUTES_STR == '1':
            R_MINUTES_STR = '01'
        elif R_MINUTES_STR == '2':
            R_MINUTES_STR = '02'
        elif R_MINUTES_STR == '3':
            R_MINUTES_STR = '03'
        elif R_MINUTES_STR == '4':
            R_MINUTES_STR = '04'
        elif R_MINUTES_STR == '5':
            R_MINUTES_STR = '05'
        elif R_MINUTES_STR == '6':
            R_MINUTES_STR = '06'
        elif R_MINUTES_STR == '7':
            R_MINUTES_STR = '07'
        elif R_MINUTES_STR == '8':
            R_MINUTES_STR = '08'
        elif R_MINUTES_STR == '9':
            R_MINUTES_STR = '09'
        elif R_MINUTES_STR == '0':
            R_MINUTES_STR = '00'

        R_SECONDS_STR = str(R_SECONDS)
        if R_SECONDS_STR == '1':
            R_SECONDS_STR = '01'
        elif R_SECONDS_STR == '2':
            R_SECONDS_STR = '02'
        elif R_SECONDS_STR == '3':
            R_SECONDS_STR = '03'
        elif R_SECONDS_STR == '4':
            R_SECONDS_STR = '04'
        elif R_SECONDS_STR == '5':
            R_SECONDS_STR = '05'
        elif R_SECONDS_STR == '6':
            R_SECONDS_STR = '06'
        elif R_SECONDS_STR == '7':
            R_SECONDS_STR = '07'
        elif R_SECONDS_STR == '8':
            R_SECONDS_STR = '08'
        elif R_SECONDS_STR == '9':
            R_SECONDS_STR = '09'
        elif R_SECONDS_STR == '0':
            R_SECONDS_STR = '00'

        lbc_update_at = '{0}{1}{2} {3}:{4}:{5}'.format(R_YEAR_STR, R_MONTH_STR, R_DAY_STR, R_HOUR_STR, R_MINUTES_STR,
                                                       R_SECONDS_STR)

        # Oracle View : LBC_C_INV_DATE
        # Elasticsearch : lbc_c_inv_date
        # 8桁の年月日(YYYYMMDD <- なんでもいいから8桁)
        # lbc_c_inv_date = u""
        # lbc_c_inv_dateの「年」生成
        R_YEAR = random.randint(2003, 2016)
        # lbc_c_inv_dateの「月」生成
        if R_YEAR == 2017:
            R_MONTH = random.randint(1, 3)
        else:
            R_MONTH = random.randint(1, 12)
        # lbc_c_inv_dateの「日」生成
        if R_MONTH == 1:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 2:
            R_DAY = random.randint(1, 28)
        elif R_MONTH == 3:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 4:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 5:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 6:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 7:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 8:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 9:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 10:
            R_DAY = random.randint(1, 31)
        elif R_MONTH == 11:
            R_DAY = random.randint(1, 30)
        elif R_MONTH == 12:
            R_DAY = random.randint(1, 31)

        R_YEAR_STR = str(R_YEAR)

        R_MONTH_STR = str(R_MONTH)
        if R_MONTH_STR == '1':
            R_MONTH_STR = '01'
        elif R_MONTH_STR == '2':
            R_MONTH_STR = '02'
        elif R_MONTH_STR == '3':
            R_MONTH_STR = '03'
        elif R_MONTH_STR == '4':
            R_MONTH_STR = '04'
        elif R_MONTH_STR == '5':
            R_MONTH_STR = '05'
        elif R_MONTH_STR == '6':
            R_MONTH_STR = '06'
        elif R_MONTH_STR == '7':
            R_MONTH_STR = '07'
        elif R_MONTH_STR == '8':
            R_MONTH_STR = '08'
        elif R_MONTH_STR == '9':
            R_MONTH_STR = '09'

        R_DAY_STR = str(R_DAY)
        if R_DAY_STR == '1':
            R_DAY_STR = '01'
        elif R_DAY_STR == '2':
            R_DAY_STR = '02'
        elif R_DAY_STR == '3':
            R_DAY_STR = '03'
        elif R_DAY_STR == '4':
            R_DAY_STR = '04'
        elif R_DAY_STR == '5':
            R_DAY_STR = '05'
        elif R_DAY_STR == '6':
            R_DAY_STR = '06'
        elif R_DAY_STR == '7':
            R_DAY_STR = '07'
        elif R_DAY_STR == '8':
            R_DAY_STR = '08'
        elif R_DAY_STR == '9':
            R_DAY_STR = '09'

        lbc_c_inv_date = R_YEAR_STR + R_MONTH_STR + R_DAY_STR

        rows = [(gid, lbc_office_id, lbc_company_abbreviated_flag, lbc_company_abbreviated_name,
                 lbc_company_before_after, lbc_company_before_after_name, lbc_company_name, lbc_formal_company_name,
                 lbc_office_name, lbc_industry_code1_large, lbc_industry_code1_medium, lbc_industry_code1_small,
                 lbc_industry_code1_small, lbc_industry_code2_large, lbc_industry_code2_medium,
                 lbc_industry_code2_small, lbc_industry_code2_tiny, lbc_industry_code3_large, lbc_industry_code3_medium,
                 lbc_industry_code3_small, lbc_industry_code3_tiny, lbc_create_date, lbc_update_date, lbc_update_at,
                 lbc_c_office_id, lbc_c_head_office_id, lbc_c_top_head_office_id, lbc_c_top_af_office_id1,
                 lbc_c_affiliated_office_id1, lbc_c_relation_flag1, lbc_c_listed_code, lbc_c_sec_code,
                 lbc_c_yuho_number, lbc_c_hyouten, lbc_c_company_name, lbc_c_company_name_kana, lbc_c_office_name,
                 lbc_c_building_name, lbc_c_company_pref_id, lbc_c_company_city_id, lbc_c_company_zip, lbc_c_tel,
                 lbc_c_fax, lbc_c_office_count, lbc_c_office_count_range, lbc_c_setup_date, lbc_c_capital,
                 lbc_c_capital_range, lbc_c_emp_count, lbc_c_emp_count_range, lbc_c_sales, lbc_c_sales_range,
                 lbc_c_settlement_month, lbc_c_profit, lbc_c_profit_range, lbc_c_license, lbc_c_organizations,
                 lbc_c_inv_date, lbc_c_company_kind, lbc_c_has_url, lbc_c_has_foreign_flag, lbc_c_is_head_office,
                 lbc_c_stat_ng, lbc_c_is_ccng, lbc_c_is_mujin_office, lbc_c_office_class, lbc_c_corporate_number,
                 lbc_c_grade, lbc_del_flag, lbc_c_is_faxdm)]
        writer.writerows(rows)

    csv_file.close()
