# -*- coding: utf-8 -*-
import xlrd
import random
import codecs
import csv
import sys

reload(sys)
sys.setdefaultencoding('utf-8')


# Class Mst_Bizitem
# noinspection PyUnboundLocalVariable
class MstBizitem(csv.excel):
    # ヘッダを除く企業情報取得の開始位置
    HEADER_START_ROW = 1

    status_list = ["01", "02", "03", "04", "05", "06", "07"]
    product_list = ["DISH001", "DISH002", "DM001"]
    pro_list = [0, 10, 20, 40, 50, 80, 90, 100]
    bizitem_update_at = u''

    # Oracle定義 : DEL_FLAG
    # ES定義 : bizitem_del_flag
    # 論理削除フラグ
    bizitem_del_flag = 0

    quoting = csv.QUOTE_ALL
    book = xlrd.open_workbook('landscape_dummy_data_definition_file.xls')
    sheets = book.sheets()

    # 定義シートを読み込む
    s1 = sheets[0]

    # CSVを作成
    csv_file = codecs.open('child' + '_' + 'client_mst_bizitem' + '.csv', 'w', 'utf-8')
    writer = csv.writer(csv_file)

    for row in xrange(HEADER_START_ROW, s1.nrows):

        # データ生成数の取得
        CLASS_OF_ENT = s1.cell(row, 3).value

        if CLASS_OF_ENT == u'A':
            CLASS_NUM = s1.cell(1, 5).value
        elif CLASS_OF_ENT == u'B':
            CLASS_NUM = s1.cell(2, 5).value
        elif CLASS_OF_ENT == u'C':
            CLASS_NUM = s1.cell(3, 5).value
        elif CLASS_OF_ENT == u'D':
            CLASS_NUM = s1.cell(4, 5).value

        CLASS_NUM = int(CLASS_NUM)

        # Oracle定義 : OFFICE_ID
        # ES定義 : lbc_office_id
        # 企業コード : 企業コード
        lbc_office_id = s1.cell(row, 0).value
        lbc_office_id = str(lbc_office_id)
   
        # Oracle定義 : GROUP_ID
        # ES定義 : bizitem_gid
        # グループID
        bizitem_gid = s1.cell(row, 2).value

        for i in xrange(CLASS_NUM):

            # Oracle定義 : BIZ_ITEM_ID（GROUP_ID + BIZ_ITEM_ID）
            # ES定義 : bizitem_id
            # 主キー
            # bizitem_idの取得（gid - CLIENT_DEAL_STATUS_ID)
            bizitem_gid_str = str(bizitem_gid)
            bizitem_id_num = 10000000000 + i
            bizitem_id_str = str(bizitem_id_num)

            bizitem_id = bizitem_gid_str + bizitem_id_str

            # Oracle定義 : STATUS
            # ES定義 : bizitem_status
            # 案件フェーズ
            bizitem_status = random.choice(status_list)

            # Oracle定義 : PRODUCT
            # ES定義 : bizitem_product
            # 案件商材
            bizitem_product = random.choice(product_list)

            # Oracle定義 : PRICE
            # ES定義 : bizitem_price
            # 金額
            bizitem_price = random.randint(100, 100000)

            # Oracle定義 : PROBABILITY
            # ES定義 : bizitem_probability
            # 確度
            bizitem_probability = random.choice(pro_list)

            # Oracle定義 : UPD_DATE
            # ES定義 : bizitem_update_at
            # 更新日
            # bizitem_update_at
            # bizitem_update_atの「年」生成
            R_YEAR = random.randint(2007, 2016)
            # bizitem_update_atの「月」生成
            if R_YEAR == 2017:
                R_MONTH = random.randint(1, 3)
            else:
                R_MONTH = random.randint(1, 12)
            # bizitem_update_atの「日」生成
            if R_MONTH == 1:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 2:
                R_DAY = random.randint(1, 28)
            elif R_MONTH == 3:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 4:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 5:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 6:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 7:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 8:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 9:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 10:
                R_DAY = random.randint(1, 31)
            elif R_MONTH == 11:
                R_DAY = random.randint(1, 30)
            elif R_MONTH == 12:
                R_DAY = random.randint(1, 31)
            # bizitem_update_atの「時」生成
            R_HOUR = random.randint(9, 23)
            # bizitem_update_atの「分」生成
            R_MINUTES = random.randint(0, 59)
            # bizitem_update_atの「秒」生成
            R_SECONDS = random.randint(0, 59)

            R_YEAR_STR = str(R_YEAR)

            R_MONTH_STR = str(R_MONTH)
            if R_MONTH_STR == '1':
                R_MONTH_STR = '01'
            elif R_MONTH_STR == '2':
                R_MONTH_STR = '02'
            elif R_MONTH_STR == '3':
                R_MONTH_STR = '03'
            elif R_MONTH_STR == '4':
                R_MONTH_STR = '04'
            elif R_MONTH_STR == '5':
                R_MONTH_STR = '05'
            elif R_MONTH_STR == '6':
                R_MONTH_STR = '06'
            elif R_MONTH_STR == '7':
                R_MONTH_STR = '07'
            elif R_MONTH_STR == '8':
                R_MONTH_STR = '08'
            elif R_MONTH_STR == '9':
                R_MONTH_STR = '09'

            R_DAY_STR = str(R_DAY)
            if R_DAY_STR == '1':
                R_DAY_STR = '01'
            elif R_DAY_STR == '2':
                R_DAY_STR = '02'
            elif R_DAY_STR == '3':
                R_DAY_STR = '03'
            elif R_DAY_STR == '4':
                R_DAY_STR = '04'
            elif R_DAY_STR == '5':
                R_DAY_STR = '05'
            elif R_DAY_STR == '6':
                R_DAY_STR = '06'
            elif R_DAY_STR == '7':
                R_DAY_STR = '07'
            elif R_DAY_STR == '8':
                R_DAY_STR = '08'
            elif R_DAY_STR == '9':
                R_DAY_STR = '09'

            R_HOUR_STR = str(R_HOUR)
            if R_HOUR_STR == '1':
                R_HOUR_STR = '01'
            elif R_HOUR_STR == '2':
                R_HOUR_STR = '02'
            elif R_HOUR_STR == '3':
                R_HOUR_STR = '03'
            elif R_HOUR_STR == '4':
                R_HOUR_STR = '04'
            elif R_HOUR_STR == '5':
                R_HOUR_STR = '05'
            elif R_HOUR_STR == '6':
                R_HOUR_STR = '06'
            elif R_HOUR_STR == '7':
                R_HOUR_STR = '07'
            elif R_HOUR_STR == '8':
                R_HOUR_STR = '08'
            elif R_HOUR_STR == '9':
                R_HOUR_STR = '09'
            elif R_HOUR_STR == '0':
                R_HOUR_STR = '00'

            R_MINUTES_STR = str(R_MINUTES)
            if R_MINUTES_STR == '1':
                R_MINUTES_STR = '01'
            elif R_MINUTES_STR == '2':
                R_MINUTES_STR = '02'
            elif R_MINUTES_STR == '3':
                R_MINUTES_STR = '03'
            elif R_MINUTES_STR == '4':
                R_MINUTES_STR = '04'
            elif R_MINUTES_STR == '5':
                R_MINUTES_STR = '05'
            elif R_MINUTES_STR == '6':
                R_MINUTES_STR = '06'
            elif R_MINUTES_STR == '7':
                R_MINUTES_STR = '07'
            elif R_MINUTES_STR == '8':
                R_MINUTES_STR = '08'
            elif R_MINUTES_STR == '9':
                R_MINUTES_STR = '09'
            elif R_MINUTES_STR == '0':
                R_MINUTES_STR = '00'

            R_SECONDS_STR = str(R_SECONDS)
            if R_SECONDS_STR == '1':
                R_SECONDS_STR = '01'
            elif R_SECONDS_STR == '2':
                R_SECONDS_STR = '02'
            elif R_SECONDS_STR == '3':
                R_SECONDS_STR = '03'
            elif R_SECONDS_STR == '4':
                R_SECONDS_STR = '04'
            elif R_SECONDS_STR == '5':
                R_SECONDS_STR = '05'
            elif R_SECONDS_STR == '6':
                R_SECONDS_STR = '06'
            elif R_SECONDS_STR == '7':
                R_SECONDS_STR = '07'
            elif R_SECONDS_STR == '8':
                R_SECONDS_STR = '08'
            elif R_SECONDS_STR == '9':
                R_SECONDS_STR = '09'
            elif R_SECONDS_STR == '0':
                R_SECONDS_STR = '00'

            bizitem_update_at = '{0}/{1}/{2} {3}:{4}:{5}'.format(R_YEAR_STR, R_MONTH_STR, R_DAY_STR, R_HOUR_STR,
                                                                 R_MINUTES_STR, R_SECONDS_STR)

            rows = [[bizitem_id, lbc_office_id, bizitem_gid, bizitem_status, bizitem_product, bizitem_price,
                     bizitem_probability, bizitem_update_at, bizitem_del_flag]]
            writer.writerows(rows)

    csv_file.close()
